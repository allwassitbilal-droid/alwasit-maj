// Log of when appointment dates appeared on the calendar, used to find the real release times.
// Pure helpers here; the background script owns reading/writing the store.

export interface SeenEntry {
  /** Epoch ms when the dates were first seen. */
  at: number;
  month: string;
  /** data-day values ("M/D/YYYY") that were enabled. */
  dates: string[];
}

export const HISTORY_KEY = "history";
export const HISTORY_MAX = 300;

export function appendCapped<T>(list: readonly T[], item: T, max = HISTORY_MAX): T[] {
  return [...list, item].slice(-max);
}

export function normalizeHistory(raw: unknown): SeenEntry[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter(
    (e): e is SeenEntry =>
      !!e && typeof e.at === "number" && typeof e.month === "string" && Array.isArray(e.dates),
  );
}

/** Count of sightings per hour of day (local time), index 0..23. */
export function hourHistogram(entries: readonly SeenEntry[]): number[] {
  const bins = Array<number>(24).fill(0);
  for (const e of entries) bins[new Date(e.at).getHours()]!++;
  return bins;
}

/** Count of sightings per weekday, index 0 = Sunday .. 6 = Saturday. */
export function weekdayHistogram(entries: readonly SeenEntry[]): number[] {
  const bins = Array<number>(7).fill(0);
  for (const e of entries) bins[new Date(e.at).getDay()]!++;
  return bins;
}

/** Hours with the most sightings, busiest first; ties keep the earlier hour first. Empty hours are skipped. */
export function topHours(hist: readonly number[], n = 3): number[] {
  return hist
    .map((count, hour) => ({ count, hour }))
    .filter((x) => x.count > 0)
    .sort((a, b) => b.count - a.count || a.hour - b.hour)
    .slice(0, n)
    .map((x) => x.hour);
}
