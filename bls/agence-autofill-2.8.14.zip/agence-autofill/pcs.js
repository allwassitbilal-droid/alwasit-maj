// «🖥 Les PC de l'équipe» (shared by Autofill TLS and Autofill BLS).
// Service worker: each PC writes its own line in the team settings (teamSettings.pcs, synced ☁):
//   { name, v: version of the extension, at: last time seen } — at start, when its version or name changes,
//   and at least every 6 hours while Chrome is open. sync.js merges the lines of all PCs.
// Panel (⚙): the list — which PC has which version, and since when it wasn't seen; «Nom de ce PC» to rename it.
(() => {
  const local = chrome.storage.local;
  const mine = chrome.runtime.getManifest().version;
  const EVERY = 6 * 3600e3;
  const cmp = (a, b) => {
    const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
    return 0;
  };
  const defaultName = id => `PC ${id.slice(3, 7).toUpperCase()}`;

  async function ident() {
    let { pcId, pcName } = await local.get(['pcId', 'pcName']);
    if (!pcId) { pcId = 'pc-' + crypto.randomUUID().slice(0, 8); await local.set({ pcId }); }
    return { id: pcId, name: (pcName || '').trim() || defaultName(pcId) };
  }

  // ---- Service worker: the heartbeat ----
  if (typeof document === 'undefined') {
    let chain = Promise.resolve(); // one at a time, none skipped
    const beat = force => (chain = chain.then(async () => {
      const { teamSettings, teamSynced } = await local.get(['teamSettings', 'teamSynced']);
      if (teamSynced === undefined) return; // not connected ☁ yet: nothing shared
      const { id, name } = await ident();
      const me = teamSettings?.pcs?.[id];
      if (!force && me && !me.deleted && me.v === mine && me.name === name && Date.now() - me.at < EVERY) return;
      const { teamSettings: ts = {} } = await local.get('teamSettings');
      await local.set({ teamSettings: { ...ts, pcs: { ...(ts.pcs || {}), [id]: { name, v: mine, at: Date.now() } } } });
    }).catch(() => {}));

    chrome.alarms.create('pc-equipe', { delayInMinutes: 2, periodInMinutes: 60 });
    chrome.alarms.onAlarm.addListener(a => { if (a.name === 'pc-equipe') beat(); });
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local') return;
      if (ch.pcName) beat(true);
      if (ch.teamSynced && ch.teamSynced.oldValue === undefined) beat(true); // just connected ☁
    });
    beat();
    return;
  }

  // ---- Panel (⚙): the list ----
  const el = (tag, props = {}, ...kids) => {
    const e = Object.assign(document.createElement(tag), props);
    e.append(...kids.filter(k => k != null && k !== false));
    return e;
  };
  const ago = at => {
    const m = Math.round((Date.now() - at) / 60e3);
    if (m < 2) return 'à l\'instant';
    if (m < 60) return `il y a ${m} min`;
    const h = Math.round(m / 60);
    if (h < 24) return `il y a ${h} h`;
    return `il y a ${Math.round(h / 24)} j`;
  };

  async function render() {
    const box = document.querySelector('#pcs-box');
    if (!box || document.activeElement?.closest?.('.pc-name')) return; // not while typing the name
    const { teamSettings = {}, teamSynced } = await local.get(['teamSettings', 'teamSynced']);
    const { id, name } = await ident();
    const input = el('input', { value: name, maxLength: 40, placeholder: 'ex : Serveur 1, Bureau accueil', autocomplete: 'off' });
    input.onchange = async () => { await local.set({ pcName: input.value.trim() }); };
    const kids = [
      el('div', { className: 'hint' }, el('b', { textContent: '🖥 Les PC de l\'équipe' }), ' — quelle version sur quel PC'),
      el('label', { className: 'pc-name' }, el('span', { textContent: 'Nom de ce PC' }), input),
    ];
    if (teamSynced === undefined) {
      kids.push(el('div', { className: 'hint', textContent: 'Connectez-vous ☁ pour voir les PC de l\'équipe.' }));
      return box.replaceChildren(...kids);
    }
    const pcs = Object.entries(teamSettings.pcs || {}).filter(([, p]) => p && !p.deleted);
    const latest = pcs.reduce((v, [, p]) => (cmp(p.v, v) > 0 ? p.v : v), mine);
    pcs.sort((a, b) => (a[0] === id ? -1 : b[0] === id ? 1 : 0) || (a[1].name || '').localeCompare(b[1].name || ''));
    const rows = pcs.map(([k, p]) => {
      const old = cmp(p.v, latest) < 0, stale = Date.now() - p.at > 2 * 86400e3;
      return el('li', { className: 'pc' + (old ? ' old' : '') + (stale ? ' stale' : '') },
        el('span', { className: 'pc-dot', textContent: old ? '⚠' : '✓' }),
        el('span', { className: 'pc-main' },
          el('b', { textContent: (p.name || k) + (k === id ? ' · ce PC' : '') }),
          el('small', { textContent: `v${p.v} · vu ${ago(p.at)}${old ? ' · ancienne version' : ''}` })),
        k === id ? null : el('button', {
          type: 'button', className: 'pc-del', textContent: '✕', title: 'Retirer ce PC de la liste (il revient s\'il se rallume)',
          onclick: async () => {
            const { teamSettings: ts = {} } = await local.get('teamSettings');
            await local.set({ teamSettings: { ...ts, pcs: { ...(ts.pcs || {}), [k]: { deleted: true, at: Date.now() } } } });
          },
        }));
    });
    kids.push(rows.length ? el('ul', { className: 'pcs' }, ...rows) : el('div', { className: 'hint', textContent: 'Les PC apparaissent ici quelques minutes après leur connexion ☁.' }));
    box.replaceChildren(...kids);
  }

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && (ch.teamSettings || ch.teamSynced || ch.pcName)) render();
  });
  setInterval(render, 60e3);
  globalThis.AAPcs = { render };
  render();
})();
