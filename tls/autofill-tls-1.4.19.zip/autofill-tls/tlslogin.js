// «TLS» button (service worker): sign in on TLScontact with the client's Gmail + TLS password.
// The panel asks { type: 'tls-login', clientId }; we open the TLS login page (team setting, ⚙) or reuse an open
// TLScontact tab. On the centre page we click «Prendre rendez-vous» and answer «Oui» / «Oui» (France-Visas filled,
// registered on TLScontact): that leads to the login page (i2-auth.visas-fr.tlscontact.com, with a reCAPTCHA).
// There we fill the email and the password; the person ticks the captcha and clicks «Se connecter». The password waits in session memory (never on disk) for 3 minutes at most.
(() => {
  const KEY = 'tlsLogin';
  const DEFAULT_URL = 'https://visas-fr.tlscontact.com/fr-fr/country/ma/vac/maTNG2fr'; // TLS Tanger
  const TLS_TABS = ['*://*.tlscontact.com/*'];
  const isTls = url => /^https:\/\/([\w-]+\.)*tlscontact\.com\//i.test(url || '');

  async function start(clientId, windowId) {
    const { clients = [], teamSettings = {} } = await chrome.storage.local.get(['clients', 'teamSettings']);
    const c = clients.find(x => x.id === clientId);
    if (!c) return { ok: false, error: 'Client introuvable' };
    const email = (c.gmail || '').trim(), pass = c.tlsmdp || '';
    if (!email || !pass) return { ok: false, error: 'Ajoutez le Gmail et le mot de passe TLS du client (✎ → Gmail et compte TLS)' };
    await chrome.storage.session.set({ [KEY]: { email, pass, until: Date.now() + 3 * 60e3, clicked: 0, name: `${c.prenom || ''} ${c.nom || ''}`.trim() } });
    const win = windowId ?? (await chrome.windows.getLastFocused({ windowTypes: ['normal'] }).catch(() => undefined))?.id;
    const [open] = await chrome.tabs.query({ url: TLS_TABS, ...(win !== undefined ? { windowId: win } : {}) });
    if (open?.id !== undefined) {
      await chrome.tabs.update(open.id, { active: true });
      if (open.status === 'complete') run(open.id);
      return { ok: true, reused: true };
    }
    let url = (teamSettings.tlsLoginUrl || '').trim() || DEFAULT_URL;
    if (!/^https:\/\//i.test(url)) url = DEFAULT_URL;
    await chrome.tabs.create({ url, active: true, ...(win !== undefined ? { windowId: win } : {}) });
    return { ok: true };
  }

  async function run(tabId) {
    const { [KEY]: job } = await chrome.storage.session.get(KEY);
    if (!job || job.until < Date.now()) return chrome.storage.session.remove(KEY);
    let res;
    try {
      [{ result: res }] = await chrome.scripting.executeScript({ target: { tabId }, func: fillLogin, args: [job.email, job.pass, job.clicked < 5, job.name] });
    } catch { return; } // page not reachable (closed, error page): try again on the next load
    if (res?.clicked) {
      // The page only had a «Se connecter» link: we clicked it, the login form comes on the next load (or right away).
      await chrome.storage.session.set({ [KEY]: { ...job, clicked: job.clicked + 1 } });
      setTimeout(() => run(tabId), 1800);
      return;
    }
    if (res?.filled) await chrome.storage.session.remove(KEY); // done (sent, or waiting for the captcha)
  }

  /** In the page: find the login form (waits up to 15 s), fill it like typing, then press the button (not over a captcha). */
  async function fillLogin(email, pass, mayClickLink, name) {
    const visible = e => e && !e.disabled && e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden';
    const setVal = (input, v) => {
      input.focus();
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, v);
      for (const t of ['input', 'change']) input.dispatchEvent(new Event(t, { bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
      input.blur();
    };
    const find = () => {
      const pw = [...document.querySelectorAll('input[type=password]')].find(visible);
      if (!pw) return null;
      const scope = pw.form || pw.closest('form, [role=dialog], main, body') || document;
      const sel = 'input[type=email], input[autocomplete=username], input[name*=user i], input[id*=user i], input[name*=mail i], input[id*=mail i], input[name*=login i], input[id*=login i], input[type=text]';
      const user = [...scope.querySelectorAll(sel)].find(e => visible(e) && e !== pw);
      return { pw, user, scope };
    };
    const banner = (text, keep) => {
      document.getElementById('aa-tls-banner')?.remove();
      const b = Object.assign(document.createElement('div'), { id: 'aa-tls-banner', textContent: text });
      Object.assign(b.style, { position: 'fixed', zIndex: 2147483647, left: '50%', top: '12px', transform: 'translateX(-50%)', maxWidth: '90vw',
        background: '#0055A4', color: '#fff', font: '600 14px/1.4 system-ui, sans-serif', padding: '10px 16px', borderRadius: '10px', boxShadow: '0 6px 20px rgba(0,0,0,.35)' });
      document.documentElement.append(b);
      if (!keep) setTimeout(() => b.remove(), 9000);
      b.onclick = () => b.remove();
    };

    let f = null;
    for (let i = 0; i < 50 && !(f = find()); i++) {
      if (i === 5 && mayClickLink) {
        // No form yet. The TLS centre page: «Prendre rendez-vous», then two questions answered «Oui»; else a login link.
        const txt = e => (e.textContent || e.value || '').replace(/\s+/g, ' ').trim();
        const all = [...document.querySelectorAll('a, button, [role=button]')].filter(visible);
        const ouis = all.filter(e => /^oui$/i.test(txt(e)));
        if (ouis.length) { for (const o of ouis) o.click(); return { clicked: true }; }
        const go = all.find(e => /^(se connecter|connexion|login|log in|sign in|s'identifier)$/i.test(txt(e)))
          || all.find(e => /^prendre (un )?rendez-vous$/i.test(txt(e)))
          || all.find(e => /^(continuer|suivant|valider)$/i.test(txt(e)));
        if (go) { go.click(); return { clicked: true }; }
      }
      await new Promise(r => setTimeout(r, 300));
    }
    if (!f) return { filled: false };
    if (f.user) setVal(f.user, email);
    setVal(f.pw, pass);
    const captcha = document.querySelector('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], iframe[src*="turnstile"], iframe[src*="challenges.cloudflare"], .g-recaptcha, .h-captcha, .cf-turnstile, [data-sitekey]');
    if (captcha) {
      banner(`Autofill TLS : ${name || 'client'} — email et mot de passe remplis. Cochez « Je ne suis pas un robot », puis « Se connecter ».`, true);
      return { filled: true, captcha: true };
    }
    const btn = [...f.scope.querySelectorAll('button[type=submit], input[type=submit], #kc-login, button')]
      .find(e => visible(e) && (e.type === 'submit' || e.id === 'kc-login' || /connexion|se connecter|login|log in|sign in|valider|continuer/i.test(e.textContent || e.value || '')));
    banner(`Autofill TLS : connexion de ${name || 'client'}…`);
    setTimeout(() => (btn ? btn.click() : f.pw.form?.requestSubmit?.()), 400);
    return { filled: true, sent: true };
  }

  chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (info.status === 'complete' && isTls(tab.url)) run(tabId);
  });
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg?.type !== 'tls-login') return false;
    start(msg.clientId, msg.windowId).then(reply, e => reply({ ok: false, error: e.message }));
    return true;
  });
})();
