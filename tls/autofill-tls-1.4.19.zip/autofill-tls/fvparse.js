// Reads the France-Visas application PDF (Cerfa 14076*05 «Demande de Visa Schengen», made by france-visas.gouv.fr)
// from its text, by position: each answer sits in a fixed box under or next to its numbered label.
// Ticked boxes are a «n» (ZapfDingbats ■) just left of the option. Input: pdf.js text items of pages 1-3.
// Works on the text only: nothing leaves the PC.
globalThis.AAFV = (() => {
  const clean = s => s.replace(/\s+/g, ' ').trim();
  const isBox = s => s.length === 1 && /[-■-◿☐-☒]/.test(s);
  const isDate = s => /^\d{2}\/\d{2}\/\d{4}$/.test(s);
  const iso = s => (isDate(s) ? s.split('/').reverse().join('-') : '');
  const COL = 460; // the right column (from x 466) is the administration's, never an answer
  /** Words of a row as printed: a space only where the PDF leaves a gap (pdf.js splits words in pieces). */
  const join = its => its.reduce((acc, it, k) => {
    if (!k) return it.s;
    const prev = its[k - 1];
    const gap = prev.w ? it.x - (prev.x + prev.w) : 9;
    return acc + (gap > 1.2 && !/\s$/.test(acc) && !/^\s/.test(it.s) ? ' ' : '') + it.s;
  }, '');

  function rowsOf(items) {
    const rows = [];
    for (const it of [...items].sort((a, b) => b.y - a.y || a.x - b.x)) {
      if (it.s === '' || it.s === ' ') continue;
      let r = rows.find(r => Math.abs(r.y - it.y) < 3);
      if (!r) rows.push(r = { y: it.y, items: [] });
      r.items.push(it);
    }
    rows.sort((a, b) => b.y - a.y);
    for (const r of rows) { r.items.sort((a, b) => a.x - b.x); r.text = join(r.items); }
    return rows;
  }

  function page(items) {
    const rows = rowsOf(items);
    /** First row whose text matches; its y, and the x where the match starts. */
    const find = (re, from = Infinity) => {
      for (const r of rows) {
        if (r.y >= from) continue;
        if (!re.test(r.text)) continue;
        // x of the item where the match starts
        let x = r.items[0].x;
        for (let i = 0; i < r.items.length; i++) {
          if (re.test(join(r.items.slice(i)))) x = r.items[i].x; else break;
        }
        return { y: r.y, x, row: r };
      }
      return null;
    };
    /** Text of the items in a box: below y `top` (exclusive) down to y `bottom` (exclusive), x in [x0, x1). */
    const box = (top, bottom, x0, x1, skip) => rows
      .filter(r => r.y < top - 1 && r.y > bottom + 1)
      .map(r => clean(join(r.items.filter(i => i.x >= x0 && i.x < x1 && !isBox(i.s) && i.s !== 'n'))))
      .filter(t => t && !(skip && skip.test(t)));
    /** Text right of «:» on the label's own row, up to x1. */
    const after = (hit, x1 = COL) => {
      if (!hit) return '';
      const its = hit.row.items.filter(i => i.x < x1);
      const k = its.findIndex((i, n) => n > 0 && i.x >= hit.x && /:\s*$/.test(i.s));
      return clean(join(its.slice(k + 1)));
    };
    /** Ticked options (text after a «n») inside a box. */
    const ticked = (top, bottom, x0, x1) => {
      const out = [];
      for (const r of rows) {
        if (r.y > top + 1 || r.y < bottom - 1) continue;
        const its = r.items.filter(i => i.x >= x0 && i.x < x1);
        for (let i = 0; i < its.length; i++) {
          if (its[i].s !== 'n') continue;
          const words = [];
          for (let j = i + 1; j < its.length && its[j].s !== 'n' && !isBox(its[j].s); j++) words.push(its[j]);
          if (words.length) out.push(clean(join(words)));
        }
      }
      return out;
    };
    return { rows, find, box, after, ticked };
  }

  function parse(pages) {
    const [p1, p2, p3] = pages.map(page);
    const out = { fv: {} }, fv = out.fv;
    const set = (k, v) => { if (v) fv[k] = v; };
    const all = pages.flat().map(i => i.s).join(' ');
    if (!/Demande de Visa Schengen/i.test(all) || !/14076/.test(all)) throw new Error('Ce PDF n\'est pas un formulaire France-Visas (Demande de Visa Schengen).');

    // ---- page 1 ----
    if (p1) {
      const L = re => p1.find(re);
      out.nom = p1.after(L(/^1\. Nom \[nom de famille\]/));
      set('nomNaissance', p1.after(L(/^2\. Nom/)));
      out.prenom = p1.after(L(/^3\. Prénom/));
      const l4 = L(/^4\. Date de naissance/), l6 = L(/6\. Pays de naissance/), l8 = L(/8\. Sexe/) || L(/9\. É\s*tat Civil/), lNat = L(/Nationalité à la naissance/), lAutre = L(/Autre\(s\) nationalité/);
      const l9 = L(/9\. É\s*tat Civil/) || l8;
      if (l4) {
        out.naissance = iso(p1.box(l4.y, l8 ? Math.min(l8.y, l9.y) : 0, 0, 176).find(isDate) || '');
        set('lieuNaissance', p1.box(l4.y, l6 ? l6.y : 0, 176, 314, /^(année\)|:)/).join(' '));
        if (l6) set('paysNaissance', p1.box(l6.y, l9 ? l9.y : 0, 176, 314).join(' '));
        set('nationalite', p1.box(l4.y, lNat ? lNat.y : 0, 314, COL).join(' '));
        if (lNat) set('nationaliteNaissance', p1.box(lNat.y, lAutre ? lAutre.y : 0, 314, COL, /^Autre\(s\)/).join(' '));
        if (lAutre) set('autresNationalites', [p1.after(lAutre), ...p1.box(lAutre.y, l9 ? l9.y : 0, 314, COL)].filter(Boolean).join(' '));
      }
      if (l9) {
        const l10 = L(/^10\. Autorité parentale/);
        const low = l10 ? l10.y : l9.y - 40;
        set('sexe', p1.ticked(l9.y, low, 0, 205)[0]);
        set('etatCivil', p1.ticked(l9.y, low, 205, COL)[0]);
        const l11 = L(/^11\. Numéro national/);
        if (l10 && l11) set('tuteur', p1.box(l10.y, l11.y, 0, COL, /numéro de téléphone, adresse électronique/).join(', '));
      }
      set('cin', p1.after(L(/^11\. Numéro national/)).replace(/\s/g, ''));
      const l12 = L(/^12\. Type de document/), l13 = L(/^13\. Numéro du document/);
      if (l12 && l13) set('typeDoc', p1.ticked(l12.y, l13.y, 0, COL)[0]);
      if (l13) {
        const l17 = L(/^17\. Données/);
        const vals = p1.rows.filter(r => r.y < l13.y - 1 && r.y > (l17 ? l17.y : 0) + 1).flatMap(r => r.items.filter(i => i.x < COL));
        const at = (x0, x1) => clean(join(vals.filter(i => i.x >= x0 && i.x < x1)));
        out.passeport = at(0, 180).replace(/\s/g, '');
        out.delivre = iso(at(180, 270));
        out.expire = iso(at(270, 360));
        set('delivrePar', at(360, COL));
      }
      // Administration column: date and number of the application
      const lDate = L(/Date de la demande/), lNum = L(/Numéro de la demande/);
      if (lDate) set('dateDemande', iso(p1.box(lDate.y, lNum ? lNum.y : lDate.y - 20, 455, 600).find(isDate) || ''));
      if (lNum) set('reference', p1.box(lNum.y, lNum.y - 20, 455, 600).join('').replace(/\s/g, ''));
    }

    // ---- page 2 ----
    if (p2) {
      const L = re => p2.find(re);
      const l19 = L(/^19\. Adresse du domicile/), l20 = L(/^20\. Résidence/);
      if (l19) {
        const lines = p2.box(l19.y, l20 ? l20.y : 0, 0, 415);
        const mail = lines.find(t => /@/.test(t));
        set('adresse', lines.filter(t => t !== mail).join(', '));
        set('email', mail);
        out.mobile = p2.box(l19.y, l20 ? l20.y : 0, 415, 600).join(' ').replace(/\s/g, '');
      }
      const l21 = L(/21\. Profession actuelle/), l22 = L(/22\. Nom, adresse/), l23 = L(/^23\. Objet/), l24 = L(/^24\. Informations/);
      if (l20 && l21) {
        const t = p2.ticked(l20.y, l21.y, 0, 600)[0];
        set('residenceAutre', t && /^Oui/.test(t) ? clean(p2.box(l20.y, l21.y, 0, 600).join(' ')) : t);
      }
      if (l21 && l22) set('profession', p2.box(l21.y, l22.y, 0, 600).join(' '));
      if (l22 && l23) set('employeur', p2.box(l22.y, l23.y, 0, 600).join(', '));
      if (l23 && l24) set('objet', p2.ticked(l23.y, l24.y, 0, 600).join(', '));
      const l25 = L(/^25\. État membre de destination/), l27 = L(/^27\. Nombre d’entrées/) || L(/^27\. Nombre d'entrées/);
      if (l24 && l25) set('infoObjet', p2.box(l24.y, l25.y, 0, 600).join(' '));
      if (l25 && l27) {
        set('destination', p2.box(l25.y, l27.y, 0, 290, /^destination, le cas/).join(' '));
        set('premiereEntree', p2.box(l25.y, l27.y, 290, 600).join(' '));
      }
      const lArr = L(/Date d.{0,4}arrivée prévue/), lDep = L(/Date de départ prévue/);
      if (l27 && lArr) set('entrees', p2.ticked(l27.y, lArr.y, 0, 600)[0]);
      const dateIn = hit => (hit ? iso(hit.row.items.map(i => i.s.trim()).find(isDate) || '') : '');
      set('dateArrivee', dateIn(lArr));
      set('dateDepart', dateIn(lDep));
      const l28 = L(/^28\. Empreintes/), l29 = L(/^29\. Autorisation/);
      if (l28 && l29) {
        const t = p2.ticked(l28.y, l29.y, 0, 600)[0];
        set('empreintes', t && /^Oui/.test(t) ? 'Oui' : t);
      }
      const l30 = L(/30\. Nom et prénom de la ou des personnes qui invitent/);
      if (l30) set('hebergement', p2.box(l30.y, 0, 0, 600, /^temporaire dans le ou les États membres|^\d+\/4$/).join(' '));
    }

    // ---- page 3 ----
    if (p3) {
      const L = re => p3.find(re);
      const lAdr = L(/^Adresse et adresse électronique de la ou des personnes qui invitent/), l31 = L(/31\. Nom et adresse de l/);
      if (lAdr && l31) {
        const lines = p3.box(lAdr.y, l31.y, 0, 415, /^d.{0,3}hébergement temporaire/);
        const mail = lines.find(t => /@/.test(t));
        set('hebergementAdresse', lines.filter(t => t !== mail).join(', '));
        set('hebergementEmail', mail);
        set('hebergementTel', p3.box(lAdr.y, l31.y, 415, 600).join(' ').replace(/\s/g, ''));
      }
      const lContact = L(/^Nom, prénom, adresse, numéro de téléphone, et adresse électronique de la personne de contact/), l32 = L(/32\. Les frais de voyage/);
      if (l31 && lContact) set('entrepriseHote', p3.box(l31.y, lContact.y, 0, 600, /^l.{0,3}organisation\s*:$/).join(', '));
      if (l32) {
        const l33 = L(/^3\s*3\s*\.\s*Nom et prénom de la personne qui remplit/);
        const low = l33 ? l33.y : 0;
        const by = p3.ticked(l32.y, low, 0, 300), gar = p3.ticked(l32.y, low, 300, 600);
        set('financement', [...by.filter(t => /^Par /.test(t)), ...gar.filter(t => /^Par /.test(t))].join(', ')
          || (gar.length ? 'Par un garant' : ''));
        set('moyens', [...by, ...gar].filter(t => !/^Par /.test(t)).join(', '));
        if (l33) {
          const lA = L(/^Adresse et adresse électronique de la personne qui remplit/);
          set('remplisseur', p3.box(l33.y, lA ? lA.y : l33.y - 30, 0, 600).join(' '));
        }
      }
    }
    for (const k of ['nom', 'prenom', 'passeport', 'mobile']) if (!out[k]) delete out[k];
    for (const k of ['naissance', 'delivre', 'expire']) if (!out[k]) delete out[k];
    return out;
  }

  return { parse };
})();
