// Team sync (runs in the background service worker).
// chrome.storage.local `clients` stays the local copy everything else reads and writes.
// `synced` = { id: canonical JSON } of what the server has, so we know what changed on each side.
(() => {
  // Same content => same string, whatever the key order (Postgres jsonb reorders keys).
  const canon = c => JSON.stringify(Object.keys(c).sort().reduce((o, k) => ((o[k] = c[k]), o), {}));

  // Server rows + local list -> new local list. Local edits not uploaded yet are kept.
  function mergeRemote(local, synced, rows) {
    const remote = new Map(rows.map(r => [r.id, { ...r.data, id: r.id }]));
    const localById = new Map(local.map(c => [c.id, c]));
    const pending = c => c && synced[c.id] !== undefined && canon(c) !== synced[c.id];
    const clients = [], newSynced = {};
    for (const [id, data] of remote) {
      newSynced[id] = canon(data);
      const l = localById.get(id);
      clients.push(pending(l) ? l : data);
    }
    // Not on the server: new here (keep, will be uploaded) or deleted by a colleague (drop).
    for (const c of local) if (!remote.has(c.id) && synced[c.id] === undefined) clients.push(c);
    return { clients, synced: newSynced };
  }

  // What must be sent to the server.
  function diffLocal(clients, synced) {
    const ids = new Set(clients.map(c => c.id));
    return {
      upserts: clients.filter(c => canon(c) !== synced[c.id]),
      deletes: Object.keys(synced).filter(id => !ids.has(id)),
    };
  }

  // One realtime event -> new local list.
  function applyEvent(clients, synced, p) {
    clients = [...clients];
    synced = { ...synced };
    if (p.eventType === 'DELETE') {
      const id = p.old?.id;
      clients = clients.filter(c => c.id !== id);
      delete synced[id];
    } else {
      const data = { ...p.new.data, id: p.new.id };
      const i = clients.findIndex(c => c.id === data.id);
      const pending = i >= 0 && synced[data.id] !== undefined && canon(clients[i]) !== synced[data.id];
      synced[data.id] = canon(data);
      if (!pending) { if (i >= 0) clients[i] = data; else clients.push(data); }
    }
    return { clients, synced };
  }

  // ---- Team settings (Telegram, BLS peak hours): one reserved row of the same table, never a client ----
  const TEAM_ID = '__equipe__';
  // Deep, so jsonb's own key order in nested objects ({ telegram: {…} }) never looks like a change.
  const deepCanon = v => JSON.stringify(v, (_k, x) => (x && typeof x === 'object' && !Array.isArray(x)
    ? Object.keys(x).sort().reduce((o, k) => ((o[k] = x[k]), o), {}) : x));

  // «À faire» tasks (teamSettings.tasks) merge task by task: the newest change of each task wins, so two PCs
  // ticking different tasks at the same moment both keep their tick.
  function mergeTasks(a = [], b = []) {
    const m = new Map(a.map(t => [t.id, t]));
    for (const t of b) { const x = m.get(t.id); if (!x || (t.at || 0) > (x.at || 0)) m.set(t.id, t); }
    return [...m.values()];
  }

  // «Les PC de l'équipe» (teamSettings.pcs, one entry per PC): merged per PC, newest wins — every PC writes its own.
  function mergePcs(a = {}, b = {}) {
    const o = { ...a };
    for (const [k, v] of Object.entries(b || {})) if (!o[k] || (v?.at || 0) > (o[k]?.at || 0)) o[k] = v;
    return o;
  }
  /** The parts several PCs write at once (tasks, pcs), merged; the rest from `mine`. */
  function mergeShared(mine = {}, theirs = {}) {
    const out = { ...mine };
    if (mine.tasks || theirs.tasks) out.tasks = mergeTasks(theirs.tasks, mine.tasks);
    if (mine.pcs || theirs.pcs) out.pcs = mergePcs(theirs.pcs, mine.pcs);
    // 🔄 «already announced on Telegram» marks (annonce.js, phone): the furthest one wins, so nothing is announced twice.
    const vmax = (a, b) => { const x = String(a || '0').split('.').map(Number), y = String(b || '0').split('.').map(Number);
      for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0) ? a : b;
      return a || b; };
    if (mine.majAnnoncee || theirs.majAnnoncee) out.majAnnoncee = vmax(mine.majAnnoncee, theirs.majAnnoncee);
    if (mine.majTel || theirs.majTel) out.majTel = (mine.majTel || '') > (theirs.majTel || '') ? mine.majTel : theirs.majTel;
    if (mine.majCaisse || theirs.majCaisse) out.majCaisse = (mine.majCaisse || '') > (theirs.majCaisse || '') ? mine.majCaisse : theirs.majCaisse;
    return out;
  }

  /** Server row (or none) + local copy -> what to keep locally; local edits not uploaded yet win (tasks, pcs: merged). */
  function mergeTeam(local, teamSynced, row) {
    const pending = local !== undefined && deepCanon(local) !== teamSynced;
    if (!row) return null;
    if (!pending) return { teamSettings: row.data, teamSynced: deepCanon(row.data) };
    if (!local.tasks && !row.data?.tasks && !local.pcs && !row.data?.pcs) return null;
    // Never synced yet (tasks added before ☁ login): keep the team's other settings from the server.
    const base = teamSynced === undefined ? { ...row.data, ...local } : local;
    return { teamSettings: mergeShared(base, row.data || {}), teamSynced: deepCanon(row.data) };
  }

  globalThis.AASync = { canon, mergeRemote, diffLocal, applyEvent, TEAM_ID, deepCanon, mergeTeam, mergeTasks, mergePcs, mergeShared };
  if (!globalThis.chrome?.storage) return; // tests (node)

  const local = chrome.storage.local;
  const authStore = {
    getItem: async k => (await local.get('sb:' + k))['sb:' + k] ?? null,
    setItem: (k, v) => local.set({ ['sb:' + k]: v }),
    removeItem: k => local.remove('sb:' + k),
  };
  let sb = null, channel = null, chain = Promise.resolve();
  // Server work runs one job at a time.
  const serial = fn => (chain = chain.then(fn).catch(e => setStatus({ state: 'error', error: e.message || String(e) })));
  const setStatus = async s => {
    const { syncStatus } = await local.get('syncStatus');
    return local.set({ syncStatus: { ...syncStatus, ...s, at: Date.now() } });
  };

  async function config() {
    const { syncConfig } = await local.get('syncConfig');
    const c = globalThis.AA_CONFIG || {};
    return { url: c.supabaseUrl || syncConfig?.url, key: c.supabaseKey || syncConfig?.key };
  }

  async function client() {
    if (sb) return sb;
    const { url, key } = await config();
    if (!url || !key) return null;
    sb = supabase.createClient(url, key, {
      auth: { storage: authStore, persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
    });
    return sb;
  }

  async function session() {
    const s = await client();
    if (!s) return null;
    const { data } = await s.auth.getSession();
    return data.session ? { s, user: data.session.user, token: data.session.access_token } : null;
  }

  async function pushTeam(ses) {
    const { teamSettings, teamSynced } = await local.get(['teamSettings', 'teamSynced']);
    if (teamSettings === undefined || deepCanon(teamSettings) === teamSynced) return;
    // Tasks and PCs: add what colleagues changed meanwhile, so this upload never erases their changes.
    const { data: cur } = await ses.s.from('clients').select('data').eq('id', TEAM_ID).maybeSingle();
    const data = cur?.data ? mergeShared(teamSettings, cur.data) : teamSettings;
    const { error } = await ses.s.from('clients').upsert({
      id: TEAM_ID, data, updated_at: new Date().toISOString(), updated_by: ses.user.email,
    });
    if (error) throw error;
    const { teamSettings: now } = await local.get('teamSettings');
    // Edited again while uploading: keep that edit pending (it goes up next time).
    if (deepCanon(now) === deepCanon(teamSettings)) await local.set({ teamSettings: data, teamSynced: deepCanon(data) });
    else await local.set({ teamSettings: mergeShared(now, data), teamSynced: deepCanon(data) });
  }

  async function pushInner() {
    const ses = await session();
    if (!ses) return;
    await pushTeam(ses);
    const { clients = [], synced = {} } = await local.get(['clients', 'synced']);
    const { upserts, deletes } = diffLocal(clients, synced);
    if (!upserts.length && !deletes.length) return;
    const now = new Date().toISOString();
    for (let i = 0; i < upserts.length; i += 500) {
      const rows = upserts.slice(i, i + 500).map(c => ({ id: c.id, data: c, updated_at: now, updated_by: ses.user.email }));
      const { error } = await ses.s.from('clients').upsert(rows);
      if (error) throw error;
    }
    if (deletes.length) {
      const { error } = await ses.s.from('clients').delete().in('id', deletes);
      if (error) throw error;
    }
    const { synced: cur = {} } = await local.get('synced');
    for (const c of upserts) cur[c.id] = canon(c);
    for (const id of deletes) delete cur[id];
    await local.set({ synced: cur });
    await setStatus({ state: 'on', lastPush: Date.now() });
  }

  async function pullInner() {
    const ses = await session();
    if (!ses) return setStatus({ state: 'off' });
    const rows = [];
    for (let from = 0; ; from += 1000) {
      const { data, error } = await ses.s.from('clients').select('id,data').range(from, from + 999);
      if (error) throw error;
      rows.push(...data);
      if (data.length < 1000) break;
    }
    const { clients = [], synced = {}, teamSettings, teamSynced } = await local.get(['clients', 'synced', 'teamSettings', 'teamSynced']);
    const team = mergeTeam(teamSettings, teamSynced, rows.find(r => r.id === TEAM_ID));
    await local.set({ ...mergeRemote(clients, synced, rows.filter(r => r.id !== TEAM_ID)), ...team });
    await pushInner();
    await setStatus({ state: 'on', email: ses.user.email, error: null });
  }

  async function subscribe() {
    const ses = await session();
    if (!ses || channel) return;
    channel = ses.s.channel('aa-clients')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'clients' }, p => serial(async () => {
        if ((p.new?.id || p.old?.id) === TEAM_ID) {
          if (p.eventType === 'DELETE') return;
          const { teamSettings, teamSynced } = await local.get(['teamSettings', 'teamSynced']);
          const team = mergeTeam(teamSettings, teamSynced, p.new);
          if (team) await local.set(team);
          return;
        }
        const { clients = [], synced = {} } = await local.get(['clients', 'synced']);
        await local.set(applyEvent(clients, synced, p));
      }))
      .subscribe(st => setStatus({ live: st === 'SUBSCRIBED' }));
  }

  const push = () => serial(pushInner);
  const pull = () => serial(async () => { await subscribe(); await pullInner(); });

  async function login({ url, key, email, password }) {
    if (url && key) await local.set({ syncConfig: { url: url.trim(), key: key.trim() } });
    if (sb) { await sb.removeAllChannels(); sb = null; channel = null; }
    const s = await client();
    if (!s) return { ok: false, error: 'Adresse ou clé Supabase manquante' };
    const { error } = await s.auth.signInWithPassword({ email, password });
    if (error) { await setStatus({ state: 'error', error: error.message }); return { ok: false, error: error.message }; }
    await pull();
    await chain;
    return { ok: true };
  }

  async function logout() {
    if (sb) { await sb.removeAllChannels(); await sb.auth.signOut(); }
    sb = null;
    channel = null;
    // Local accounts stay; next login merges them with the server.
    await local.set({ synced: {} });
    await local.set({ syncStatus: { state: 'off', at: Date.now() } });
  }

  // The panel talks to Storage itself (files.js) with the current token.
  async function filesAuth() {
    const ses = await session();
    if (!ses) return {};
    const { url, key } = await config();
    return { url, key, token: ses.token };
  }
  globalThis.AAFilesAuth = filesAuth; // bls.js (same worker) reads the clients' photos with it

  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && (ch.clients || ch.teamSettings)) push(); });
  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    const job = msg.type === 'login' ? login(msg) : msg.type === 'logout' ? logout()
      : msg.type === 'sync-now' ? (pull(), chain.then(() => ({ ok: true })))
      : msg.type === 'files-auth' ? filesAuth() : null;
    if (!job) return false;
    job.then(reply, e => reply({ ok: false, error: e.message }));
    return true;
  });
  // Safety net when the live connection was asleep: full refresh every minute.
  chrome.alarms.create('aa-pull', { periodInMinutes: 1 });
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'aa-pull') pull(); });
  pull();
})();
