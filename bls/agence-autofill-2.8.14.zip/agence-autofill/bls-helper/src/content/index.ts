import { askBackground, sendToBackground, type ContentRequest, type DiagResponse, type FillReport, type LeaderReply, type WatchState } from "../shared/messages";
import { activeProfile } from "../shared/profiles";
import { loadAccount, loadProfiles, loadSettings, onAccountChanged, onSettingsChanged } from "../shared/storage";
import { describeForm, fillForm, formSignature } from "./autofill";
import { availableDays } from "./dom";
import { startAutoLogin } from "./login";
import { activeNoticeShown, continueNewBooking, emptyAccountPage, handleActiveNotice, newBookingWindowReady, onLeaveLogin, runNavigator } from "./navigator";
import { startApiData } from "./apidata";
import { startPhotoHelper } from "./photos";
import { signupBlocksLogin, signupKnown, startSignupHelper } from "./signup";
import { httpTrouble, showRetry } from "./retry";
import { contextAlive, onSignupPage, sleep, waitFor } from "./util";
import { Watcher } from "./watcher";
import { mountWidget } from "./widget";

/** How long after a signup fill the next wizard step is still filled automatically. */
const SIGNUP_STEP_WAIT_MS = 10 * 60_000;
/** How long «Open BLS» waits for login + navigation to reach the date page. */
const AUTOSTART_WAIT_MS = 10 * 60_000;
/** After load, time for the site to render before an error page is judged as one. */
const ERROR_PAGE_CHECK_MS = 4000;
/** How often an empty appointments page is looked for (see below). */
const EMPTY_PAGE_CHECK_MS = 4000;

startApiData(); // first: BLS's calendar answers can come while settings load

void (async () => {
  const [settings, account] = await Promise.all([loadSettings(), loadAccount()]);

  let filling: Promise<FillReport> | null = null;

  const watcher = new Watcher(settings, () => filling !== null);
  onSettingsChanged((s) => watcher.updateSettings(s));

  /** Fills the applicant (or signup) form and reports the outcome in the activity log. */
  function fill(followStep = true): Promise<FillReport> {
    // Pickers open one popover at a time: a second click while filling just waits for the first.
    filling ??= (async () => {
      const who = activeProfile(await loadProfiles());
      const report = await fillForm(who.profile);
      const { filled, check, missing = [], kept = [] } = report;
      if (!filled.length && !check.length && !missing.length && !kept.length)
        watcher.note("📝 ما لقيت حتى خانة نعرفها فهاد الصفحة", "warn");
      else
        watcher.note(
          `📝 عبيت ${filled.length} خانة لـ ${who.name}` +
            (missing.length ? ` · ناقصين فالبروفايل (عمّرهم فالإعدادات): ${missing.join("، ")}` : "") +
            (check.length ? ` · راجع بيدك (برتقالي): ${check.join("، ")}` : "") +
            (kept.length ? ` · خليت كيف كتبتيهم: ${kept.join("، ")}` : "") +
            (missing.length || check.length ? "" : " · راجع قبل ما تصيفط"),
          missing.length || check.length ? "warn" : "ok",
        );
      if (followStep && onSignupPage()) void fillNextStep();
      return report;
    })().finally(() => (filling = null));
    return filling;
  }

  /** The signup wizard's step 2 (passport) appears after the user clicks Continue: fill it once, same request. */
  async function fillNextStep(): Promise<void> {
    const before = formSignature();
    const next = await waitFor(() => onSignupPage() && formSignature() !== before && formSignature() !== "", SIGNUP_STEP_WAIT_MS, 500);
    if (!next) return;
    await sleep(400); // let the step's fields mount fully
    await fill(false);
  }

  chrome.runtime.onMessage.addListener(
    (msg: ContentRequest, _sender, reply: (r: WatchState | DiagResponse | FillReport) => void) => {
      switch (msg?.type) {
        case "diag":
          reply({ diag: JSON.stringify({ ...JSON.parse(watcher.diag()), form: describeForm() }, null, 1) });
          return;
        case "fillForm":
          void fill().then(reply);
          return true; // async reply
        case "start":
          watcher.start();
          break;
        case "stop":
          watcher.stop();
          break;
        case "yield":
          watcher.yieldLeadership();
          break;
        case "autoStart":
          void startWhenReady();
          break;
        case "getState":
          break;
        default:
          return;
      }
      reply(watcher.state());
    },
  );

  watcher.init();
  mountWidget(watcher, { onFill: () => void fill() });
  startPhotoHelper((text) => watcher.note(text, "ok"));
  startSignupHelper(
    () => fill(false),
    (text) => {
      watcher.note(text, "warn");
      sendToBackground({ type: "notify", text });
    },
  );

  let navigating = false;
  /** Starts the navigator unless it's off or already running; true when it started. */
  const navigate = (): boolean => {
    const s = watcher.currentSettings;
    if (navigating || !s.enabled || !s.autoNav) return false;
    navigating = true;
    void runNavigator(askUser).finally(() => (navigating = false));
    return true;
  };
  /** A step only the user can do (or check): alert, and start watching once the date page shows. */
  function askUser(text: string): void {
    watcher.note(text, "warn");
    sendToBackground({ type: "notify", text });
    void startWhenReady();
  }

  let currentAccount = account;
  const recheckLogin = startAutoLogin(
    () => watcher.currentSettings,
    // Agence Autofill: while a new account is being made, the login form gets nothing (no Gmail code tried as password).
    () => (signupBlocksLogin() ? { ...currentAccount, password: "" } : currentAccount),
    (text) => {
      watcher.note(text, "warn");
      sendToBackground({ type: "notify", text });
    },
  );
  void signupKnown.then(() => recheckLogin()); // the login waited to know whether an account is being made
  onAccountChanged((a) => {
    currentAccount = a;
    recheckLogin();
  });
  // Toolbar switches apply at once: Auto / Relogin / Nav auto turned on start what they control.
  let was = settings;
  onSettingsChanged((s) => {
    if ((s.enabled && !was.enabled) || (s.autoLogin && !was.autoLogin)) recheckLogin();
    if ((s.enabled && !was.enabled) || (s.autoNav && !was.autoNav)) navigate();
    was = s;
  });
  navigate();
  // The site can land on an empty appointments page after the navigator's run ended (slow login, a click
  // elsewhere): look again every few seconds and take it from there.
  setInterval(() => {
    if (!contextAlive()) return;
    const s = watcher.currentSettings;
    // «Vous avez déjà un rendez-vous actif»: D'accord, then carry on with that appointment.
    if (s.enabled && s.autoNav && activeNoticeShown()) {
      void startWhenReady();
      void handleActiveNotice(askUser).then(() => setTimeout(navigate, 1500));
      return;
    }
    if (emptyAccountPage()) navigate();
    // The new-booking window: one client ready → «Continuer vers la sélection du créneau», then the dates.
    if (s.enabled && s.autoNav && newBookingWindowReady()) {
      void startWhenReady();
      void continueNewBooking(askUser);
    }
  }, EMPTY_PAGE_CHECK_MS);

  let arming = false;
  /** «Open BLS» from the popup: once login and navigation reach the date page, start watching. */
  async function startWhenReady(): Promise<void> {
    if (arming || watcher.state().running) return;
    arming = true;
    watcher.note("🚀 كنمشي لصفحة التواريخ، ومن تما غادي نبدا المراقبة بوحدي...");
    navigate();
    const ready = await waitFor(() => !onSignupPage() && availableDays() !== null, AUTOSTART_WAIT_MS, 1000);
    arming = false;
    if (!ready) return watcher.note("⚠️ ما وصلتش لصفحة التواريخ: دخل بيدك وضغط ▶ Start", "warn");
    sendToBackground({ type: "autoStartDone" });
    if (!watcher.state().running) watcher.start();
  }
  // A page loaded after «Open BLS» (new window, or a reload during login) asks whether to start.
  // Agence Autofill: also when watching was on before a reload, an error retry or a Chrome restart.
  void askBackground<LeaderReply>({ type: "autoStartPending" }).then((r) => {
    if (!r?.ok) return;
    if (r.resumed) {
      if (!watcher.currentSettings.enabled) return;
      watcher.note("🔄 رجعت للمراقبة بعد إعادة التحميل");
    }
    void startWhenReady();
  });

  // Agence Autofill: the page itself is a BLS / Cloudflare error (429, 5xx): count down and reload.
  setTimeout(() => {
    if (!watcher.currentSettings.enabled || availableDays() !== null) return;
    void httpTrouble(false).then((t) => {
      if (t) showRetry(t, () => sendToBackground({ type: "resume", on: false }));
    });
  }, ERROR_PAGE_CHECK_MS);

  // The SPA can drop an expired session back to the login form without a page load; once
  // auto-login gets past it, walk back to the date page (the watch loop resumes there by itself).
  onLeaveLogin(() => {
    if (navigate()) watcher.note("🔑 دخلت للحساب، كنمشي لصفحة التواريخ...");
  });
})();
