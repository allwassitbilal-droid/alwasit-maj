// Fills the applicant form, or the account signup wizard, from the saved profile, on the user's request only.
// It never submits and never ticks a consent box: filled fields turn green, recognised-but-unfillable
// ones orange, for the user to review.
import type { FillReport } from "../shared/messages";
import {
  CHOICE_KEYS,
  DATE_KEYS,
  PASSPORT_TYPE_RE,
  PROFILE_LABELS,
  classifyField,
  fieldValue,
  formatDateFor,
  isDialCodeOnly,
  matchOption,
  phoneDigits,
  phoneForInput,
  type Profile,
  type ProfileKey,
} from "../shared/profile";
import { parseIsoDate } from "../shared/slots";
import { PICKER_SEL, dayTime, isOff, navButtonIn, popoverOf } from "./dom";
import { onSignupPage, setNativeValue, sleep, textOf, waitFor } from "./util";

type Control = HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement;

// Radios are handled per group (choice fields) in fillForm, not as standalone fields.
const SKIP_TYPES = new Set(["hidden", "password", "submit", "button", "reset", "checkbox", "radio", "file", "image", "search", "range", "color"]);
const STYLE_ID = "bls-autofill-style";
/** Month steps a date picker without year/month lists may need: 100 years covers any date of birth. */
const MAX_MONTH_STEPS = 1200;

function ensureStyle(): void {
  if (document.getElementById(STYLE_ID)) return;
  const st = document.createElement("style");
  st.id = STYLE_ID;
  st.textContent =
    ".bls-filled{outline:2px solid #0a8550!important;outline-offset:1px;background-color:rgba(10,133,80,.06)!important}" +
    ".bls-check{outline:2px dashed #d97706!important;outline-offset:1px}";
  document.head.appendChild(st);
}

const visible = (el: Element): boolean => {
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden";
};

/** Form controls the user could type into, excluding login/search fields. */
export function fillableControls(): Control[] {
  return [...document.querySelectorAll<Control>("input, select, textarea")].filter(
    (el) =>
      !(el instanceof HTMLInputElement && SKIP_TYPES.has(el.type)) &&
      !el.disabled &&
      !(el as HTMLInputElement).readOnly &&
      visible(el),
  );
}

/** Popover pickers inside forms (not the phone input's country button: the dial code stays as the site set it). */
export function pickerTriggers(): HTMLButtonElement[] {
  return [...document.querySelectorAll<HTMLButtonElement>(PICKER_SEL)].filter(
    (b) => !!b.closest("form") && !b.closest(".PhoneInput") && !b.disabled && visible(b),
  );
}

function labelText(el: Control | HTMLButtonElement): string {
  const parts = [...(el.labels ?? [])].map(textOf);
  const by = el.getAttribute("aria-labelledby");
  if (by) parts.push(...by.split(/\s+/).map((id) => textOf(document.getElementById(id))));
  // Unlabelled fields in shadcn-style forms: the label usually sits just above in the same wrapper.
  if (!parts.length) {
    const wrapLabel = el.closest("div")?.querySelector("label");
    if (wrapLabel) parts.push(textOf(wrapLabel));
  }
  return parts.join(" ");
}

function describe(el: Control | HTMLButtonElement): string {
  return [
    labelText(el),
    el.getAttribute("aria-label"),
    el instanceof HTMLButtonElement ? "" : el.name,
    el.id,
    el.getAttribute("placeholder"),
    el.getAttribute("autocomplete"),
  ]
    .filter(Boolean)
    .join(" ");
}

/** Fields of radio groups (e.g. sex, marital status) keyed by group name. */
function radioGroups(): Map<string, HTMLInputElement[]> {
  const groups = new Map<string, HTMLInputElement[]>();
  for (const r of document.querySelectorAll<HTMLInputElement>('input[type="radio"]')) {
    if (!r.name || r.disabled) continue;
    groups.set(r.name, [...(groups.get(r.name) ?? []), r]);
  }
  return groups;
}

function groupLabel(radios: HTMLInputElement[]): string {
  const fieldset = radios[0]?.closest("fieldset");
  const legend = fieldset?.querySelector("legend");
  const group = radios[0]?.closest('[role="radiogroup"]');
  return [textOf(legend), group?.getAttribute("aria-label"), radios[0]?.name].filter(Boolean).join(" ");
}

const MISSING_TIP = "BLS Helper: هاد المعلومة ناقصة فالبروفايل. حل إعدادات الإضافة وعمّرها، ولا كتبها بيدك";
const FAILED_TIP = "BLS Helper: ما قدرتش نعمّر هاد الخانة، عمّرها بيدك وتأكد منها";

/** Outlines a field green (filled) or orange (to do by hand), with the reason as its tooltip. */
function mark(el: HTMLElement, ok: boolean, why: string): void {
  el.classList.add(ok ? "bls-filled" : "bls-check");
  if (why) {
    el.dataset.blsTitle = el.getAttribute("title") ?? "";
    el.title = why;
  }
}

function unmark(el: HTMLElement): void {
  el.classList.remove("bls-filled", "bls-check");
  if (el.dataset.blsTitle !== undefined) {
    el.title = el.dataset.blsTitle;
    delete el.dataset.blsTitle;
  }
}

/** Whether a field already holds something the user (not the site's "+212" prefix) put there. */
const hasValue = (el: Control): boolean => !!el.value && !(el instanceof HTMLInputElement && el.type === "tel" && isDialCodeOnly(el.value));

function fillControl(el: Control, key: ProfileKey, value: string): boolean {
  if (el instanceof HTMLSelectElement) {
    const opts = [...el.options].map((o) => ({ text: o.text, value: o.value }));
    const i = matchOption(opts, key, value);
    if (i < 0) return false;
    setNativeValue(el, opts[i]!.value);
    return true;
  }
  if (CHOICE_KEYS.has(key)) return false; // a choice typed as free text: leave it to the user
  if (key === "phone") {
    const v = phoneForInput(value, el.value);
    setNativeValue(el, v);
    // Phone inputs reformat as they go ("+212 6 12..."): compare digits only.
    return phoneDigits(el.value) === phoneDigits(v);
  }
  let v = value;
  if (DATE_KEYS.has(key) && !(el instanceof HTMLInputElement && el.type === "date")) {
    v = formatDateFor(value, el.getAttribute("placeholder") ?? "");
  }
  setNativeValue(el, v);
  // BLS upper-cases some fields as you type ("Larache" -> "LARACHE"): that is still a success.
  return el.value.trim().toLowerCase() === v.trim().toLowerCase();
}

// ---- popover pickers (signup wizard) ----

const escape = (): void => {
  (document.activeElement ?? document.body).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
};

/** Opens a picker's popover and returns its content, or null (popover closed again) when it didn't open. */
async function openPicker(trigger: HTMLButtonElement, ready: (pop: HTMLElement) => boolean): Promise<HTMLElement | null> {
  if (trigger.getAttribute("aria-expanded") !== "true") trigger.click();
  const pop = await waitFor(() => {
    const p = popoverOf(trigger);
    return p && ready(p) ? p : null;
  }, 3000);
  if (!pop) await closePicker(trigger);
  return pop;
}

async function closePicker(trigger: HTMLButtonElement): Promise<void> {
  if (trigger.getAttribute("aria-expanded") !== "true") return;
  escape();
  await waitFor(() => trigger.getAttribute("aria-expanded") !== "true", 1000);
}

const isComboSet = (b: HTMLButtonElement): boolean => !!b.querySelector('[data-slot="badge"]');

/** A date trigger still showing its "YYYY-MM-DD" placeholder. */
const isDateEmpty = (b: HTMLButtonElement): boolean => /y{4}|^$/i.test(textOf(b.querySelector("span[title]") ?? b));

/** The date a picker trigger shows ("October 2nd, 2026"), as a local-midnight timestamp, or null. */
function shownDate(b: HTMLButtonElement): number | null {
  const t = (b.querySelector("span[title]")?.getAttribute("title") ?? textOf(b)).replace(/(\d)(st|nd|rd|th)\b/g, "$1");
  const iso = parseIsoDate(t.trim());
  if (iso !== null) return iso;
  const ms = Date.parse(t);
  if (Number.isNaN(ms)) return null;
  const d = new Date(ms);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}


/** Picks a combobox option chosen by pick() from the open list; searches when the list is filtered/long. */
async function chooseOption(
  trigger: HTMLButtonElement,
  pick: (opts: Array<{ text: string; value: string }>) => number,
  search: string,
): Promise<boolean> {
  const pop = await openPicker(trigger, (p) => !!p.querySelector('[role="option"]'));
  if (!pop) return false;
  const options = () => [...pop.querySelectorAll<HTMLElement>('[role="option"]')].filter((o) => o.getAttribute("aria-disabled") !== "true");
  const asData = (os: HTMLElement[]) => os.map((o) => ({ text: textOf(o), value: o.getAttribute("data-value") ?? "" }));
  let os = options();
  let i = pick(asData(os));
  const box = pop.querySelector<HTMLInputElement>("input");
  if (i < 0 && box && search) {
    setNativeValue(box, search);
    await sleep(200);
    os = options();
    i = pick(asData(os));
  }
  if (i >= 0) {
    os[i]!.click();
    await waitFor(() => isComboSet(trigger), 1500);
  }
  await closePicker(trigger);
  return isComboSet(trigger);
}

/** Opens a Radix-style list (Select / combobox) and clicks the option pick() returns. */
async function pickFromList(listTrigger: HTMLElement, pick: (opts: HTMLElement[]) => HTMLElement | undefined): Promise<boolean> {
  // Radix Select opens on pointerdown, other lists on click: send both.
  listTrigger.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, button: 0, pointerType: "mouse" }));
  listTrigger.click();
  const list = await waitFor(() => {
    const id = listTrigger.getAttribute("aria-controls");
    const byId = id ? document.getElementById(id) : null;
    const box = byId ?? [...document.querySelectorAll<HTMLElement>('[role="listbox"]')].at(-1) ?? null;
    return box?.querySelector('[role="option"]') ? box : null;
  }, 1500);
  const opt = list && pick([...list.querySelectorAll<HTMLElement>('[role="option"]')]);
  if (!opt) {
    escape();
    return false;
  }
  opt.scrollIntoView({ block: "nearest" });
  for (const type of ["pointerdown", "pointerup"]) opt.dispatchEvent(new PointerEvent(type, { bubbles: true, button: 0, pointerType: "mouse" }));
  opt.click();
  await sleep(150);
  return true;
}

/**
 * Calendars whose caption has year / month lists that aren't native selects (a button showing "1990",
 * one showing "October"): pick the year, then the month by its position in the list.
 */
async function pickCaptionLists(pop: HTMLElement, want: Date): Promise<void> {
  const lists = () => [...pop.querySelectorAll<HTMLElement>('button[role="combobox"], [aria-haspopup="listbox"]')];
  const year = lists().find((t) => /^\d{4}$/.test(textOf(t)));
  if (year) await pickFromList(year, (opts) => opts.find((o) => textOf(o) === String(want.getFullYear())));
  const month = lists().find((t) => /^[\p{L}.]+$/u.test(textOf(t)));
  if (month) await pickFromList(month, (opts) => (opts.length === 12 ? opts[want.getMonth()] : undefined));
}

/**
 * Selects a date in a react-day-picker popover: month/year dropdowns when it has them, else month steps.
 * Returns "" on success, else why it couldn't (shown in the field's tooltip).
 */
async function chooseDate(trigger: HTMLButtonElement, iso: string): Promise<string> {
  const target = parseIsoDate(iso);
  if (target === null) return "التاريخ المحفوظ ماشي صالح";
  const opened = await openPicker(trigger, (p) => !!p.querySelector("button[data-day]"));
  if (!opened) return "التقويم ما تحلّش";
  // Looked up on every use: a calendar may rebuild its popover container when the month changes.
  const pop = () => popoverOf(trigger) ?? opened;
  const want = new Date(target);
  const inMonth = () => [...pop().querySelectorAll<HTMLButtonElement>("button[data-day]")].filter((b) => !b.closest('[data-outside="true"]'));
  const dayBtn = () => inMonth().find((b) => dayTime(b) === target && !b.disabled);
  const isMonthSelect = (sel: HTMLSelectElement) => sel.options.length === 12 && [...sel.options].every((o, i) => o.value === String(i));

  // Year first: changing it can rebuild the month list (e.g. months after an expiry limit).
  for (const sel of pop().querySelectorAll("select")) {
    if (!isMonthSelect(sel) && [...sel.options].some((o) => o.value === String(want.getFullYear()))) setNativeValue(sel, String(want.getFullYear()));
  }
  await sleep(120);
  for (const sel of pop().querySelectorAll("select")) if (isMonthSelect(sel)) setNativeValue(sel, String(want.getMonth()));
  await sleep(120);
  if (!dayBtn()) await pickCaptionLists(pop(), want);

  // Last resort, month by month: each click waits for the month to change instead of a fixed delay,
  // so a date of birth decades back (hundreds of steps) takes seconds, not minutes.
  const shownMonth = () => {
    const first = inMonth()[0];
    return first ? dayTime(first) : 0;
  };
  let why = "";
  for (let i = 0; i < MAX_MONTH_STEPS && !dayBtn(); i++) {
    const before = shownMonth();
    if (!before || trigger.getAttribute("aria-expanded") !== "true") {
      why = "التقويم تسدّ ولا ما تقراش";
      break;
    }
    const nav = navButtonIn(pop(), before < target ? "next" : "prev");
    // The site limits how far back/forward this calendar goes (e.g. no issue date in the future).
    if (isOff(nav)) {
      why = "الموقع ما كيقبلش هاد التاريخ فهاد الخانة (برا المجال ديال التقويم)";
      break;
    }
    nav!.click();
    if (!(await waitFor(() => shownMonth() !== before, 1500, 8))) {
      why = "التقويم ما تحرّكش";
      break;
    }
  }

  const day = dayBtn();
  if (!day && !why) {
    const disabled = inMonth().some((b) => dayTime(b) === target && b.disabled);
    why = disabled ? "هاد النهار مسدود فالتقويم ديال الموقع" : "ما لقيتش هاد النهار فالتقويم";
  }
  day?.click();
  if (day) await waitFor(() => shownDate(trigger) === target, 1500);
  await closePicker(trigger);
  return shownDate(trigger) === target ? "" : why || "التقويم ما قبلش الاختيار";
}

/** Fills one picker; returns the outcome for the report, or null when the picker isn't one we handle. */
async function fillPicker(
  trigger: HTMLButtonElement,
  profile: Profile,
  overwrite: boolean,
): Promise<{ label: string; ok: boolean; missing?: boolean; why?: string } | null> {
  const desc = describe(trigger);
  const isDate = trigger.getAttribute("aria-haspopup") === "dialog";

  const key = PASSPORT_TYPE_RE.test(desc) ? "passportType" : classifyField(desc);
  if (!key) return null;
  const value = fieldValue(profile, key);
  const label = PROFILE_LABELS[key];
  if (isDate !== DATE_KEYS.has(key)) return null;
  if (isDate ? !isDateEmpty(trigger) : isComboSet(trigger)) {
    if (!overwrite) return null;
  }
  if (!value) return { label, ok: false, missing: true };
  if (!isDate) return { label, ok: await chooseOption(trigger, (os) => matchOption(os, key, value), value) };
  // A date the picker refused is shown in full (and why) so the user can pick it by hand.
  const why = await chooseDate(trigger, value);
  return why ? { label: `${label}: ${value}`, ok: false, why } : { label, ok: true };
}

export async function fillForm(profile: Profile, opts: { overwrite?: boolean } = {}): Promise<FillReport> {
  ensureStyle();
  const filled: string[] = [];
  const check: string[] = [];
  const kept: string[] = [];
  const missing: string[] = [];
  const signup = onSignupPage();

  for (const el of fillableControls()) {
    unmark(el);
    const key = classifyField(describe(el));
    if (!key) continue;
    const value = fieldValue(profile, key);
    const label = PROFILE_LABELS[key];
    if (!value) {
      if (!hasValue(el)) {
        mark(el, false, MISSING_TIP);
        missing.push(label);
      }
      continue;
    }
    if (hasValue(el) && !opts.overwrite) {
      kept.push(label); // never clobber what the user typed
      continue;
    }
    const ok = fillControl(el, key, value);
    mark(el, ok, ok ? "" : FAILED_TIP);
    (ok ? filled : check).push(label);
  }

  // One popover at a time, in page order: each closes before the next opens.
  for (const trigger of pickerTriggers()) {
    unmark(trigger);
    const r = await fillPicker(trigger, profile, !!opts.overwrite);
    if (!r) continue;
    mark(trigger, r.ok, r.missing ? MISSING_TIP : r.ok ? "" : r.why ? `BLS Helper: ${r.why}. ${r.label}` : FAILED_TIP);
    (r.missing ? missing : r.ok ? filled : check).push(r.label);
  }

  // Choice fields shown as radio groups (sex, marital status, purpose, entries...).
  for (const radios of radioGroups().values()) {
    const key = classifyField(groupLabel(radios));
    const value = key && CHOICE_KEYS.has(key) ? fieldValue(profile, key) : "";
    if (!key || !value || radios.some((r) => r.checked)) continue;
    const i = matchOption(
      radios.map((r) => ({ text: [...(r.labels ?? [])].map(textOf).join(" "), value: r.value })),
      key,
      value,
    );
    if (i >= 0) {
      radios[i]!.click();
      filled.push(PROFILE_LABELS[key]);
    } else check.push(PROFILE_LABELS[key]);
  }

  // Consent and "details match my passport" are the user's own statements: never ticked for them.
  const consent = [...document.querySelectorAll<HTMLElement>('form [role="checkbox"][aria-checked="false"], form input[type="checkbox"]:not(:checked)')]
    .filter(visible);
  if (signup && consent.length) {
    for (const c of consent) mark(c, false, "BLS Helper: هادي تصريح ديالك، علّمها بيدك");
    check.push("خانة الموافقة: علّمها بيدك");
  }

  const first = document.querySelector<HTMLElement>(".bls-check") ?? document.querySelector<HTMLElement>(".bls-filled");
  first?.scrollIntoView({ block: "center", behavior: "smooth" });
  return { filled, check, missing, kept };
}

/**
 * Changes when a wizard moves to its next step (different fields on screen). Only fields inside the
 * form count: an open picker's popover (portalled outside it) must not look like a new step.
 */
export function formSignature(): string {
  return [...fillableControls(), ...pickerTriggers()]
    .filter((el) => el.closest("form"))
    .map((el) => el.id || (el as HTMLInputElement).name || el.tagName)
    .join(",");
}

/** Field list (no values) for the diagnostics copy, to tune detection on real BLS forms. */
export function describeForm(): Array<Record<string, string>> {
  return [
    ...fillableControls().map((el) => ({
      tag: el.tagName.toLowerCase() + (el instanceof HTMLInputElement ? `:${el.type}` : ""),
      descriptor: describe(el).slice(0, 120),
      detected: classifyField(describe(el)) ?? "-",
      ...(el instanceof HTMLSelectElement ? { options: [...el.options].slice(0, 6).map((o) => o.text).join(" | ") } : {}),
    })),
    ...pickerTriggers().map((b) => ({
      tag: `picker:${b.getAttribute("aria-haspopup")}`,
      descriptor: describe(b).slice(0, 120),
      detected: PASSPORT_TYPE_RE.test(describe(b)) ? "passportType" : (classifyField(describe(b)) ?? "-"),
    })),
  ];
}
