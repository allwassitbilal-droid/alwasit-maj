// Builds the BLS page script (BLS Helper's, with agence.ts/storage.ts as the bridge) into ../bls/.
// Run from this folder: node build.mjs   (esbuild is taken from BLS Helper's node_modules if not here)
import { createRequire } from "node:module";
import { existsSync } from "node:fs";

const LOCAL = new URL("./node_modules/esbuild/", import.meta.url);
const HELPER = "C:/Users/ASUS/Desktop/bilal toop/BLS Helper 3.11.0/package.json";
const require = createRequire(existsSync(LOCAL) ? new URL("./package.json", import.meta.url) : HELPER);
const { build } = require("esbuild");

await build({
  entryPoints: { content: "src/content/index.ts", offscreen: "src/offscreen/index.ts", peek: "src/page/peek.ts" },
  outdir: "../bls",
  bundle: true,
  format: "iife",
  platform: "browser",
  target: "chrome120",
  minify: true,
  logLevel: "info",
});
