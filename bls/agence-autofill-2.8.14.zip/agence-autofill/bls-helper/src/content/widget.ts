// Toolbar across the top of BLS pages: status, start/stop, and the settings used day to day (date range,
// check interval, slot choice, auto switches, Telegram), saved straight to storage. Lives in a closed
// shadow root so the site's CSS can't touch it (and ours can't leak into the site). The page is pushed
// down by the bar's height, so nothing of BLS hides under it.
import { askBackground, sendToBackground, type TelegramReply } from "../shared/messages";
import { phaseLabel, secondsUntil } from "../shared/schedule";
import { LIMITS, normalizeSettings, type Settings } from "../shared/settings";
import { PRESETS, presetRange, type PresetId } from "../shared/presets";
import { activeProfile, type Profiles } from "../shared/profiles";
import { loadProfiles, onProfilesChanged, saveSettings } from "../shared/storage";
import { fillableControls, pickerTriggers } from "./autofill";
import { contextAlive } from "./util";
import type { Watcher } from "./watcher";

const COLLAPSED_KEY = "blsWidgetCollapsed";
const MORE_KEY = "blsWidgetMore";
const THEME_KEY = "blsWidgetTheme";
const PAGE_STYLE_ID = "bls-toolbar-offset";

const CSS = `
:host { all: initial; }
.bar { position: fixed; top: 0; left: 0; right: 0; z-index: 2147483646; direction: ltr;
  font: 12.5px/1.3 system-ui, "Segoe UI", Tahoma, sans-serif; color: var(--fg);
  background: var(--bg); border-bottom: 1px solid var(--line); box-shadow: 0 4px 16px rgba(0,0,0,.25);
  padding: 6px 10px; display: grid; gap: 6px; }
.bar.dark { --bg: #0f1d2b; --fg: #e6edf3; --muted: #8fa3b5; --line: #22384d; --field: #16283a; --field-line: #2a4560; }
.bar.light { --bg: #f4f7fa; --fg: #14202b; --muted: #5b6b7a; --line: #d3dde6; --field: #fff; --field-line: #c3d0dc; }
.row { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.brand { font-weight: 800; color: #4fc3f7; letter-spacing: .5px; margin-right: 2px; }
.dot { width: 9px; height: 9px; border-radius: 50%; background: #6b7280; flex: none; }
.dot.run { background: #5b8cc4; animation: pulse 1.6s infinite; }
.dot.ok { background: #3cc58a; } .dot.warn { background: #f0a24a; } .dot.err { background: #ef4444; }
@keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(91,140,196,.7); } 100% { box-shadow: 0 0 0 8px rgba(91,140,196,0); } }
.status { flex: 1 1 220px; min-width: 120px; direction: rtl; text-align: right; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.status.ok { color: #3cc58a; } .status.warn { color: #f0a24a; } .status.err { color: #f87171; }
.btn { all: unset; cursor: pointer; padding: 5px 11px; border-radius: 999px; font-weight: 600; white-space: nowrap;
  background: #2e5784; color: #fff; box-shadow: inset 0 0 0 1px rgba(255,255,255,.08); }
.btn:hover { filter: brightness(1.15); }
.btn:disabled { opacity: .45; cursor: default; filter: none; }
.btn.go { background: #1f8f5a; } .btn.stop { background: #b4483e; } .btn.fill { background: #3a6aa0; }
.btn.ghost { background: transparent; color: var(--fg); box-shadow: inset 0 0 0 1px var(--field-line); }
.tog { all: unset; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; padding: 5px 10px; border-radius: 999px;
  font-weight: 600; background: var(--field); box-shadow: inset 0 0 0 1px var(--field-line); white-space: nowrap; }
.tog::before { content: ""; width: 8px; height: 8px; border-radius: 50%; background: #6b7280; }
.tog[aria-pressed="true"] { background: #17603f; color: #eafff4; box-shadow: none; }
.tog[aria-pressed="true"]::before { background: #6ee7a8; }
.tog:disabled { opacity: .45; cursor: default; }
.field { display: inline-flex; align-items: center; gap: 4px; padding: 2px 4px 2px 9px; border-radius: 8px;
  background: var(--field); box-shadow: inset 0 0 0 1px var(--field-line); color: var(--muted); white-space: nowrap; }
.field input, .field select { all: unset; color: var(--fg); padding: 3px 4px; font: inherit; color-scheme: var(--scheme, dark); }
.bar.light .field input, .bar.light .field select { --scheme: light; }
.field input[type="number"] { width: 46px; }
.field input.times { width: 96px; }
.field select option { color: #14202b; }
.chip { padding: 3px 8px; border-radius: 999px; background: var(--field); color: var(--muted); font-size: 11.5px; white-space: nowrap; }
.chip:empty { display: none; } .chip.lag { color: #f0a24a; }
.icon { all: unset; cursor: pointer; width: 26px; height: 26px; display: grid; place-items: center; border-radius: 7px; color: var(--muted); }
.icon:hover, .icon[aria-pressed="true"] { background: var(--field); color: var(--fg); }
.spacer { flex: 1; }
/* Folded bar: just a small arrow tab at the top; its color says the state (blue = watching), hover shows the status. */
.pill { all: unset; cursor: pointer; position: fixed; top: 0; left: 50%; transform: translateX(-50%); z-index: 2147483646;
  display: grid; place-items: center; width: 34px; height: 16px; border-radius: 0 0 9px 9px;
  font: 700 11px/1 system-ui, sans-serif; background: #0f1d2b; color: #8fa3b5; box-shadow: 0 3px 10px rgba(0,0,0,.3); opacity: .75; }
.pill:hover { opacity: 1; height: 20px; color: #e6edf3; }
.pill.run { color: #7fb2ea; } .pill.ok { color: #3cc58a; } .pill.warn { color: #f0a24a; } .pill.err { color: #ef4444; }
.fab { all: unset; cursor: pointer; position: fixed; bottom: 22px; left: 22px; z-index: 2147483646; direction: rtl;
  display: flex; align-items: center; gap: 8px; padding: 12px 18px; border-radius: 999px;
  font: 700 14px system-ui, "Segoe UI", Tahoma, sans-serif; color: #fff;
  background: linear-gradient(135deg, #d4ae46, #a68528); box-shadow: 0 8px 24px rgba(166,133,40,.5); }
.fab:hover { filter: brightness(1.08); }
.fab:disabled { opacity: .7; cursor: default; }
.fab small { font-weight: 500; opacity: .9; }
[hidden] { display: none !important; }
`;

const HTML = `
<div class="bar dark" part="bar">
  <div class="row">
    <span class="brand">BLS</span>
    <span class="dot"></span>
    <button class="btn go" data-act="toggle"></button>
    <button class="tog" data-set="enabled" title="كل الأتمتة (الدخول، التنقل، المراقبة فوقت الذروة)">Auto</button>
    <label class="field" title="اختيار سريع ديال التواريخ">📅
      <select data-act="preset"><option value="">Période…</option>${PRESETS.map((p) => `<option value="${p.id}">${p.label}</option>`).join("")}</select></label>
    <label class="field" title="من هاد النهار (فارغ = بلا حد)">Du <input type="date" data-set="filter.from"></label>
    <label class="field" title="حتى لهاد النهار (فارغ = بلا حد)">Au <input type="date" data-set="filter.to"></label>
    <label class="field" title="شحال من ثانية بين كل فحص (${LIMITS.intervalSec[0]}–${LIMITS.intervalSec[1]})">Refresh(s)
      <input type="number" data-set="intervalSec" min="${LIMITS.intervalSec[0]}" max="${LIMITS.intervalSec[1]}"></label>
    <label class="field" title="فصفحة الدخول: شحال من ثانية بين كل ضغطة على Login">Login(s)
      <select data-set="loginRetrySec">${[1, 2, 3, 5, 10, 20, 30].map((n) => `<option value="${n}">${n}</option>`).join("")}</select></label>
    <button class="btn fill" data-act="fill">📝 Remplir</button>
    <span class="chip" data-k="next"></span>
    <span class="status"></span>
    <button class="icon" data-act="more" title="خيارات أكثر">⋯</button>
    <button class="icon" data-act="theme" title="فاتح / غامق">🌙</button>
    <button class="icon" data-act="collapse" title="تصغير">▴</button>
  </div>
  <div class="row" data-k="more">
    <label class="field" title="شحال من شهر نفحص">Mois <input type="number" data-set="months" min="${LIMITS.months[0]}" max="${LIMITS.months[1]}"></label>
    <label class="field" title="أشمن نهار نختار">Jour
      <select data-set="dayPick"><option value="earliest">Premier</option><option value="latest">Dernier</option></select></label>
    <label class="field" title="أشمن وقت نختار فالنهار">Créneau
      <select data-set="slotPick"><option value="earliest">Premier</option><option value="latest">Dernier</option><option value="random">Aléatoire</option></select></label>
    <button class="tog" data-set="autoLogin" title="يدخل للحساب ويعاود يدخل إلا خرجات الجلسة">Relogin</button>
    <button class="tog" data-set="autoNav" title="يمشي بوحدو لصفحة التواريخ">Nav auto</button>
    <button class="tog" data-set="autoPrepare" title="يختار النهار والوقت؛ نتا اللي كتأكد">Préparer</button>
    <button class="tog" data-set="autoConfirm" title="ملي يلقى نهار بين Du و Au: يختار الوقت ويضغط «تأكيد الموعد» بوحدو (خاص Préparer يكون مشعول)">Réserver auto</button>
    <button class="tog" data-set="queue" title="من بعد ما يتريزيرفا الكليان: يدوز بوحدو للكليان الواجد ⭐ اللي موراه (يبدل الكونط ويقلب ليه)">File ⭐</button>
    <button class="tog" data-set="peak.enabled" title="فحص أسرع فأوقات الذروة">Pics</button>
    <label class="field" title="ساعات الذروة، مفروقين بفاصلة: 09:00, 15:00">⏱ <input type="text" class="times" data-set="peak.times" placeholder="09:00, 15:00"></label>
    <label class="field" title="يبدا قبل الساعة بشحال من دقيقة">Avant(min) <input type="number" data-set="peak.leadMin" min="${LIMITS.leadMin[0]}" max="${LIMITS.leadMin[1]}"></label>
    <label class="field" title="شحال من دقيقة تبقى الذروة">Durée(min) <input type="number" data-set="peak.durationMin" min="${LIMITS.durationMin[0]}" max="${LIMITS.durationMin[1]}"></label>
    <label class="field" title="فوقت الذروة: كل شحال من ثانية يفحص">Pics(s) <input type="number" data-set="peak.intervalSec" min="${LIMITS.peakIntervalSec[0]}" max="${LIMITS.peakIntervalSec[1]}"></label>
    <button class="tog" data-set="telegram.enabled" title="تنبيه فتيليغرام ملي يبان موعد">Telegram</button>
    <button class="btn ghost" data-act="tgtest" title="صيفط رسالة تجربة">Test TG</button>
    <span class="chip" data-k="checks"></span><span class="chip" data-k="peak"></span><span class="chip lag" data-k="lag"></span>
    <span class="spacer"></span>
    <button class="btn ghost" data-act="options">⚙ Paramètres</button>
  </div>
</div>
<button class="pill" data-act="expand" title="BLS">▼</button>
<button class="fab" data-act="fill" title="عبّي هاد الاستمارة بالمعلومات المحفوظة" hidden>📝 <span>عبّي المعلومات</span><small data-k="who"></small></button>`;

function stored(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

// Agence Autofill: the site's localStorage is wiped at every client switch (sign-out), so the bar's own
// choices (folded ⋯, ▴, theme) are also kept in the extension's storage, which survives it.
const UI_KEY = "blsWidgetUi";

function store(key: string, v: string): void {
  try {
    localStorage.setItem(key, v);
  } catch {
    // storage blocked: the copy below still remembers
  }
  try {
    void chrome.storage.local.get(UI_KEY).then((r) => {
      const ui = (r[UI_KEY] as Record<string, string> | undefined) ?? {};
      return chrome.storage.local.set({ [UI_KEY]: { ...ui, [key]: v } });
    }).catch(() => {});
  } catch {
    // extension reloaded: this page script is orphaned
  }
}

/** The bar's choices kept by the extension (see store). */
async function storedUi(): Promise<Record<string, string>> {
  try {
    return ((await chrome.storage.local.get(UI_KEY))[UI_KEY] as Record<string, string> | undefined) ?? {};
  } catch {
    return {};
  }
}

/** A page with this many fillable fields (and no calendar) is treated as a form page. */
const FORM_MIN_FIELDS = 3;

/** Reads a dotted path ("filter.from") of the settings. */
function getPath(s: Settings, path: string): unknown {
  return path.split(".").reduce<unknown>((o, k) => (o as Record<string, unknown>)?.[k], s);
}

/** A copy of the settings with one dotted path changed, validated like the options page does. */
function withPath(s: Settings, path: string, value: unknown): Settings {
  const copy = structuredClone(s) as unknown as Record<string, unknown>;
  const keys = path.split(".");
  const last = keys.pop()!;
  const parent = keys.reduce((o, k) => o[k] as Record<string, unknown>, copy);
  parent[last] = value;
  return normalizeSettings(copy);
}

/** Pushes the BLS app down by the bar's height (its root fills the viewport, so shrink it too). */
function offsetPage(px: number): void {
  let st = document.getElementById(PAGE_STYLE_ID);
  if (!st) {
    st = document.createElement("style");
    st.id = PAGE_STYLE_ID;
    document.head.appendChild(st);
  }
  // Full-screen dialogs (the slot picker is a bottom sheet 100dvh tall) are fixed to the viewport, outside
  // #root: shorten them too, so their header (Back, close) isn't under the bar.
  st.textContent = px
    ? `html{scroll-padding-top:${px}px}#root{padding-top:${px}px}#root>.h-dvh{height:calc(100dvh - ${px}px)!important}` +
      `[role="dialog"][class*="100dvh"]{height:calc(100dvh - ${px}px)!important;max-height:calc(100dvh - ${px}px)!important;top:auto!important}` +
      `[role="dialog"]{max-height:calc(100dvh - ${px}px)}`
    : "";
}

export function mountWidget(watcher: Watcher, actions: { onFill: () => void }): void {
  const host = document.createElement("bls-helper-widget");
  const root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `<style>${CSS}</style>${HTML}`;

  const q = <T extends Element>(sel: string) => root.querySelector(sel) as T;
  const bar = q<HTMLElement>(".bar");
  const pill = q<HTMLElement>(".pill");
  const fab = q<HTMLButtonElement>(".fab");
  const status = q<HTMLElement>(".status");
  const toggle = q<HTMLButtonElement>('[data-act="toggle"]');
  const fillBtn = q<HTMLButtonElement>('[data-act="fill"]');
  const tgBtn = q<HTMLButtonElement>('[data-act="tgtest"]');
  const chip = (k: string) => q<HTMLElement>(`[data-k="${k}"]`);
  const dots = [...root.querySelectorAll<HTMLElement>(".dot")];
  const toggles = [...root.querySelectorAll<HTMLButtonElement>("button[data-set]")];
  const fields = [...root.querySelectorAll<HTMLInputElement | HTMLSelectElement>("input[data-set], select[data-set]")];

  const moreRow = q<HTMLElement>('[data-k="more"]');
  const moreBtn = q<HTMLButtonElement>('[data-act="more"]');
  const presetSel = q<HTMLSelectElement>('[data-act="preset"]');

  // Agence Autofill: folded to its arrow by default; ▼ brings the bar out, ▴ puts it away again.
  let collapsed = stored(COLLAPSED_KEY) !== "0";
  // The second row (peak hours, Relogin, Telegram…) shows until folded with ⋯ (Agence Autofill: open by default).
  let showMore = stored(MORE_KEY) !== "0";
  let flash: { text: string; tone: string; until: number } | null = null;
  bar.className = `bar ${stored(THEME_KEY) === "light" ? "light" : "dark"}`;
  // After a client switch the site's copy is gone: take the extension's, which wins.
  void storedUi().then((ui) => {
    if (ui[COLLAPSED_KEY]) collapsed = ui[COLLAPSED_KEY] === "1";
    if (ui[MORE_KEY]) showMore = ui[MORE_KEY] !== "0";
    if (ui[THEME_KEY]) bar.className = `bar ${ui[THEME_KEY] === "light" ? "light" : "dark"}`;
    render();
  });

  const save = (path: string, value: unknown) => void saveSettings(withPath(watcher.currentSettings, path, value));

  /** Settings controls follow storage, except the field being edited right now. */
  const renderSettings = () => {
    const s = watcher.currentSettings;
    for (const t of toggles) t.setAttribute("aria-pressed", String(!!getPath(s, t.dataset.set!)));
    const tg = s.telegram;
    q<HTMLButtonElement>('[data-set="telegram.enabled"]').disabled = !tg.botToken || !tg.chatId;
    tgBtn.disabled = !tg.botToken || !tg.chatId;
    for (const f of fields) {
      if (root.activeElement === f) continue;
      f.value = String(getPath(s, f.dataset.set!) ?? "");
    }
  };

  const render = () => {
    const s = watcher.state();
    const show = watcher.currentSettings.showWidget;
    const watching = s.onCalendar || s.running;
    const formPage = !watching && fillableControls().length + pickerTriggers().length >= FORM_MIN_FIELDS;

    bar.hidden = !show || collapsed;
    pill.hidden = !show || !collapsed;
    // On any form page, a big button to fill it, whether the bar is shown, folded or turned off.
    fab.hidden = !formPage || !contextAlive();
    offsetPage(bar.hidden ? 0 : bar.offsetHeight);
    if (!show) return;

    // The extension was reloaded or updated: this page's script is cut off and no button can work.
    if (!contextAlive()) {
      for (const d of dots) d.className = "dot err";
      pill.className = "pill err";
      pill.title = "حدّث الصفحة (F5)";
      status.textContent = "⚠️ الإضافة تحدّثات: دير F5 لهاد الصفحة باش ترجع تخدم";
      status.className = "status err";
      for (const b of root.querySelectorAll<HTMLButtonElement>("button[data-act], button[data-set]")) {
        b.disabled = !["collapse", "expand", "theme", "more"].includes(b.dataset.act ?? "");
      }
      return;
    }

    const dotClass = s.running ? "run" : s.tone !== "info" ? s.tone : "";
    for (const d of dots) d.className = `dot ${dotClass}`;
    const next = s.running && s.nextCheckAt ? `⏱ ${secondsUntil(s.nextCheckAt)}ث` : "";
    pill.className = `pill ${dotClass}`;
    pill.title = `BLS · ${s.running ? next || "كنفحص..." : "متوقف"} — ${s.text}`;
    if (collapsed) return;

    const msg = flash && flash.until > Date.now() ? flash : { text: s.text, tone: s.tone };
    status.textContent = msg.text;
    status.title = msg.text;
    status.className = `status ${msg.tone}`;
    toggle.textContent = s.running ? "⏹ Stop" : "▶ Start";
    toggle.className = s.running ? "btn stop" : "btn go";
    fillBtn.hidden = !formPage;
    moreRow.hidden = !showMore;
    moreBtn.setAttribute("aria-pressed", String(showMore));
    chip("next").textContent = next;
    chip("checks").textContent = s.checks ? `🔎 ${s.checks}` : "";
    chip("peak").textContent = phaseLabel(s.sched);
    chip("lag").textContent = s.running && s.lagSec ? `🐢 +${s.lagSec}ث` : "";
    renderSettings();
  };

  const say = (text: string, tone: string) => {
    flash = { text, tone, until: Date.now() + 6000 };
    render();
  };

  root.addEventListener("click", (e) => {
    const el = (e.target as Element).closest<HTMLElement>("[data-act], button[data-set]");
    if (!el) return;
    if (el.dataset.set) {
      save(el.dataset.set, el.getAttribute("aria-pressed") !== "true");
      return;
    }
    switch (el.dataset.act) {
      case "toggle": {
        const st = watcher.state();
        if (st.running) watcher.stop();
        else if (st.onCalendar) watcher.start();
        // Not on the date page yet: sign in / navigate there, then start (same as the popup's search button).
        else sendToBackground({ type: "openBls" });
        break;
      }
      case "more":
        showMore = !showMore;
        store(MORE_KEY, showMore ? "1" : "0");
        break;
      case "fill":
        actions.onFill();
        break;
      case "options":
        sendToBackground({ type: "openOptions" });
        break;
      case "tgtest":
        say("⏳ كنصيفط رسالة تجربة...", "info");
        void askBackground<TelegramReply>({ type: "telegramTest" }).then((r) =>
          say(r?.ok ? "✅ وصلات رسالة التجربة لتيليغرام" : `❌ تيليغرام: ${r?.error ?? "ما تجاوبش"}`, r?.ok ? "ok" : "err"),
        );
        break;
      case "theme": {
        const light = !bar.classList.contains("light");
        bar.className = `bar ${light ? "light" : "dark"}`;
        store(THEME_KEY, light ? "light" : "dark");
        break;
      }
      case "collapse":
      case "expand":
        collapsed = el.dataset.act === "collapse";
        store(COLLAPSED_KEY, collapsed ? "1" : "0");
        break;
    }
    render();
  });

  presetSel.addEventListener("change", () => {
    const id = presetSel.value as PresetId;
    presetSel.value = "";
    presetSel.blur();
    if (!id) return;
    const { from, to } = presetRange(id);
    const s = watcher.currentSettings;
    void saveSettings({ ...s, filter: { ...s.filter, from, to } });
  });

  for (const f of fields) {
    f.addEventListener("change", () => {
      const path = f.dataset.set!;
      save(path, f instanceof HTMLInputElement && f.type === "number" ? Number(f.value) : f.value);
      f.blur();
    });
    // Keys typed in the bar must not reach the BLS page's shortcuts.
    f.addEventListener("keydown", (e) => e.stopPropagation());
  }

  // While a BLS dialog is open (the slot picker is one), Radix closes it on any pointerdown outside it and
  // pulls focus back into it. The bar is outside: keep its events from reaching the page's document.
  for (const type of ["pointerdown", "mousedown", "touchstart", "focusin", "focusout", "keydown", "wheel"]) {
    host.addEventListener(type, (e) => e.stopPropagation());
  }

  // «Remplir» says who the form is for (the active family member).
  const showWho = (ps: Profiles) => {
    const name = activeProfile(ps).name;
    fillBtn.textContent = ps.list.length > 1 ? `📝 Remplir · ${name}` : "📝 Remplir";
    q<HTMLElement>('[data-k="who"]').textContent = ps.list.length > 1 ? `· ${name}` : "";
    fillBtn.title = `عبّي الاستمارة بالمعلومات ديال «${name}» (بدّل الشخص من اللوحة الجانبية)`;
  };
  void loadProfiles().then(showWho);
  onProfilesChanged(showWho);

  new ResizeObserver(() => offsetPage(bar.hidden ? 0 : bar.offsetHeight)).observe(bar);
  watcher.subscribe(render);
  setInterval(render, 1000); // countdown + calendar/form appearing on SPA navigation
  document.documentElement.appendChild(host);
  render();
}
