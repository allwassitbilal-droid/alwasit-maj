// Shared by the popup (CSV import) and the page filler (label matching).
// Order matters: the first rule that matches wins (e.g. "lieu délivrance" before "délivré").
globalThis.AA_RULES = [
  { key: 'gmail', inc: /e?mail|courriel/, exc: /mailing|postal|parent|employ|societe|company|agence/ },
  { key: 'lieu', inc: /lieu.*(deliv|emis)|placeofissue|issueplace|issuedat|autorite|authority/ },
  { key: 'expire', inc: /expir|validjusqu|validuntil|validite|dateoffin/ },
  { key: 'delivre', inc: /deliv|emission|dateofissue|issuedate|issuedon|issue/ },
  { key: 'passeport', inc: /passeport|passport|numpass|ndepass|travel/ },
  { key: 'naissance', inc: /naissance|birth|dob|nele|datenai/, exc: /lieu|place|pays|country|ville|city/ },
  { key: 'prenom', inc: /prenom|firstname|givenname|fname/ },
  { key: 'nom', inc: /nom|lastname|surname|familyname|lname/, exc: /utilisateur|user|societe|company|agence|pere|mere|nombre|denomin/ },
  { key: 'mobile', inc: /mobile|telephone|^tel|phone|gsm|portable/ },
];

globalThis.AA_DATES = ['naissance', 'delivre', 'expire'];

globalThis.AA_norm = s => (s || '').toString().normalize('NFD').replace(/[̀-ͯ]/g, '')
  .toLowerCase().replace(/[^a-z0-9]/g, '');

globalThis.AA_match = text => {
  const n = AA_norm(text);
  if (!n) return null;
  for (const r of AA_RULES) if (r.inc.test(n) && !(r.exc && r.exc.test(n))) return r.key;
  return null;
};

// Stamp for a client created on this PC: who (the ☁ login) and which PC. bls.js sends the
// «nouveau client» Telegram from this PC only, once (sent: true then travels to the team).
globalThis.AA_newMeta = async () => {
  const r = await chrome.storage.local.get(['deviceId', 'syncStatus']);
  let pc = r.deviceId;
  if (!pc) { pc = crypto.randomUUID(); await chrome.storage.local.set({ deviceId: pc }); }
  return { by: r.syncStatus?.email || '', pc, at: Date.now(), sent: false };
};

// Accepts "2030-05-14", "14/05/2030", "14-05-2030", "14.05.2030" -> "2030-05-14"
globalThis.AA_toIso = s => {
  s = (s || '').trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const m = s.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);
  return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : '';
};
