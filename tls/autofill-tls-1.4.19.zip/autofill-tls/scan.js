const FIELDS = [
  ['gmail', '📧 Gmail', 'email'], ['code', '🔑 Code Gmail'], ['prenom', 'Prénom'], ['nom', 'Nom'], ['naissance', 'Naissance', 'date'], ['passeport', 'N° passeport'],
  ['delivre', 'Délivré', 'date'], ['expire', 'Expire', 'date'], ['lieu', 'Lieu délivrance'], ['mobile', 'Mobile'],
];
const $ = s => document.querySelector(s);
let queue = Promise.resolve(), scanFamily = null;

function el(tag, props = {}, ...kids) {
  const e = Object.assign(document.createElement(tag), props);
  e.append(...kids.filter(k => k != null));
  return e;
}

function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = bad ? 'show bad' : 'show';
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (t.className = ''), 2500);
}

// OCR: ocr.js (AAOcr), shared with the panel.
let onProgress = () => {};
const readPassport = (file, setStatus) => AAOcr.readPassport(file, setStatus, m => onProgress(m));

function addFiles(files) {
  const imgs = [...files].filter(f => f.type.startsWith('image/'));
  if (!imgs.length) return toast('Choisissez une image (JPG, PNG)', true);
  for (const f of imgs) {
    const card = makeCard(f);
    queue = queue.then(() => processCard(card, f));
  }
}

function makeCard(file) {
  const status = el('div', { className: 'status', textContent: 'En attente…' });
  const progress = el('progress', { max: 1, value: 0 });
  const form = el('form', {},
    el('div', { className: 'grid' }, ...FIELDS.map(([k, label, type]) =>
      el('label', {}, label, el('input', { name: k, type: type || 'text' })))),
    el('label', { className: 'wide', style: 'margin-top:8px;color:var(--muted);font-size:11px;display:flex;flex-direction:column;gap:3px' },
      'Champs en plus (nom du champ = valeur)', el('textarea', { name: 'extra', rows: 2 })),
    el('div', { className: 'actions' },
      el('span', { className: 'grow' }),
      el('button', { type: 'button', textContent: 'Retirer', onclick: () => { card.remove(); summary(); } }),
      el('button', { type: 'submit', className: 'primary', textContent: 'Enregistrer' })));
  const card = el('div', { className: 'card' },
    el('div', {}, el('img', { src: URL.createObjectURL(file) }), progress, status), form);
  form.onsubmit = async e => { e.preventDefault(); if (await saveCards([card])) toast('Compte enregistré'); };
  card._status = status;
  card._progress = progress;
  card._form = form;
  card._file = file;
  $('#cards').prepend(card);
  summary();
  return card;
}

async function processCard(card, file) {
  const setStatus = t => { card._status.textContent = t; };
  onProgress = m => { if (m.status === 'recognizing text') card._progress.value = m.progress; };
  try {
    const r = await readPassport(file, setStatus);
    card._progress.remove();
    if (!r) {
      card._status.replaceChildren(el('span', { className: 'bad', textContent: '✗ Lignes MRZ introuvables. Reprenez une photo plus nette ou remplissez à la main.' }));
      return;
    }
    const f = card._form.elements;
    for (const [k] of FIELDS) if (r[k]) f[k].value = r[k];
    const extra = [r.nationalite && `Nationalité = ${r.nationalite}`, r.sexe && `Sexe = ${r.sexe}`].filter(Boolean);
    f.extra.value = extra.join('\n');
    const mark = (ok, label) => el('span', { className: ok ? 'ok' : 'bad', textContent: `${ok ? '✓' : '✗'} ${label}  ` });
    card._status.replaceChildren(
      mark(r.checks.passeport, 'N° passeport'), mark(r.checks.naissance, 'Naissance'), mark(r.checks.expire, 'Expire'),
      el('br'), mark(r.delivre, r.delivre ? 'Délivré lu sur la page : vérifiez-le' : 'Délivré non lu : à saisir'),
      mark(r.lieu, r.lieu ? 'Lieu lu : vérifiez-le' : 'Lieu non lu : à saisir'),
      el('br'), 'Vérifiez les noms avant d\'enregistrer.');
  } catch (e) {
    card._progress.remove();
    card._status.replaceChildren(el('span', { className: 'bad', textContent: 'Erreur : ' + e.message }));
  }
  summary();
}

async function saveCards(cards) {
  const { clients = [] } = await chrome.storage.local.get('clients');
  let n = 0;
  const photos = [];
  for (const card of cards) {
    const f = card._form.elements;
    const data = Object.fromEntries([...FIELDS.map(([k]) => k), 'extra'].map(k => [k, f[k].value.trim()]));
    if (!data.nom && !data.prenom) continue;
    const dossier = $('#dossier').value.trim();
    if (dossier) data.dossier = dossier;
    if ($('#famille').checked) {
      // One family for everything saved on this page while the box is ticked; the first one is the head.
      const first = !scanFamily;
      scanFamily ||= crypto.randomUUID();
      data.famille = scanFamily;
      if (first) data.lien = 'principal';
    }
    const same = data.passeport && clients.find(c => c.passeport === data.passeport);
    const id = same?.id || crypto.randomUUID();
    // Re-scan of a known passport: empty boxes keep what the account already had (Gmail, code…).
    if (same) Object.assign(same, Object.fromEntries(Object.entries(data).filter(([, v]) => v)));
    else clients.push({ id, ...data, ajout: await AA_newMeta() });
    photos.push([id, card._file]);
    card.classList.add('saved');
    n++;
  }
  await chrome.storage.local.set({ clients });
  // The scanned photo also goes into the client's files (🛂 Passeport) when connected.
  for (const [id, file] of photos) AAFiles.upload(id, 'passeport', file).catch(() => {});
  summary();
  return n;
}

function summary() {
  const cards = [...document.querySelectorAll('.card')];
  const saved = cards.filter(c => c.classList.contains('saved')).length;
  $('#summary').textContent = cards.length ? `${cards.length} photo(s) · ${saved} enregistrée(s)` : '';
  $('#saveAll').hidden = cards.length < 2;
}

$('#saveAll').onclick = async () => {
  const n = await saveCards([...document.querySelectorAll('.card:not(.saved)')]);
  toast(`${n} compte(s) enregistré(s)`);
};
$('#famille').onchange = () => { scanFamily = null; }; // re-ticking starts a new family
$('#drop').onclick = () => $('#file').click();
$('#file').onchange = e => { addFiles(e.target.files); e.target.value = ''; };
$('#drop').ondragover = e => { e.preventDefault(); $('#drop').classList.add('over'); };
$('#drop').ondragleave = () => $('#drop').classList.remove('over');
$('#drop').ondrop = e => { e.preventDefault(); $('#drop').classList.remove('over'); addFiles(e.dataTransfer.files); };
// Folder suggestions, starting with the folder open in the side panel
globalThis.chrome?.storage?.local.get(['clients', 'dossiers', 'folder']).then(r => {
  const names = [...new Set([...(r.dossiers || []), ...(r.clients || []).map(c => c.dossier).filter(Boolean)])];
  $('#dossier-list').replaceChildren(...names.map(n => el('option', { value: n })));
  if (names.includes(r.folder)) $('#dossier').value = r.folder;
});
document.onpaste =e => { if (e.clipboardData.files.length) addFiles(e.clipboardData.files); };
