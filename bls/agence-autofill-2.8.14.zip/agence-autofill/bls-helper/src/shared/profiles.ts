// Family profiles: each family member's applicant details and own BLS account (BLS Morocco books one
// person per account). One member is active at a time: the account signed in, searched for and filled
// for. Pure functions over a plain object; storage.ts persists it.
import { EMPTY_PROFILE, normalizeProfile, type Profile } from "./profile";
import { normalizeAccount, type Account } from "./settings";

export const PROFILES_KEY = "profiles";
/** A household, not a client list: forms are filled one person at a time, by hand. */
export const MAX_PROFILES = 10;

export interface NamedProfile {
  id: string;
  name: string;
  profile: Profile;
  account: Account;
}

export interface Profiles {
  list: NamedProfile[];
  activeId: string;
}

const FIRST_NAME = "أنا";

export const newId = (): string => Math.random().toString(36).slice(2, 10);

/**
 * Valid profiles from storage. Before family profiles there was a single "profile" and "account" key
 * (legacy): they become the first member, so nothing typed before is lost. There is always at least
 * one profile.
 */
export function normalizeProfiles(raw: unknown, legacy?: unknown, legacyAccount?: unknown): Profiles {
  const r = typeof raw === "object" && raw !== null ? (raw as Record<string, unknown>) : {};
  const seen = new Set<string>();
  const list: NamedProfile[] = (Array.isArray(r.list) ? r.list : [])
    .flatMap((p: unknown) => {
      const o = typeof p === "object" && p !== null ? (p as Record<string, unknown>) : null;
      const id = typeof o?.id === "string" && o.id ? o.id : newId();
      if (!o || seen.has(id)) return [];
      seen.add(id);
      const name = typeof o.name === "string" && o.name.trim() ? o.name.trim().slice(0, 30) : FIRST_NAME;
      return [{ id, name, profile: normalizeProfile(o.profile), account: normalizeAccount(o.account) }];
    })
    .slice(0, MAX_PROFILES);
  if (!list.length) {
    list.push({ id: newId(), name: FIRST_NAME, profile: normalizeProfile(legacy ?? EMPTY_PROFILE), account: normalizeAccount(legacyAccount) });
  }
  const activeId = typeof r.activeId === "string" && list.some((p) => p.id === r.activeId) ? r.activeId : list[0]!.id;
  return { list, activeId };
}

export const activeProfile = (ps: Profiles): NamedProfile => ps.list.find((p) => p.id === ps.activeId) ?? ps.list[0]!;

/** Adds an empty member and makes it active; unchanged when the household is full. */
export function addProfile(ps: Profiles, name: string): Profiles {
  if (ps.list.length >= MAX_PROFILES) return ps;
  const p: NamedProfile = {
    id: newId(),
    name: name.trim().slice(0, 30) || `فرد ${ps.list.length + 1}`,
    profile: { ...EMPTY_PROFILE },
    account: normalizeAccount(undefined),
  };
  return { list: [...ps.list, p], activeId: p.id };
}

/** Removes a member (never the last one); the active one moves to the first left. */
export function removeProfile(ps: Profiles, id: string): Profiles {
  if (ps.list.length <= 1) return ps;
  const list = ps.list.filter((p) => p.id !== id);
  return { list, activeId: ps.activeId === id ? list[0]!.id : ps.activeId };
}

export function updateProfile(ps: Profiles, id: string, patch: Partial<Pick<NamedProfile, "name" | "profile" | "account">>): Profiles {
  return {
    ...ps,
    list: ps.list.map((p) =>
      p.id === id
        ? {
            ...p,
            ...(patch.name !== undefined ? { name: patch.name.trim().slice(0, 30) || p.name } : {}),
            ...(patch.profile ? { profile: normalizeProfile(patch.profile) } : {}),
            ...(patch.account ? { account: normalizeAccount(patch.account) } : {}),
          }
        : p,
    ),
  };
}

/**
 * Whether going from one active member to another means signing out of BLS and in with another account.
 * A member without an account also signs out: staying on the previous member's account would book and
 * fill for the wrong person.
 */
export function needsAccountSwitch(before: Profiles, after: Profiles): boolean {
  if (before.activeId === after.activeId) return false;
  const a = activeProfile(before).account.email.toLowerCase();
  const b = activeProfile(after).account.email.toLowerCase();
  return a !== b;
}
