// Every BLS-specific selector lives here, so a site redesign means editing one file.
// The calendar is detected by structure (data-slot / role=grid / day buttons), not only by month text.
import { parseDayAttr, parseTime } from "../shared/slots";
import { CONFIRM_BTN_RE, EMPTY_RE, FACE_RE, NEXT_MONTH_RE, PREV_MONTH_RE } from "./texts";
import { textOf } from "./util";

export { ERR_RE, FOLLOWUP_CONFIRM_RE, OK_RE } from "./texts";

const MONTH_RE = /^[\p{L}.]+,? ?\d{4}$/u;

export const DIALOG_SEL = '[role="dialog"],[role="alertdialog"]';

export interface Slot {
  btn: HTMLButtonElement;
  mins: number;
  text: string;
}

export const isOff = (b: Element | null | undefined): boolean =>
  !b || (b as HTMLButtonElement).disabled || b.getAttribute("aria-disabled") === "true";

/**
 * Whether an element sits in a popover some trigger has open (a form's date picker or a combobox list).
 * Such a calendar is a date of birth or passport date, never the slot calendar.
 */
export function inPopover(e: Element): boolean {
  return [...document.querySelectorAll('[aria-controls][aria-expanded="true"]')].some((t) => !!popoverOf(t)?.contains(e));
}

/** First match outside any open popover. */
const outsidePopover = <T extends Element>(sel: string): T | undefined =>
  [...document.querySelectorAll<T>(sel)].find((e) => !inPopover(e));

export function findCalendar(): Element | null {
  const slot = outsidePopover('[data-slot="calendar"]');
  if (slot) return slot;
  const grid = outsidePopover('[role="grid"]') ?? outsidePopover('td[role="gridcell"], button[data-day]')?.closest("table");
  if (!grid) return null;
  return grid.closest('[data-slot="calendar"]') ?? grid.parentElement?.parentElement ?? grid;
}

export function monthLabel(): Element | null {
  const byText = [...document.querySelectorAll("span")].find((s) => MONTH_RE.test(textOf(s)) && !inPopover(s));
  if (byText) return byText;
  const cal = findCalendar();
  if (!cal) return null;
  return (
    cal.querySelector('[role="status"], [aria-live]') ??
    [...cal.querySelectorAll("span,div,h1,h2,h3,p")].find((e) => {
      const t = textOf(e);
      return !e.children.length && /\d{4}\s*$/.test(t) && t.length < 25;
    }) ??
    null
  );
}

function calendarRoot(): Element | null {
  const label = monthLabel();
  return label?.closest('[data-slot="calendar"]') ?? label?.parentElement?.parentElement ?? findCalendar();
}

const byNavLabel = (scope: ParentNode, kind: "next" | "prev") => {
  const re = kind === "next" ? NEXT_MONTH_RE : PREV_MONTH_RE;
  return [...scope.querySelectorAll<HTMLButtonElement>("button[aria-label]")].find((b) => re.test(b.getAttribute("aria-label")!));
};

/** Month navigation inside one calendar (the booking page's, or a date picker's popover). */
export function navButtonIn(scope: ParentNode, kind: "next" | "prev"): HTMLButtonElement | null {
  const hit = byNavLabel(scope, kind);
  if (hit) return hit;
  const navs = [...scope.querySelectorAll<HTMLButtonElement>("nav button")];
  return navs.length >= 2 ? ((kind === "next" ? navs.at(-1) : navs[0]) ?? null) : null;
}

export function navButton(kind: "next" | "prev"): HTMLButtonElement | null {
  const root = calendarRoot();
  return (root && navButtonIn(root, kind)) ?? byNavLabel(document, kind) ?? null;
}

/** The content of a Radix popover (combobox list or date picker) its trigger opened, if open. */
export const popoverOf = (trigger: Element): HTMLElement | null => {
  const id = trigger.getAttribute("aria-controls");
  return id && trigger.getAttribute("aria-expanded") === "true" ? document.getElementById(id) : null;
};

/** Signup-form pickers: Radix comboboxes (passport type, country) and date-picker triggers. */
export const PICKER_SEL = 'button[role="combobox"][aria-haspopup="listbox"], button[data-slot="popover-trigger"][aria-haspopup="dialog"]';

/**
 * A calendar day button's date (booking calendar or date picker). The cell's ISO data-day comes first;
 * the button's own one is locale-formatted, so its day number (the button text) tells D/M from M/D.
 */
export function dayTime(b: Element): number {
  const cell = b.closest("td[data-day]")?.getAttribute("data-day") ?? "";
  if (/^\d{4}-\d{2}-\d{2}/.test(cell)) return parseDayAttr(cell);
  const dom = Number.parseInt(textOf(b), 10);
  return parseDayAttr(b.getAttribute("data-day"), Number.isNaN(dom) ? undefined : dom);
}

/** Enabled day buttons in the visible month; null when no calendar is on the page. */
export function availableDays(): HTMLButtonElement[] | null {
  const root = calendarRoot();
  if (!root) return null;
  const cells = [...root.querySelectorAll('td[role="gridcell"]')];
  if (cells.length) {
    return cells
      .filter((td) => td.getAttribute("data-disabled") !== "true" && td.getAttribute("data-hidden") !== "true")
      .map((td) => td.querySelector<HTMLButtonElement>("button[data-day]"))
      .filter((b): b is HTMLButtonElement => !!b && !b.disabled);
  }
  if (EMPTY_RE.test(root.textContent ?? "")) return [];
  return [...root.querySelectorAll<HTMLButtonElement>("button")].filter(
    (b) => !isOff(b) && !b.hasAttribute("aria-label") && /^\d{1,2}(\D|$)/.test(textOf(b)),
  );
}

/** Whether a form on the page has text in it (typed or filled): a reload would wipe it. */
export function formTouched(): boolean {
  return [...document.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>("input, textarea")].some(
    (e) =>
      !e.disabled &&
      !e.readOnly &&
      !["hidden", "checkbox", "radio", "submit", "button", "file"].includes(e.type) &&
      e.value.trim() !== "",
  );
}

export const dayLabel =(b: Element): string => b.getAttribute("aria-label") || textOf(b);

export function timeSlots(): Slot[] {
  return [...document.querySelectorAll<HTMLButtonElement>("button")].flatMap((btn) => {
    if (btn.disabled) return [];
    const text = textOf(btn.querySelector('span[dir="ltr"]'));
    const mins = parseTime(text);
    return mins === null ? [] : [{ btn, mins, text }];
  });
}

export const confirmButton = (): HTMLButtonElement | undefined =>
  [...document.querySelectorAll<HTMLButtonElement>("button")].find((b) => !b.disabled && CONFIRM_BTN_RE.test(textOf(b)));

export const isConfirmButton = (el: Element | null | undefined): el is HTMLButtonElement =>
  !!el && el.tagName === "BUTTON" && CONFIRM_BTN_RE.test(textOf(el));

export function faceStep(): boolean {
  const dlg = document.querySelector('[role="dialog"]') as HTMLElement | null;
  return (!!dlg && FACE_RE.test(dlg.innerText)) || FACE_RE.test(document.body.innerText.slice(0, 20000));
}

export const toastText = (): string =>
  [...document.querySelectorAll<HTMLElement>('[data-sonner-toast], [role="alert"], [role="alertdialog"]')]
    .map((x) => x.innerText.replace(/\s+/g, " ").trim())
    .filter(Boolean)
    .join(" | ")
    .slice(0, 160);

export function monthText(): string {
  const l = monthLabel();
  return l ? textOf(l) : findCalendar() ? "التقويم" : "";
}

/** Changes whenever the visible month changes; used to detect navigation finishing. */
export function monthSignature(): string {
  const t = textOf(monthLabel());
  if (t) return t;
  return findCalendar()?.querySelector("button[data-day]")?.getAttribute("data-day") ?? "";
}

export function calendarSummary(): string {
  const root = calendarRoot();
  if (!root) return "";
  const cells = root.querySelectorAll('td[role="gridcell"]').length;
  const empty = EMPTY_RE.test(root.textContent ?? "") || EMPTY_RE.test(document.body.textContent ?? "");
  return ` [${cells} خلية${empty ? "، الموقع كيقول: لا توجد مواعيد" : ""}]`;
}

/** Snapshot of the page structure, copied from the popup to debug selector breakage. */
export function diagnostics(extra: Record<string, unknown>): string {
  const q = (s: string) => document.querySelectorAll(s).length;
  const attrs = (e: Element) =>
    [...e.attributes]
      .filter((a) => a.name !== "class" && a.name !== "style")
      .map((a) => `${a.name}="${a.value.slice(0, 30)}"`)
      .join(" ");
  const monthLike = [...document.querySelectorAll("body *")]
    .filter((e) => !e.children.length && /(19|20)\d{2}/.test(e.textContent ?? "") && textOf(e).length < 30)
    .slice(0, 8)
    .map((e) => `<${e.tagName.toLowerCase()} ${attrs(e)}>${textOf(e)}`);
  const dlg = document.querySelector('[role="dialog"]') as HTMLElement | null;
  return JSON.stringify(
    {
      url: location.pathname,
      iframes: q("iframe"),
      calendarSlot: q('[data-slot="calendar"]'),
      grid: q('[role="grid"]'),
      gridcell: q('[role="gridcell"]'),
      dayButtons: q("button[data-day]"),
      enabledDays: availableDays()?.length ?? 0,
      slots: timeSlots().map((s) => s.text),
      monthLike,
      dialogs: q('[role="dialog"]'),
      dialogText: dlg ? dlg.innerText.replace(/\s+/g, " ").slice(0, 300) : "",
      ...extra,
    },
    null,
    1,
  );
}
