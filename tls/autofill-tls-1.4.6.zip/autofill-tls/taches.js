// «À faire aujourd'hui»: the team's daily to-do, a slim bar at the top of the panel; a click opens the list.
// Two kinds of tasks:
//   - automatic ones, built from the clients (appointment today/tomorrow, account to renew…) by the panel (opts.auto);
//   - tasks someone writes (＋), with a day and optionally a client.
// Ticks and written tasks live in teamSettings.tasks, so with ☁ every PC of the team sees the same list.
// A written task: { id, text, day, clientId?, done?, by, doneBy?, at }. A ticked automatic task: { id: 'auto:…', done, at }.
// A deleted task stays a little while as { id, deleted: true, at } so the deletion reaches the other PCs.
globalThis.AATaches = (() => {
  const local = chrome.storage.local;
  const el = (tag, props = {}, ...kids) => {
    const e = Object.assign(document.createElement(tag), props);
    e.append(...kids.filter(k => k != null && k !== false));
    return e;
  };
  const ymd = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const frShort = iso => (iso ? iso.slice(8, 10) + '/' + iso.slice(5, 7) : '');
  const SHOWN = 4; // rows before «▾ n autres»
  const DAY = 864e5;

  let opts = null, tasks = [], me = '', ui = { folded: false, more: false, done: false, adding: false };
  // Open or folded is remembered on this PC (key «tachesFolded»), so the list stays as the person left it.
  const fold = v => { ui.folded = v; local.set({ tachesFolded: v }); render(); };

  // Old ticks and deletions go away after a while, so the shared row stays small.
  const prune = list => list.filter(t => {
    const age = Date.now() - (t.at || 0);
    if (t.deleted) return age < 30 * DAY;
    if (t.id.startsWith('auto:')) return age < 30 * DAY;
    return !t.done || age < 14 * DAY;
  });

  async function change(fn) {
    const { teamSettings = {} } = await local.get('teamSettings');
    const next = prune(fn([...(teamSettings.tasks || [])]));
    await local.set({ teamSettings: { ...teamSettings, tasks: next } });
  }
  const put = t => change(list => [...list.filter(x => x.id !== t.id), { ...t, at: Date.now() }]);

  // Everything to show, most urgent first.
  function build() {
    const today = ymd();
    const byId = new Map(tasks.map(t => [t.id, t]));
    const clients = opts.clients();
    const clientOf = id => clients.find(c => c.id === id);
    const rows = [];
    for (const a of opts.auto(today)) {
      const id = `auto:${a.key}`;
      const t = byId.get(id);
      rows.push({ ...a, id, auto: true, day: today, done: !!t?.done && !t.deleted, doneBy: t?.doneBy });
    }
    for (const t of tasks) {
      if (t.deleted || t.id.startsWith('auto:')) continue;
      const c = t.clientId ? clientOf(t.clientId) : null;
      rows.push({
        id: t.id, text: t.text, client: c, day: t.day || today, done: !!t.done, doneBy: t.doneBy, by: t.by, icon: '✎',
        rank: t.day < today ? 0 : t.day === today ? 3 : 9, late: !t.done && t.day < today,
      });
    }
    rows.sort((a, b) => a.rank - b.rank || (a.time || '').localeCompare(b.time || '') || a.day.localeCompare(b.day));
    return {
      now: rows.filter(r => !r.done && r.day <= today),
      later: rows.filter(r => !r.done && r.day > today).sort((a, b) => a.day.localeCompare(b.day)),
      done: rows.filter(r => r.done && (r.auto || r.day <= today)),
    };
  }

  const who = email => (email || '').split('@')[0];

  function row(r) {
    const tick = el('button', {
      className: 'tk-box', type: 'button', title: r.done ? 'Remettre à faire' : 'Marquer fait',
      ariaLabel: r.done ? 'Remettre à faire' : 'Marquer fait', textContent: r.done ? '✓' : '',
      onclick: () => {
        const t = tasks.find(x => x.id === r.id) || { id: r.id };
        put(r.done ? { ...t, done: false, doneBy: undefined } : { ...t, done: true, doneBy: me || undefined });
      },
    });
    const meta = [
      r.client ? el('button', {
        className: 'tk-client', type: 'button', title: 'Voir ce client',
        textContent: `${r.client.num != null && r.client.num !== '' ? 'N°' + r.client.num + ' ' : ''}${`${r.client.prenom || ''} ${r.client.nom || ''}`.trim()}`,
        onclick: () => opts.show(r.client),
      }) : null,
      r.late ? el('span', { className: 'tk-late', textContent: `en retard · ${frShort(r.day)}` }) : null,
      !r.late && !r.done && r.day > ymd() ? el('span', { className: 'tk-day', textContent: '📅 ' + frShort(r.day) + (r.day.slice(0, 4) !== ymd().slice(0, 4) ? '/' + r.day.slice(0, 4) : '') }) : null,
      r.done && r.doneBy ? el('span', { textContent: `fait par ${who(r.doneBy)}` }) : null,
      !r.done && r.by ? el('span', { textContent: who(r.by) }) : null,
    ].filter(Boolean);
    return el('li', { className: 'tk' + (r.done ? ' done' : '') + (r.late ? ' late' : '') + (r.auto ? ' auto' : '') },
      tick,
      el('div', { className: 'tk-main' },
        el('div', { className: 'tk-text' }, el('span', { className: 'tk-icon', textContent: r.icon || '•' }), ' ', r.text),
        meta.length ? el('div', { className: 'tk-meta' }, ...meta) : null),
      r.auto ? null : el('button', {
        className: 'tk-del', type: 'button', textContent: '✕', title: 'Supprimer la tâche', ariaLabel: 'Supprimer la tâche',
        onclick: () => put({ id: r.id, deleted: true }),
      }));
  }

  function addForm() {
    const clients = [...opts.clients()].filter(c => !c.archive)
      .sort((a, b) => (+a.num || 1e9) - (+b.num || 1e9) || `${a.prenom}${a.nom}`.localeCompare(`${b.prenom}${b.nom}`));
    const text = el('input', { name: 'text', placeholder: 'Ex : appeler Omar pour les photos', required: true, maxLength: 140, autocomplete: 'off' });
    const day = el('input', { name: 'day', type: 'date', value: ymd(), title: 'Pour quel jour' });
    const who = el('select', { name: 'client', title: 'Client (optionnel)' },
      el('option', { value: '', textContent: 'Client (optionnel)' }),
      ...clients.map(c => el('option', { value: c.id, textContent: `${c.num != null && c.num !== '' ? 'N°' + c.num + ' · ' : ''}${`${c.prenom || ''} ${c.nom || ''}`.trim() || '(sans nom)'}` })));
    const f = el('form', { className: 'tk-add' },
      text,
      el('div', { className: 'tk-add-row' }, day, who),
      el('div', { className: 'tk-add-row' },
        el('button', { type: 'submit', className: 'primary', textContent: 'Ajouter la tâche' }),
        el('button', { type: 'button', textContent: 'Annuler', onclick: () => { ui.adding = false; render(); } })));
    f.onsubmit = e => {
      e.preventDefault();
      const v = text.value.trim();
      if (!v) return;
      ui.adding = false;
      put({ id: 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), text: v, day: day.value || ymd(), clientId: who.value || undefined, by: me || undefined });
    };
    f.onkeydown = e => { if (e.key === 'Escape') { ui.adding = false; render(); } };
    setTimeout(() => text.focus());
    return f;
  }

  function render() {
    const box = document.querySelector('#taches');
    if (!box || !opts) return;
    const { now, later, done } = build();
    const lateN = now.filter(r => r.late).length;
    const head = el('div', { className: 'tk-head' },
      el('button', {
        className: 'tk-title', type: 'button', ariaExpanded: String(!ui.folded),
        title: ui.folded ? 'Afficher les tâches' : '',
        onclick: () => { if (ui.folded) fold(false); },
      }, el('span', { textContent: '📋' }), el('b', { textContent: "À faire aujourd'hui" }),
        el('span', { className: 'tk-count' + (lateN ? ' bad' : now.length ? '' : ' zero'), textContent: String(now.length) }),
        ui.folded ? el('span', { className: 'tk-caret', textContent: '▸' }) : null),
      ui.folded ? null : el('button', {
        className: 'tk-fold', type: 'button', textContent: '▾', title: 'Réduire la liste', ariaLabel: 'Réduire la liste',
        onclick: () => fold(true),
      }),
      ui.folded ? null : el('button', {
        className: 'tk-plus', type: 'button', textContent: '＋', title: 'Nouvelle tâche', ariaLabel: 'Nouvelle tâche',
        onclick: () => { ui.adding = !ui.adding; render(); },
      }));
    const kids = [head];
    if (!ui.folded) {
      if (ui.adding) kids.push(addForm());
      const shown = ui.more ? now : now.slice(0, SHOWN);
      if (now.length) kids.push(el('ul', { className: 'tk-list' }, ...shown.map(row)));
      else if (!ui.adding) kids.push(el('p', { className: 'tk-empty', textContent: 'Rien à faire pour aujourd\'hui. ＋ pour ajouter une tâche.' }));
      const foot = [];
      if (now.length > SHOWN) foot.push(el('button', { type: 'button', textContent: ui.more ? '▴ Moins' : `▾ ${now.length - SHOWN} autre${now.length - SHOWN > 1 ? "s" : ""}`, onclick: () => { ui.more = !ui.more; render(); } }));
      if (done.length) foot.push(el('button', { type: 'button', className: ui.done ? 'on' : '', textContent: `✓ Fait · ${done.length}`, onclick: () => { ui.done = !ui.done; render(); } }));
      if (foot.length) kids.push(el('div', { className: 'tk-foot' }, ...foot));
      // Tasks for a later day are always shown (with their date), however far the date is.
      if (later.length) kids.push(el('div', { className: 'tk-sub' }, `📅 Prochains jours · ${later.length}`), el('ul', { className: 'tk-list' }, ...later.map(row)));
      if (ui.done && done.length) kids.push(el('ul', { className: 'tk-list sub' }, ...done.map(row)));
    }
    // Keep the typing when a colleague's change re-renders the card.
    const typing = box.querySelector('.tk-add');
    if (typing && ui.adding) {
      const keep = kids.find(k => k.classList?.contains('tk-add'));
      if (keep) kids[kids.indexOf(keep)] = typing;
    }
    box.replaceChildren(...kids);
    box.classList.toggle('folded', ui.folded);
  }

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.teamSettings) { tasks = ch.teamSettings.newValue?.tasks || []; render(); }
    if (ch.syncStatus) me = ch.syncStatus.newValue?.email || me;
  });
  // The day changes while the panel stays open: refresh at midnight-ish, every 10 minutes.
  setInterval(() => render(), 10 * 60e3);

  return {
    async init(o) {
      opts = o;
      const r = await local.get(['teamSettings', 'syncStatus']);
      tasks = r.teamSettings?.tasks || [];
      me = r.syncStatus?.email || '';
      ui.folded = (await local.get('tachesFolded')).tachesFolded === true;
      render();
    },
    render,
    _test: { build, prune, ymd },
  };
})();
