// Pure parsing/ordering of days and time slots, independent of the DOM.
import type { DateFilter, DayPick, SlotPick } from "./settings";

/** "9:05 PM" or "21:05" -> 1265 (minutes since midnight), or null if it isn't a time. */
export function parseTime(text: string): number | null {
  const m = /^(\d{1,2})[:h.](\d{2})\s?(AM|PM)?$/i.exec(text.trim());
  if (!m || Number(m[2]) > 59) return null;
  const ampm = m[3]?.toUpperCase();
  if (!ampm) return Number(m[1]) < 24 ? Number(m[1]) * 60 + Number(m[2]) : null;
  let h = Number(m[1]) % 12;
  if (ampm === "PM") h += 12;
  return h * 60 + Number(m[2]);
}

/**
 * A day button's data-day as a timestamp, or 0 if unparseable. ISO ("2026-10-26") is unambiguous.
 * "a/b/YYYY" comes from the browser's toLocaleDateString: M/D in an English Chrome, D/M in a French
 * or Arabic one. A part above 12 settles it; otherwise the button's own day number (dayOfMonth) does.
 */
export function parseDayAttr(attr: string | null, dayOfMonth?: number): number {
  const s = attr ?? "";
  const iso = /(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (iso) return new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3])).getTime();
  const m = /(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})/.exec(s);
  if (!m) return 0;
  const a = Number(m[1]);
  const b = Number(m[2]);
  const dayFirst = a > 12 || (b <= 12 && dayOfMonth === a && dayOfMonth !== b);
  const [day, month] = dayFirst ? [a, b] : [b, a];
  return new Date(Number(m[3]), month - 1, day).getTime();
}

/** "2026-12-15" -> local-midnight timestamp, or null when empty/invalid. */
export function parseIsoDate(s: string): number | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  return m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])).getTime() : null;
}

export const filterActive = (f: DateFilter): boolean => !!(f.from || f.to || f.excludeDays.length);

/** Whether a day (local-midnight timestamp) passes the user's date filter. Unknown dates (0) pass. */
export function dayAllowed(ts: number, f: DateFilter): boolean {
  if (!ts) return true;
  if (f.excludeDays.includes(new Date(ts).getDay())) return false;
  const from = parseIsoDate(f.from);
  if (from !== null && ts < from) return false;
  const to = parseIsoDate(f.to);
  return to === null || ts <= to;
}

export function pickSlot<T extends { mins: number }>(
  slots: readonly T[],
  mode: SlotPick,
  random: () => number = Math.random,
): T | undefined {
  if (!slots.length) return undefined;
  if (mode === "random") return slots[Math.floor(random() * slots.length)];
  const sorted = [...slots].sort((a, b) => a.mins - b.mins);
  return mode === "latest" ? sorted.at(-1) : sorted[0];
}

export function orderByDate<T>(items: readonly T[], dateOf: (t: T) => number, pick: DayPick): T[] {
  const sorted = [...items].sort((a, b) => dateOf(a) - dateOf(b));
  return pick === "latest" ? sorted.reverse() : sorted;
}
