// Agence Autofill, runs in the BLS page itself (MAIN world, document_start). It sends NO request of its own:
// it only reads the answers to the calendar requests the site already makes (/slots/calendar for a month's
// days, /slots/date-slots for a day's hours) and passes a copy to the extension's page script by postMessage.
// The site gets its responses untouched; any error here is swallowed.
export const PEEK_TAG = "aa-bls-api";
const WATCHED = /\/api\/v1\/slots\/(calendar|date-slots)\b/;

function pass(url: string, status: number, text: string): void {
  const m = WATCHED.exec(url);
  if (!m || status < 200 || status >= 300) return;
  try {
    window.postMessage({ tag: PEEK_TAG, kind: m[1], url, body: JSON.parse(text) }, location.origin);
  } catch {
    // not JSON: ignore
  }
}

const origFetch = window.fetch;
window.fetch = async function (this: unknown, ...args: Parameters<typeof fetch>): Promise<Response> {
  const res = await origFetch.apply(this, args);
  try {
    if (WATCHED.test(res.url)) {
      const copy = res.clone();
      void copy.text().then((t) => pass(res.url, res.status, t), () => {});
    }
  } catch {
    // never disturb the site
  }
  return res;
};

const origOpen = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function (this: XMLHttpRequest, ...args: unknown[]) {
  try {
    const url = String(args[1] ?? "");
    if (WATCHED.test(url)) {
      this.addEventListener("load", () => {
        try {
          const t = this.responseType === "" || this.responseType === "text" ? this.responseText : JSON.stringify(this.response);
          pass(this.responseURL || url, this.status, t);
        } catch {
          // ignore
        }
      });
    }
  } catch {
    // ignore
  }
  return (origOpen as (...a: unknown[]) => void).apply(this, args);
} as typeof XMLHttpRequest.prototype.open;
