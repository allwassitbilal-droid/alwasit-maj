// Agence Autofill version: settings under "blsSettings"; the profiles and the BLS account come from
// the panel's clients (see agence.ts), never from keys of their own. Nothing here removes data.
import { ACTIVE_KEY, profilesFrom, type Client } from "./agence";
import type { Profile } from "./profile";
import { activeProfile, normalizeProfiles, type Profiles } from "./profiles";
import { normalizeSettings, type Account, type Settings } from "./settings";

const SETTINGS_KEY = "blsSettings";
/** Shared with the whole team by the panel's sync (Supabase): Telegram and peak hours. */
const TEAM_KEY = "teamSettings";

type Team = Partial<Pick<Settings, "telegram" | "peak">>;

/** This PC's settings, with the team's Telegram and peak hours on top. */
export function mergeTeam(own: unknown, team: Team | undefined): Settings {
  const s = (typeof own === "object" && own !== null ? own : {}) as Record<string, unknown>;
  return normalizeSettings({ ...s, ...(team?.telegram ? { telegram: team.telegram } : {}), ...(team?.peak ? { peak: team.peak } : {}) });
}

export async function loadSettings(): Promise<Settings> {
  const r = await chrome.storage.local.get([SETTINGS_KEY, TEAM_KEY]);
  return mergeTeam(r[SETTINGS_KEY], r[TEAM_KEY] as Team | undefined);
}

/**
 * Telegram and peak hours go to the team, only when they were actually changed here: saving another
 * setting must never push this PC's (maybe not yet synced) copy over what a colleague set.
 */
export async function saveSettings(s: Settings): Promise<void> {
  const n = normalizeSettings(s);
  const r = await chrome.storage.local.get([SETTINGS_KEY, TEAM_KEY]);
  const team = r[TEAM_KEY] as Team | undefined;
  const cur = mergeTeam(r[SETTINGS_KEY], team);
  const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);
  const changed = !same(cur.telegram, n.telegram) || !same(cur.peak, n.peak);
  await chrome.storage.local.set({ [SETTINGS_KEY]: n, ...(changed ? { [TEAM_KEY]: { ...team, telegram: n.telegram, peak: n.peak } } : {}) });
}

/** The client picked with «BLS» and his family; an empty profile when none is picked yet. */
export async function loadProfiles(): Promise<Profiles> {
  const r = await chrome.storage.local.get(["clients", ACTIVE_KEY]);
  return profilesFrom((r.clients as Client[] | undefined) ?? [], r[ACTIVE_KEY]) ?? normalizeProfiles(undefined);
}

export async function loadAccount(): Promise<Account> {
  return activeProfile(await loadProfiles()).account;
}

export async function loadProfile(): Promise<Profile> {
  return activeProfile(await loadProfiles()).profile;
}

export async function setActiveProfile(id: string): Promise<void> {
  await chrome.storage.local.set({ [ACTIVE_KEY]: id });
}

/** Fires when the picked client changes, or when the clients are edited (here or by a colleague). */
export function onProfilesChanged(cb: (ps: Profiles) => void): void {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.clients || changes[ACTIVE_KEY])) void loadProfiles().then(cb);
  });
}

export function onSettingsChanged(cb: (s: Settings) => void): void {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes[SETTINGS_KEY] || changes[TEAM_KEY])) void loadSettings().then(cb);
  });
}

export function onAccountChanged(cb: (a: Account) => void): void {
  onProfilesChanged((ps) => cb(activeProfile(ps).account));
}
