importScripts('lib/supabase.js', 'config.js', 'sync.js', 'alerts.js', 'matin.js', 'annonce.js', 'tlslogin.js', 'autoreload.js', 'pcs.js');

// Icon click and Alt+T open the side panel (it stays open next to the page).
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

chrome.commands.onCommand.addListener((command, tab) => {
  if (command === 'open-panel' && tab) chrome.sidePanel.open({ windowId: tab.windowId });
});
