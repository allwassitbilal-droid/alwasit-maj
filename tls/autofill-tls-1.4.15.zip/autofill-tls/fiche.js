// 📋 «Fiche dossier»: the paper form of the office (وثائق طلب تأشيرة شنغن), in the extension.
// One per client: his profile (salarié, commerçant, agriculteur…), the documents of that profile with what was
// brought (✅), what is missing (⬜) and what is not needed (➖), the passport deposit and an observation.
// Kept in the client (c.fiche, shared ☁ like the rest). From it: the count on the card (📋 8/14), a WhatsApp
// to the client with what is missing, and the printed fiche (same look as the paper one).
// Uses popup.js: clients, save, render, el, toast, fullName, frDate.
globalThis.AAFiche = (() => {
  const APP = /tls/i.test(chrome.runtime.getManifest().name) ? 'tls' : 'bls';

  // [key, arabic label (as on the paper), french, options]  opt: «si disponible» (not counted as missing)
  const GROUPS = [
    ['🗂 Dossier', [
      ['formulaire', 'الاستمارة', 'Formulaire', { slot: 'formulaire' }],
      ['photos', '02 صور', '2 photos', { slot: 'photo' }],
      ['recu', 'توصيل الأداء', 'Reçu de paiement'],
    ]],
    ['🪪 Identité', [
      ['passeport', 'جواز السفر', 'Passeport', { slot: 'passeport' }],
      ['cin', 'بطاقة التعريف الوطنية', 'CIN'],
      ['visas', 'تأشيرات شنغن السابقة', 'Visas Schengen précédents', { opt: 1 }],
      ['etatcivil', 'عقد الزواج أو شهادة العزوبة، طلاق أو أرملة (مترجمة)', 'Acte de mariage / célibat / divorce / veuvage (traduit)'],
      ['livret', 'نسخة لدفتر الحالة المدنية', 'Livret de famille'],
    ]],
    ['🏦 Argent', [
      ['releves', 'كشوفات الحساب البنكي مع الرصيد الحالي (أصلية)', 'Relevés bancaires + solde (originaux)', { months: 1 }],
      ['attbanque', 'الشهادة البنكية', 'Attestation bancaire'],
      ['propriete', 'ملكية أو عقار (إذا توفر)', 'Propriété / bien immobilier', { opt: 1 }],
    ]],
    ['✈️ Voyage', [
      ['assurance', 'شهادة تأمين السفر', 'Assurance voyage'],
      ['avion', 'حجز تذكرة الطائرة', 'Réservation billet d\'avion'],
      ['hotel', 'حجز الفندق', 'Réservation d\'hôtel'],
    ]],
  ];

  const PROFILS = {
    salarie: ['💼', 'للأجير', 'Salarié', [
      ['atttravail', 'شهادة العمل', 'Attestation de travail'],
      ['attsalaire', 'شهادة الأجرة', 'Attestation de salaire'],
      ['bulletins', 'كشف الراتب لآخر 3 أشهر (أصلية)', '3 derniers bulletins de paie'],
      ['cnsscarte', 'بطاقة الانخراط / التسجيل في CNSS', 'Carte CNSS'],
      ['cnssdecl', 'شهادة التصريح بالأجور CNSS', 'Déclaration de salaires CNSS'],
    ], 3],
    commerce: ['🏪', 'السجل التجاري', 'Commerçant / gérant', [
      ['rc', 'السجل التجاري (Model 7)', 'Registre de commerce (Modèle 7)'],
      ['patente', 'شهادة التسجيل في الرسم المهني', 'Attestation de taxe professionnelle'],
      ['patenteq', 'التوصيل الضريبي السنوي (الباتنتا)', 'Quittance annuelle (patente)'],
      ['revenu', 'شهادة الدخل', 'Attestation de revenu'],
      ['igr', 'التصريح بالضريبة على الدخل (IGR) / آخر تصريح ضريبي', 'Déclaration IR (IGR) / dernière déclaration'],
      ['fiscale', 'شهادة الوضعية الجبائية القانونية', 'Attestation de régularité fiscale'],
      ['nonrole', 'شهادة عدم التسجيل بالجداول', 'Attestation de non-inscription aux rôles', { opt: 1 }],
      ['ca', 'رقم المعاملات (بالنسبة لفرنسا، أرباب الشركات)', 'Chiffre d\'affaires (France, gérants)', { opt: APP === 'bls' ? 1 : 0 }],
    ], 6],
    agri: ['🌾', 'فلاح مستقل', 'Agriculteur (exploitant)', [
      ['attagri', 'شهادة فلاح من القيادة / الجماعة', 'Attestation d\'exploitant agricole'],
      ['terre', 'شهادة الملكية أو عقد كراء الأرض الفلاحية', 'Propriété ou bail de la terre'],
      ['patenteagri', 'شهادة الضريبة المهنية (Patente)', 'Patente', { opt: 1 }],
      ['cartefellah', 'بطاقة الفلاح', 'Carte d\'agriculteur', { opt: 1 }],
    ], 6],
    ouvrier: ['👨‍🌾', 'عامل فلاحي', 'Ouvrier agricole', [
      ['atttravailagri', 'شهادة العمل الفلاحي (شهادة شغل)', 'Attestation de travail agricole'],
      ['cnssagri', 'تصريح CNSS', 'Déclaration CNSS', { opt: 1 }],
      ['bulletinsagri', 'كشوفات الأجرة لـ 3 أشهر', '3 bulletins de paie'],
    ], 3],
    charge: ['👨‍👩‍👧', 'العاطلين عن العمل / بالتكفل', 'Sans emploi / à charge', [
      ['priseencharge', 'شهادة تكفل موقعة ومصادق عليها (الحالة المهنية للمتكفل)', 'Prise en charge légalisée (+ situation du garant)'],
      ['ressources', 'إثبات ملكية أو موارد أخرى', 'Preuve de propriété / ressources'],
      ['relevesgarant', 'كشف حساب بنكي (المتكفل) أو سند ملكية', 'Relevés du garant ou titre de propriété'],
      ['lien', 'صلة القرابة', 'Lien de parenté'],
      ['naissance', 'شهادة ميلاد مترجمة للفرنسية أو الإسبانية', 'Acte de naissance traduit'],
    ], 3],
    autre: ['📁', 'آخر', 'Autre', [], 3],
  };

  // ---------- the model ----------
  const fiche = c => c.fiche || {};
  const items = c => {
    const f = fiche(c), p = PROFILS[f.profil];
    const groups = GROUPS.map(([g, list]) => [g, list]);
    if (p && p[3].length) groups.push([`${p[0]} ${p[2]}`, p[3]]);
    if ((f.extra || []).length) groups.push(['➕ Autres', f.extra.map(x => [x.k, x.ar, x.fr || x.ar, {}])]);
    return groups;
  };
  /** 'ok' | 'na' | '' (missing). Stored: ok / na / miss; not marked yet: ✅ if the file is in Fichiers,
   *  ➖ for an optional document («si disponible»), else missing. */
  const stateOf = (c, key, opts = {}, files = {}) => {
    const s = fiche(c).docs?.[key]?.s;
    if (s === 'ok' || s === 'na') return s;
    if (s === 'miss') return '';
    if (opts.slot && files[opts.slot]) return 'ok';
    return opts.opt ? 'na' : '';
  };
  function counts(c, files = {}) {
    let ok = 0, total = 0;
    const missing = [];
    for (const [, list] of items(c)) for (const [k, ar, fr, o = {}] of list) {
      const s = stateOf(c, k, o, files);
      if (s === 'na') continue;
      total++;
      if (s === 'ok') ok++; else missing.push({ k, ar, fr });
    }
    return { ok, total, missing };
  }

  async function filesOf(c) {
    const out = {};
    if (!globalThis.AAFiles) return out;
    await Promise.all(['formulaire', 'photo', 'passeport'].filter(s => AAFiles.SLOTS.some(x => x[0] === s)).map(async s => {
      try { out[s] = (await AAFiles.list(c.id, s)).length > 0; } catch { /* not connected */ }
    }));
    return out;
  }

  async function update(c, fn) {
    const cur = clients.find(x => x.id === c.id);
    if (!cur) return null;
    const f = JSON.parse(JSON.stringify(cur.fiche || {}));
    fn(f);
    f.at = Date.now();
    cur.fiche = f;
    await save();
    return cur;
  }

  // ---------- card button ----------
  function button(c) {
    const f = fiche(c);
    const { ok, total, missing } = counts(c);
    const done = f.profil && !missing.length;
    return el('button', {
      type: 'button', className: 'fiche-btn' + (done ? ' done' : f.profil ? ' part' : ''),
      title: f.profil ? `Fiche dossier : ${ok}/${total} documents${missing.length ? ` — manque : ${missing.slice(0, 6).map(m => m.fr).join(', ')}${missing.length > 6 ? '…' : ''}` : ' — complet ✓'}` : 'Fiche dossier : documents à apporter (choisir le profil)',
      onclick: () => open(c),
    }, '📋', f.profil ? el('small', { textContent: done ? '✓' : `${ok}/${total}` }) : null);
  }

  // ---------- the view ----------
  let curId = null, files = {};
  const view = () => document.querySelector('#fiche-view');

  async function open(c) {
    curId = c.id;
    files = {};
    document.querySelectorAll('.view').forEach(v => { v.hidden = v.id !== 'fiche-view'; });
    draw();
    files = await filesOf(c);
    if (curId === c.id) draw();
  }
  function close() {
    curId = null;
    view().hidden = true;
    document.querySelector('#list-view').hidden = false;
    render();
  }

  function draw() {
    const c = clients.find(x => x.id === curId);
    if (!c) return close();
    const f = fiche(c);
    const body = view().querySelector('.fiche-body');
    view().querySelector('h2').textContent = `📋 ${fullName(c)}`;
    const { ok, total, missing } = counts(c, files);
    const pct = total ? Math.round((ok / total) * 100) : 0;

    const head = el('div', { className: 'card fiche-head' },
      el('div', { className: 'fiche-id' },
        el('b', { textContent: `N° ${c.num ?? '—'}` }),
        el('span', { textContent: [APP.toUpperCase(), c.reserve?.centre || c.rdvCentre].filter(Boolean).join(' · ') }),
        c.mobile ? el('span', { textContent: '📞 ' + c.mobile }) : null),
      el('div', { className: 'fiche-profils' }, ...Object.entries(PROFILS).map(([k, p]) => el('button', {
        type: 'button', className: 'pf' + (f.profil === k ? ' on' : ''), textContent: `${p[0]} ${p[2]}`, title: p[1],
        onclick: async () => { await update(c, x => { x.profil = k; if (!x.mois) x.mois = p[4]; }); draw(); },
      }))),
      f.profil ? el('div', { className: 'fiche-progress' },
        el('div', { className: 'bar' }, el('i', { style: `width:${pct}%` })),
        el('span', { textContent: missing.length ? `${ok}/${total} — باقي ${missing.length}` : `✅ كامل (${total})` })) : el('p', { className: 'hint', textContent: 'Choisissez le profil du client : la liste des documents s\'affiche.' }));

    const depot = f.depot || {};
    const dep = el('div', { className: 'card fiche-depot' },
      el('label', {}, 'Dépôt passeport ', el('input', { type: 'date', value: depot.le || '', onchange: e => update(c, x => { x.depot = { ...(x.depot || {}), le: e.target.value }; }) })),
      el('label', {}, 'Rendu le ', el('input', { type: 'date', value: depot.rendu || '', onchange: e => update(c, x => { x.depot = { ...(x.depot || {}), rendu: e.target.value }; }) })),
      el('label', { className: 'check' }, el('input', { type: 'checkbox', checked: !!f.guichet, onchange: e => update(c, x => { x.guichet = e.target.checked; }) }), ' Carte guichet'));

    const groups = f.profil ? items(c).map(([g, list]) => el('div', { className: 'card fiche-group' },
      el('div', { className: 'sec-title', textContent: g }),
      ...list.map(([k, ar, fr, o = {}]) => row(c, k, ar, fr, o)))) : [];

    const add = f.profil ? el('form', {
      className: 'fiche-add', onsubmit: async e => {
        e.preventDefault();
        const v = e.target.elements.doc.value.trim();
        if (!v) return;
        await update(c, x => { x.extra = [...(x.extra || []), { k: 'x' + Date.now().toString(36), ar: v }]; });
        draw();
      },
    }, el('input', { name: 'doc', placeholder: '＋ Autre document (ex : traduction, attestation…)' }), el('button', { type: 'submit', textContent: 'Ajouter' })) : null;

    const obs = el('div', { className: 'card' }, el('div', { className: 'sec-title', textContent: '📝 Observation' }),
      el('textarea', { rows: 2, value: f.obs || '', placeholder: 'Remarques sur le dossier…', onchange: e => update(c, x => { x.obs = e.target.value; }) }));

    const tools = f.profil ? el('div', { className: 'fiche-tools' },
      el('button', { type: 'button', className: 'wa', textContent: missing.length ? `📲 Demander au client (${missing.length})` : '📲 Dossier complet → client', onclick: () => whatsapp(c) }),
      el('button', { type: 'button', textContent: '🖨 Imprimer la fiche', onclick: () => print(c) })) : null;

    body.replaceChildren(head, ...(f.profil ? [dep] : []), ...groups, ...(add ? [add] : []), obs, ...(tools ? [tools] : []));
  }

  function row(c, k, ar, fr, o) {
    const s = stateOf(c, k, o, files);
    const d = fiche(c).docs?.[k] || {};
    const auto = (!d.s || d.s === 'ok') && o.slot && files[o.slot];
    const next = { '': 'ok', ok: 'na', na: '' }[s];
    const icon = { ok: '✅', na: '➖', '': '⬜' }[s];
    return el('div', { className: 'fiche-row ' + (s || 'miss') },
      el('button', {
        type: 'button', className: 'fiche-state', textContent: icon,
        title: { ok: 'Reçu — cliquer : pas nécessaire', na: 'Pas nécessaire — cliquer : à apporter', '': 'Manque — cliquer : reçu' }[s],
        onclick: async () => { await update(c, x => { x.docs = { ...(x.docs || {}), [k]: { s: next || 'miss', at: Date.now() } }; }); draw(); },
      }),
      el('div', { className: 'fiche-label' },
        el('span', { className: 'ar', textContent: ar }),
        el('small', { textContent: fr + (o.opt ? ' (si disponible)' : '') + (auto ? ' · 📎 dans Fichiers' : '') + (d.at && d.s === 'ok' ? ' · ' + new Date(d.at).toLocaleDateString('fr-FR') : '') })),
      o.months ? el('select', {
        title: 'Nombre de mois', onchange: e => update(c, x => { x.mois = +e.target.value; }),
      }, ...[3, 6, 12].map(m => el('option', { value: m, textContent: `${m} mois`, selected: (fiche(c).mois || PROFILS[fiche(c).profil]?.[4] || 3) === m }))) : null);
  }

  // ---------- WhatsApp to the client: what is still missing ----------
  function waText(c) {
    const { missing } = counts(c, files);
    const f = fiche(c);
    const mois = f.mois || PROFILS[f.profil]?.[4] || 3;
    if (!missing.length) return `السلام عليكم ${c.prenom || ''}،\nالدوسي ديالك كامل ✅ شكرا. غادي نتاصلو بيك فاش يكون الموعد.`;
    return `السلام عليكم ${c.prenom || ''}،\nباش نكملو الدوسي ديال الفيزا ${APP === 'bls' ? '🇪🇸' : '🇫🇷'} خاصك تجيب لينا هاد الوثائق:\n${missing.map(m => '• ' + m.ar + (m.k === 'releves' ? ` (${mois} أشهر)` : '')).join('\n')}\nشكرا 🙏`;
  }
  function whatsapp(c) {
    let d = String(c.mobile || '').replace(/\D/g, '');
    if (d.startsWith('00')) d = d.slice(2);
    if (/^0[5-7]\d{8}$/.test(d)) d = '212' + d.slice(1);
    const text = encodeURIComponent(waText(c));
    chrome.tabs.create({ url: d.length >= 10 ? `https://wa.me/${d}?text=${text}` : `https://wa.me/?text=${text}` });
    if (d.length < 10) toast('Pas de numéro (mobile) dans le dossier : choisissez le contact dans WhatsApp', true);
  }

  // ---------- print (fiche.html opens a tab with the fiche, like the paper one) ----------
  async function print(c) {
    const data = {
      app: APP, c: { num: c.num, nom: c.nom, prenom: c.prenom, mobile: c.mobile, gmail: c.gmail, prix: c.prix, paye: c.paye, centre: c.reserve?.centre || c.rdvCentre },
      profil: PROFILS[fiche(c).profil], fiche: fiche(c),
      rows: items(c).map(([g, list]) => [g, list.map(([k, ar, fr, o = {}]) => ({ ar, fr, s: stateOf(c, k, o, files), months: o.months ? (fiche(c).mois || PROFILS[fiche(c).profil]?.[4] || 3) : 0 }))]),
    };
    await chrome.storage.local.set({ fichePrint: data });
    chrome.tabs.create({ url: chrome.runtime.getURL('fiche.html') });
  }

  function mount() {
    const v = el('div', { id: 'fiche-view', className: 'view', hidden: true },
      el('div', { className: 'edit-head' },
        el('button', { type: 'button', className: 'icon', title: 'Retour', textContent: '←', onclick: close }),
        el('h2', { textContent: '📋 Fiche' }),
        el('span', { className: 'grow' }),
        el('button', { type: 'button', className: 'icon', title: 'Modifier le client (✎)', textContent: '✎', onclick: () => { const c = clients.find(x => x.id === curId); close(); if (c) openEdit(c); } })),
      el('div', { className: 'fiche-body scroll' }));
    document.body.append(v);
    chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.clients && curId && !view().hidden && !view().contains(document.activeElement)) setTimeout(draw, 0); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount); else mount();

  return { button, open, counts, waText, PROFILS, GROUPS, items, stateOf };
})();
