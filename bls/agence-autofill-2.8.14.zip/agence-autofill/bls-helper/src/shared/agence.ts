// Bridge to Agence Autofill: the BLS pages fill and sign in for the client picked with the panel's
// «BLS» button (storage key "blsActive"), and his family members, from the shared "clients" list.
import { CHOICE_KEYS, DATE_KEYS, EMPTY_PROFILE, SECTIONS, classifyField, normalizeProfile, type Profile, type ProfileKey } from "./profile";
import type { NamedProfile, Profiles } from "./profiles";

/** One client of the panel, as stored (only the fields used here). */
export interface Client {
  id: string;
  prenom?: string;
  nom?: string;
  naissance?: string;
  passeport?: string;
  delivre?: string;
  expire?: string;
  lieu?: string;
  mobile?: string;
  gmail?: string;
  code?: string;
  blsmdp?: string;
  extra?: string;
  famille?: string;
  lien?: string;
}

export const ACTIVE_KEY = "blsActive";

/** Free text of a choice ("Masculin", "M", "Marié") -> the profile's choice value. */
const CHOICE_TEXT: Record<string, RegExp> = {
  female: /^f$|f[ée]minin|female|femme|أنثى/i,
  male: /^m$|masculin|\bmale\b|homme|ذكر/i,
  single: /c[ée]libataire|single|عازب/i,
  married: /mari[ée]|married|متزوج/i,
  divorced: /divorc|مطلق/i,
  widowed: /veu(f|ve)|widow|أرمل/i,
  tourism: /touris|سياح/i,
  family: /visite|famil|زيارة/i,
  business: /affaire|business|أعمال/i,
  studies: /[ée]tude|stud|دراسة/i,
  one: /une|single|one|^1$/i,
  two: /deux|two|double|^2$/i,
  multi: /multi/i,
  ordinary: /ordinaire|ordinary|عادي/i,
  service: /service|خدمة/i,
  hotel: /h[ôo]tel|فندق/i,
  invitation: /invitation|h[ée]berg|famil|استضافة/i,
  no: /^(non|no|لا)$/i,
  yes: /^(oui|yes|نعم)$/i,
};

function choiceValue(key: ProfileKey, text: string): string {
  const choices = SECTIONS.flatMap((s) => s.fields).find((f) => f.key === key)?.choices ?? [];
  // "female" before "male": the longer word contains the shorter.
  const order = [...choices].sort((a, b) => (a.value === "female" ? -1 : b.value === "female" ? 1 : 0));
  return order.find((c) => c.value === text || CHOICE_TEXT[c.value]?.test(text.trim()))?.value ?? "";
}

/** "14/05/2030", "14.05.2030", "2030-05-14" -> "2030-05-14", or "". */
function isoDate(s: string): string {
  const ymd = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
  if (ymd) return s.trim();
  const dmy = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(s.trim());
  return dmy ? `${dmy[3]}-${dmy[2]!.padStart(2, "0")}-${dmy[1]!.padStart(2, "0")}` : "";
}

/** The client's details as a BLS Helper profile: passport fields, then any «Champs en plus» it recognises. */
export function clientToProfile(c: Client): Profile {
  const p: Record<string, string> = {
    ...EMPTY_PROFILE,
    lastName: c.nom ?? "",
    firstName: c.prenom ?? "",
    birthDate: c.naissance ?? "",
    passportNumber: c.passeport ?? "",
    passportIssueDate: c.delivre ?? "",
    passportExpiryDate: c.expire ?? "",
    passportIssuePlace: c.lieu ?? "",
    email: c.gmail ?? "",
    phone: c.mobile ?? "",
  };
  for (const line of (c.extra ?? "").split("\n")) {
    const at = line.indexOf("=");
    if (at < 0) continue;
    const label = line.slice(0, at).trim();
    const value = line.slice(at + 1).trim();
    const key = classifyField(label);
    if (!key || !value) continue;
    p[key] = CHOICE_KEYS.has(key) ? choiceValue(key, value) : DATE_KEYS.has(key) ? isoDate(value) : value;
  }
  return normalizeProfile(p);
}

const named = (c: Client): NamedProfile => ({
  id: c.id,
  name: (c.prenom || c.nom || "?").slice(0, 30),
  profile: clientToProfile(c),
  account: { email: (c.gmail ?? "").trim(), password: c.blsmdp || c.code || "" },
});

/** The active client and his family (same "famille"), the active one first. Empty list when none is picked. */
export function profilesFrom(clients: readonly Client[], activeId: unknown): Profiles | null {
  const active = clients.find((c) => c.id === activeId);
  if (!active) return null;
  const family = active.famille ? clients.filter((c) => c.famille === active.famille && c.id !== active.id) : [];
  return { list: [active, ...family].map(named), activeId: active.id };
}
