// After login: sidebar «Manage appointments» -> «More actions» -> «Continue to slot selection»
// (any of the site's four languages; see texts.ts).
import { ACTIVE_APPT_RE, BOOK_BTN_RE, BOOK_NEW_RE, DATE_PAGE_RE, MANAGE_TEXT_RE, MORE_ACTIONS_RE, NO_APPOINTMENT_RE, OK_BTN_RE, PROCEED_RE, READY_RE } from "./texts";
import { rateGuard, session, sleep, textOf } from "./util";

const MANAGE_HREF_RE = /manage-appointments/i;
const MAX_RUN_MS = 120_000;
/** On the appointments page, time for the list to load before «no appointment» is believed. */
const EMPTY_SETTLE_MS = 3000;

const onManagePage = () => MANAGE_HREF_RE.test(location.pathname);
const onDatePage = () =>
  !!document.querySelector('[data-slot="calendar"], [role="grid"]') || DATE_PAGE_RE.test(document.body.innerText);
const onLoginPage = () => !!document.querySelector('input[type="password"]');

const sidebarLink = () =>
  [...document.querySelectorAll<HTMLAnchorElement>("a[href]")].find((a) => MANAGE_HREF_RE.test(a.getAttribute("href")!)) ??
  [...document.querySelectorAll<HTMLAnchorElement>("a")].find((a) => MANAGE_TEXT_RE.test(textOf(a)));

const moreActions = () =>
  [...document.querySelectorAll<HTMLButtonElement>('button[data-slot="dropdown-menu-trigger"]')].find((b) =>
    MORE_ACTIONS_RE.test(`${b.textContent ?? ""} ${b.getAttribute("aria-label") ?? ""}`),
  );

const proceedItem = () =>
  [...document.querySelectorAll<HTMLElement>('[role="menuitem"]')].find((e) => PROCEED_RE.test(e.textContent?.replace(/\s+/g, " ") ?? ""));

async function pollFor<T>(fn: () => T | undefined, tries = 12, stepMs = 250): Promise<T | undefined> {
  for (let i = 0; i < tries; i++) {
    const r = fn();
    if (r) return r;
    await sleep(stepMs);
  }
  return undefined;
}

async function openMenuAndProceed(): Promise<boolean> {
  const trigger = moreActions();
  if (!trigger || !rateGuard("blsNavMenu", 3, 120_000)) return false;
  await sleep(800);
  // Radix opens its menus on pointerdown, not click.
  trigger.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, button: 0, pointerType: "mouse" }));
  trigger.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, button: 0 }));
  let item = await pollFor(proceedItem);
  if (!item) {
    trigger.click();
    item = await pollFor(proceedItem);
  }
  if (!item) return false;
  await sleep(300);
  item.click();
  return true;
}

/** Calls fn each time the login form goes away (a login just went through), without a page load. */
export function onLeaveLogin(fn: () => void): void {
  let wasLogin = onLoginPage();
  let queued = false;
  new MutationObserver(() => {
    if (queued) return;
    queued = true;
    // Not requestAnimationFrame: it never fires in a hidden tab, which is where sessions expire.
    setTimeout(() => {
      queued = false;
      const now = onLoginPage();
      if (wasLogin && !now) fn();
      wasLogin = now;
    }, 100);
  }).observe(document.documentElement, { childList: true, subtree: true });
}

const CLICKABLE = 'button, a, [role="button"]';

/** «Prendre un nouveau rendez-vous» on an account with no appointment yet (the button, or the element holding the text). */
function bookNewButton(): HTMLElement | undefined {
  const norm = (e: Element) => textOf(e).replace(/\s+/g, " ");
  const direct = [...document.querySelectorAll<HTMLElement>(CLICKABLE)].find((b) => BOOK_NEW_RE.test(norm(b)));
  if (direct) return direct;
  const leaf = [...document.querySelectorAll<HTMLElement>("body *")].find((e) => !e.children.length && BOOK_NEW_RE.test(norm(e)));
  return (leaf?.closest<HTMLElement>(CLICKABLE) ?? leaf) || undefined;
}

const dialogOpen = () => !!document.querySelector('[role="dialog"], [role="alertdialog"]');

/** The appointments page of an account with no appointment, its list loaded, no window open over it. */
const emptyManagePage = (): boolean =>
  onManagePage() && !moreActions() && !dialogOpen() && NO_APPOINTMENT_RE.test(document.body.innerText) && !!bookNewButton();

/** «Prendre rendez-vous» above the applicants list: a real button, not the sidebar link of the same name. */
const bookListButton = (): HTMLElement | undefined =>
  [...document.querySelectorAll<HTMLElement>('button, [role="button"]')].find(
    (b) => !b.closest("nav, aside") && BOOK_BTN_RE.test(textOf(b).replace(/\s+/g, " ")),
  );

/** The «Prendre rendez-vous» page: applicants listed, one of them «Prêt à réserver», no window open. */
const applicantsPage = (): boolean =>
  !onManagePage() && !dialogOpen() && !onDatePage() && !knownActive() && READY_RE.test(document.body.innerText) && !!bookListButton();

// ---- An appointment already open on the account («En cours»): carried on, never a new one over it ----
const ACTIVE_FLAG = "aaActiveAppt";
const ACTIVE_FLAG_MS = 30 * 60_000;
/** The appointments page showed an appointment a moment ago: a new booking would only be refused. */
const knownActive = (): boolean => Date.now() - (Number(session.get(ACTIVE_FLAG)) || 0) < ACTIVE_FLAG_MS;
const setKnownActive = (on: boolean): void => session.set(ACTIVE_FLAG, on ? String(Date.now()) : "0");

/** BLS's «Vous avez déjà un rendez-vous actif…» notice, with its «D'accord». */
function activeNoticeButton(): HTMLElement | undefined {
  const box = [...document.querySelectorAll<HTMLElement>('[role="dialog"], [role="alertdialog"]')].find((d) => ACTIVE_APPT_RE.test(d.innerText));
  return box ? [...box.querySelectorAll<HTMLElement>("button")].find((b) => OK_BTN_RE.test(textOf(b).replace(/\s+/g, " "))) : undefined;
}
export const activeNoticeShown = (): boolean => !!activeNoticeButton();

/**
 * «Vous avez déjà un rendez-vous actif»: D'accord, then the appointments page, where the navigator carries on
 * with that appointment (Plus d'actions → Continuer vers la sélection du créneau). Nothing is deleted.
 */
export async function handleActiveNotice(askUser: (text: string) => void): Promise<void> {
  const ok = activeNoticeButton();
  if (!ok || !rateGuard("blsActiveNotice", 3, 10 * 60_000)) return;
  setKnownActive(true);
  realClick(ok);
  await sleep(600);
  // The new-booking window may stay open behind the notice: close it.
  const cancel = [...document.querySelectorAll<HTMLElement>('[role="dialog"] button')].find((b) => /^(annuler|cancel|إلغاء|cancelar)$/i.test(textOf(b)));
  if (cancel) realClick(cancel);
  await sleep(400);
  askUser("📋 هاد الكونط فيه ديجا موعد «En cours»: غادي نكمل بيه (Plus d'actions → Continuer)، بلا ما نمسحو وبلا موعد جديد");
  if (!onManagePage()) sidebarLink()?.click();
}

/** A page where only a new booking leads on: the empty appointments page, or the applicants list. */
export const emptyAccountPage = (): boolean => emptyManagePage() || applicantsPage();

/** A full click as a user makes it (pointer + mouse events): some site buttons open on pointerdown. */
function realClick(el: HTMLElement): void {
  const opts = { bubbles: true, cancelable: true, button: 0 };
  el.dispatchEvent(new PointerEvent("pointerdown", { ...opts, pointerType: "mouse" }));
  el.dispatchEvent(new MouseEvent("mousedown", opts));
  el.dispatchEvent(new PointerEvent("pointerup", { ...opts, pointerType: "mouse" }));
  el.dispatchEvent(new MouseEvent("mouseup", opts));
  el.click();
}

/** Opens the new-booking window and tells the user what to choose; says so when it couldn't. */
async function openNewBooking(askUser: (text: string) => void): Promise<void> {
  const btn = onManagePage() ? bookNewButton() : bookListButton();
  if (!btn || !rateGuard("blsNavBookNew", 3, 10 * 60_000)) return;
  await sleep(600);
  realClick(btn);
  const where = location.pathname;
  const opened = await pollFor(() => dialogOpen() || location.pathname !== where || undefined, 12, 250);
  const name = textOf(btn).replace(/\s+/g, " ");
  askUser(
    opened
      ? `🆕 حليت «${name}». اختار الغرض والكليان وضغط «Continuer»، ومن بعد المراقبة كتبدا بوحدها`
      : `🆕 ما قدرتش نحل «${name}»: كليكي عليها بيدك، اختار الغرض والكليان وضغط «Continuer»`,
  );
}

/**
 * @param askUser An account with no appointment: the new-booking window is opened, and the user is told to
 * choose there (purpose, individual / family, applicant) and click Continue; the date page then starts watching.
 */
export async function runNavigator(askUser: (text: string) => void = () => {}): Promise<void> {
  const started = Date.now();
  let sidebarClicks = 0;
  let manageSince = 0;
  let askedNew = false;
  let toldStage = false;
  while (Date.now() - started < MAX_RUN_MS) {
    await sleep(500);
    if (onDatePage()) return;
    if (onLoginPage()) continue; // login.ts is still working

    if (onManagePage()) {
      manageSince ||= Date.now();
      if (moreActions()) {
        setKnownActive(true);
        if (await openMenuAndProceed()) return;
        // The open appointment is past slot selection (verification, payment…) or the menu has no such item.
        if (!toldStage && Date.now() - manageSince > EMPTY_SETTLE_MS) {
          toldStage = true;
          document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          askUser("📋 كاين موعد «En cours» وما فيهش «Continuer vers la sélection du créneau»: شوف «Plus d'actions» بيدك (كمل ولا Supprimer)");
        }
        continue;
      }
      if (emptyManagePage()) setKnownActive(false);
      // No appointment on this account (the list has loaded and is empty): start a new one.
      if (dialogOpen()) return; // the new-booking window is open: the user is choosing there
      if (!askedNew && emptyAccountPage() && Date.now() - manageSince > EMPTY_SETTLE_MS) {
        askedNew = true;
        await openNewBooking(askUser);
        // The user has up to «Open BLS»'s wait (10 min) to finish; the date page then starts watching.
        return;
      }
      continue;
    }
    manageSince = 0;
    // «Prendre rendez-vous» list (where «Prendre un nouveau rendez-vous» leads): its button opens the window.
    if (applicantsPage()) {
      if (!askedNew) {
        askedNew = true;
        await openNewBooking(askUser);
      }
      return;
    }
    if (dialogOpen() && READY_RE.test(document.body.innerText)) return; // the user is choosing in the window
    const link = sidebarLink();
    if (link && sidebarClicks < 3 && rateGuard("blsNavLink", 3, 120_000)) {
      sidebarClicks++;
      await sleep(600);
      link.click(); // SPA link: no full reload
      await sleep(1500);
    }
  }
}

// ---- The new-booking window (Individual / Family / Group, the applicant, «Continuer vers la sélection du créneau») ----
const proceedIn = (d: HTMLElement): HTMLButtonElement | undefined =>
  [...d.querySelectorAll<HTMLButtonElement>("button")].find((b) => PROCEED_RE.test(textOf(b).replace(/\s+/g, " ")));

const bookingWindow = (): HTMLElement | null =>
  [...document.querySelectorAll<HTMLElement>('[role="dialog"]')].find((d) => READY_RE.test(d.innerText) && !!proceedIn(d)) ?? null;

/** The window is open with its Continue button. */
export const newBookingWindowReady = (): boolean => !!bookingWindow();

/** The active client's family as in the panel (just the client when alone): names, upper case. */
async function familyNames(): Promise<string[]> {
  try {
    const { clients = [], blsActive } = (await chrome.storage.local.get(["clients", "blsActive"])) as {
      clients?: Array<{ id: string; famille?: string; prenom?: string; nom?: string }>;
      blsActive?: string;
    };
    const c = clients.find((x) => x.id === blsActive);
    const fam = c?.famille ? clients.filter((x) => x.famille === c.famille) : c ? [c] : [];
    return fam.map((m) => `${m.prenom ?? ""} ${m.nom ?? ""}`.trim().toUpperCase());
  } catch {
    return [];
  }
}

const handled = new WeakSet<HTMLElement>();
const WINDOW_RESULT_MS = 10_000;
/** The site's family sizes go 2…5 (1 is Individual). */
const MAX_FAMILY = 5;

const FAMILY_BTN_RE = /^(family|famille|عائلة|familia)$/i;
const COUNT_RE = /nombre total|total number|family size|عدد|n[úu]mero total/i;
/** «Ajouter» next to each family member in the window. */
const ADD_RE = /^(ajouter|add|إضافة|أضف|añadir|agregar)$/i;
/** «Tout sélectionner (3)» above the members. */
const SELECT_ALL_RE = /^(tout s[ée]lectionner|select all|تحديد الكل|seleccionar todo)/i;

const norm = (s: string): string => s.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\s+/g, " ").trim().toUpperCase();
const enabled = (b: HTMLButtonElement | undefined): b is HTMLButtonElement =>
  !!b && !b.disabled && b.getAttribute("aria-disabled") !== "true";

/** Family: «Family», then the total number of members, then each member ticked when the site asks. */
async function chooseFamily(d: HTMLElement, names: string[]): Promise<string | null> {
  const n = names.length;
  if (n > MAX_FAMILY) return `👨‍👩‍👧 عائلة ديال ${n}: BLS كيقبل حتى لـ ${MAX_FAMILY}، اختار «Group» ولا قسمهم بيدك`;
  const famBtn = [...d.querySelectorAll<HTMLElement>('button, [role="button"], [role="radio"], [role="tab"]')].find((b) =>
    FAMILY_BTN_RE.test(textOf(b).replace(/\s+/g, " ")),
  );
  if (!famBtn) return "👨‍👩‍👧 ما لقيتش «Family» فالنافذة";
  realClick(famBtn);

  // The «Nombre total de membres de la famille» picker, then the option «n».
  const trigger = await pollFor(
    () =>
      [...d.querySelectorAll<HTMLElement>('[role="combobox"], button, select')].find(
        (e) => e.getAttribute("role") === "combobox" || e.tagName === "SELECT" || COUNT_RE.test(textOf(e)),
      ),
    12,
    250,
  );
  if (!trigger) return "👨‍👩‍👧 ما لقيتش «Nombre total de membres»";
  if (trigger instanceof HTMLSelectElement) {
    const opt = [...trigger.options].find((o) => o.text.trim() === String(n) || o.value === String(n));
    if (!opt) return `👨‍👩‍👧 ما لقيتش ${n} ف «Nombre total de membres»`;
    trigger.value = opt.value;
    trigger.dispatchEvent(new Event("change", { bubbles: true }));
  } else {
    realClick(trigger);
    const opt = await pollFor(
      () => [...document.querySelectorAll<HTMLElement>('[role="option"]')].find((o) => textOf(o).replace(/\s+/g, " ") === String(n)),
      12,
      250,
    );
    if (!opt) return `👨‍👩‍👧 ما لقيتش ${n} ف «Nombre total de membres»`;
    realClick(opt);
  }
  await sleep(800);

  // Members: the site lists the account's other applicants, each with «Ajouter». Added until the count is
  // reached (the principal is already in): this family's names first, then the others in the site's order.
  const want = n - 1;
  let added = 0;
  const addButtons = () =>
    [...d.querySelectorAll<HTMLButtonElement>("button")].filter((b) => enabled(b) && ADD_RE.test(textOf(b).replace(/\s+/g, " ")));
  const rowName = (b: HTMLElement) => norm(b.closest<HTMLElement>('tr, [role="row"], li')?.innerText ?? b.parentElement?.parentElement?.innerText ?? "");
  /** «Tout sélectionner (3)»: adds everyone the count allows, in one click. */
  const allButton = () =>
    [...d.querySelectorAll<HTMLButtonElement>("button")].find((b) => enabled(b) && SELECT_ALL_RE.test(textOf(b).replace(/\s+/g, " ")));
  await pollFor(() => (addButtons().length || allButton() ? true : undefined), 12, 250);
  const all = allButton();
  // Everyone listed is this family (as many as the count asks): one click on «Tout sélectionner».
  if (all && addButtons().length === want) {
    realClick(all);
    added = want;
    await pollFor(() => (enabled(proceedIn(d)) || !addButtons().length ? true : undefined), 12, 250);
  }
  // One by one (the site redraws the list after each add, so each one is checked before the next):
  // this family's names first, then the others in the site's order, until Continue lights up.
  for (let tries = 0; tries < want * 3 && !enabled(proceedIn(d)); tries++) {
    const list = addButtons();
    const next = list.find((b) => names.some((nm) => rowName(b).includes(norm(nm)))) ?? list[0];
    if (!next) break;
    const before = list.length;
    realClick(next);
    added++;
    await pollFor(() => (addButtons().length < before || enabled(proceedIn(d)) ? true : undefined), 8, 250);
    await sleep(300);
  }

  // Older layout: a checkbox per member, ticked by name.
  if (!added && !enabled(proceedIn(d))) {
    for (const name of names) {
      const cell = [...d.querySelectorAll<HTMLElement>("*")].find((e) => !e.children.length && norm(textOf(e)) === norm(name));
      const row = cell?.closest<HTMLElement>('tr, [role="row"], label, li') ?? cell?.parentElement?.parentElement ?? null;
      if (!row) continue;
      const box = row.querySelector<HTMLElement>('[role="checkbox"], input[type="checkbox"]');
      const on = box ? box.getAttribute("aria-checked") === "true" || (box as HTMLInputElement).checked === true : false;
      if (!on) realClick(box ?? row);
      await sleep(250);
    }
  }
  return (await pollFor(() => enabled(proceedIn(d)) || undefined, 12, 250))
    ? null
    : `👨‍👩‍👧 عائلة (${n}): اخترت «Family» و ${n}، ولكن «Continuer» ما تشعلاتش. شوف واش الأفراد مختارين وكمل بيدك`;
}

/**
 * Clicks «Continuer vers la sélection du créneau» as the user would (once; the site then creates the appointment
 * and shows the dates): for one client with one applicant ready, or for a family (Family, its size, its members).
 */
export async function continueNewBooking(askUser: (text: string) => void): Promise<void> {
  const d = bookingWindow();
  if (!d || handled.has(d)) return;
  handled.add(d);
  // BLS already refused a new appointment from this connection less than 24 h ago: don't ask it again.
  const since = await ipLimitAt();
  if (since && Date.now() - since < IP_LIMIT_MS) {
    const left = Math.ceil((IP_LIMIT_MS - (Date.now() - since)) / 3600_000);
    return askUser(`⛔ BLS قال: كاين موعد تحجز من هاد الأنترنيت (IP) ف 24 ساعة اللخرة. ما غاديش نكليكي «Continuer» عاوتاني قبل ~${left} ساعة`);
  }
  await sleep(800); // let the window finish its own preselection
  const names = await familyNames();
  if (names.length > 1) {
    const problem = await chooseFamily(d, names);
    if (problem) return askUser(problem);
  } else {
    const ready = d.innerText.match(new RegExp(READY_RE.source, "gi"))?.length ?? 0;
    if (ready !== 1) return askUser("👤 اختار الكليان فالنافذة وضغط «Continuer vers la sélection du créneau»");
  }
  const btn = proceedIn(d);
  if (!enabled(btn)) {
    return askUser("👤 كمل الاختيارات فالنافذة وضغط «Continuer vers la sélection du créneau»");
  }
  if (!rateGuard("blsNavContinue", 2, 10 * 60_000)) {
    return askUser("✋ كليكيت «Continuer» جوج مرات ف 10 دقايق: ما غاديش نعاود بوحدي، كليكي عليها نتا إلا بغيتي");
  }
  btn.click();
  const left = await pollFor(() => onDatePage() || !document.contains(d) || undefined, WINDOW_RESULT_MS / 250, 250);
  if (left) return;
  const toast = toastErr();
  if (IP_LIMIT_RE.test(toast) || IP_LIMIT_RE.test(d.innerText)) {
    await setIpLimitAt(Date.now());
    return askUser(
      "⛔ BLS رفض موعد جديد: «Vous avez déjà un rendez-vous réservé à partir de cette adresse IP au cours des dernières 24 heures». " +
        "هادشي على الأنترنيت ديال المكتب كامل، ماشي على هاد الكليان. ما غاديش نعاود 24 ساعة",
    );
  }
  const said = toast || d.innerText.replace(/\s+/g, " ").match(/[^.!?]*(motif|purpose|s[ée]lectionnez|required|obligatoire)[^.!?]*/i)?.[0];
  askUser(`⚠️ النافذة ما دازتش${said ? `: ${said.trim().slice(0, 140)}` : ""}. كملها بيدك`);
}

// BLS: one new appointment per internet connection (IP) per 24 h. Kept per PC in the extension's storage.
const IP_LIMIT_KEY = "blsIpLimitAt";
const IP_LIMIT_MS = 24 * 3600_000;
const IP_LIMIT_RE = /adresse IP|IP address|عنوان IP|direcci[óo]n IP/i;

async function ipLimitAt(): Promise<number> {
  try {
    return Number((await chrome.storage.local.get(IP_LIMIT_KEY))[IP_LIMIT_KEY]) || 0;
  } catch {
    return 0;
  }
}

async function setIpLimitAt(at: number): Promise<void> {
  try {
    await chrome.storage.local.set({ [IP_LIMIT_KEY]: at });
  } catch {
    // extension reloaded
  }
}

const toastErr = (): string =>
  [...document.querySelectorAll<HTMLElement>('[data-sonner-toast], [role="alert"]')]
    .map((x) => x.innerText.replace(/\s+/g, " ").trim())
    .filter(Boolean)
    .join(" | ");
