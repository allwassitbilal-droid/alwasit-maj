// The printable fiche (opened by 📋 → 🖨): same layout as the paper form of the office.
(async () => {
  const FOOT = 'ESPACE SERVICES  فضاء الخدمات\nTel personnel : +212664885522 / +212666165020 / +212702795689\nTel Fixe : 0808542609\nEMAIL : e.khadamats@gmail.com';
  const { fichePrint: d, ficheFooter } = await chrome.storage.local.get(['fichePrint', 'ficheFooter']);
  const page = document.querySelector('#page');
  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  if (!d) { page.textContent = 'Aucune fiche à imprimer.'; return; }
  const { c, fiche: f = {}, profil, rows, app } = d;
  const fr = iso => (iso ? iso.split('-').reverse().join('/') : '');
  const n = v => { const x = parseFloat(String(v ?? '').replace(',', '.')); return Number.isFinite(x) ? x : null; };
  document.title = `Fiche ${c.num ?? ''} ${c.prenom || ''} ${c.nom || ''}`.trim();

  const top = h('div', 'top');
  const num = h('div', 'num');
  num.append('N° : ', h('b', null, `${c.num ?? '……'} / ${app.toUpperCase()} / ${c.centre || '……'}`));
  top.append(num, h('div', 'tag', app === 'bls' ? 'BLS 🇪🇸' : 'TLS 🇫🇷'));
  const title = h('h1', null, `وثائق طلب تأشيرة شنغن${profil ? ' — ' + profil[1] : ''}`);
  const sub = h('div', 'sub', profil ? `${profil[0]} ${profil[2]}` : '');

  const prix = n(c.prix), paye = n(c.paye) || 0;
  const fields = h('div', 'fields');
  const field = (label, value, full) => { const e = h('div', 'f' + (full ? ' full' : '')); e.append(h('i', null, label), value || '………………'); fields.append(e); };
  field('Nom Prénom :', `${c.prenom || ''} ${c.nom || ''}`.trim(), true);
  field('N° Téléphone :', c.mobile);
  field('Email :', c.gmail);
  field('Dépôt passeport :', [f.depot?.le && 'le ' + fr(f.depot.le), f.depot?.rendu && 'rendu le ' + fr(f.depot.rendu)].filter(Boolean).join(' · '));
  field('Carte guichet :', f.guichet ? '☑ oui' : '☐');
  field('Prix :', prix != null ? prix + ' DH' : '');
  field('Avance / Reste :', prix != null ? `${paye} DH / ${Math.max(0, prix - paye)} DH` : (paye ? paye + ' DH' : ''));
  field('Observation :', f.obs, true);

  const list = h('div', 'list');
  let ok = 0, total = 0;
  const missing = [];
  for (const [g, items] of rows) {
    const box = h('div', 'g');
    box.append(h('h3', null, g));
    for (const it of items) {
      const r = h('div', 'r ' + (it.s || 'miss'));
      r.append(h('span', 'box', it.s === 'ok' ? '✓' : it.s === 'na' ? '–' : ''), h('span', 'ar', it.ar + (it.months ? ` (${it.months} أشهر)` : '')), h('span', 'fr', it.fr));
      box.append(r);
      if (it.s !== 'na') { total++; if (it.s === 'ok') ok++; else missing.push(it.ar); }
    }
    list.append(box);
  }
  const sum = h('div', 'sum', missing.length ? `الوثائق: ${ok}/${total} — باقي: ${missing.join('، ')}` : `✅ الدوسي كامل: ${ok}/${total}`);
  const foot = h('footer', null, ficheFooter || FOOT);
  foot.contentEditable = 'plaintext-only';
  foot.addEventListener('blur', () => chrome.storage.local.set({ ficheFooter: foot.innerText.trim() }));
  page.append(top, title, sub, fields, list, sum, h('div', 'op', `L'opérateur : ${new Date().toLocaleDateString('fr-FR')}`), h('div', 'grow'), foot);
  document.querySelector('#print').onclick = () => window.print();
})();
