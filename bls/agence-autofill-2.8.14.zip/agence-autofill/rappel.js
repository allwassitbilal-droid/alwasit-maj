// Appointment reminders (service worker): for every client with a BLS appointment (c.reserve.day / .time),
// a Windows notification with sound + a Telegram message
//   - the day before, from 9:00 («🗓 RDV demain»),
//   - the day itself, from 7:00 («⏰ RDV aujourd'hui»).
// Each reminder goes once per client and date: the mark (c.rdvRappel) is synced, so the other PCs don't send it again.
(() => {
  const local = chrome.storage.local;
  const NOTIF_PREFIX = 'rdv:';
  const fullName = c => `${c.prenom || ''} ${c.nom || ''}`.trim() || '(sans nom)';
  const frDate = iso => (iso ? iso.split('-').reverse().join('/') : '');
  const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

  async function settings() {
    const { blsSettings = {}, teamSettings = {} } = await local.get(['blsSettings', 'teamSettings']);
    return teamSettings.telegram || blsSettings.telegram || {};
  }

  async function beep() {
    try {
      if (!(await chrome.offscreen.hasDocument())) {
        await chrome.offscreen.createDocument({
          url: 'bls/offscreen.html', reasons: ['AUDIO_PLAYBACK'], justification: 'Play a sound for an appointment reminder',
        });
        await new Promise(r => setTimeout(r, 200));
      }
      await chrome.runtime.sendMessage({ type: 'offscreen-beep' });
    } catch { /* no sound: the notification still shows */ }
  }

  async function telegram(tg, text) {
    if (!tg?.botToken || !tg?.chatId) return false;
    try {
      const r = await fetch(`https://api.telegram.org/bot${encodeURIComponent(tg.botToken)}/sendMessage`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, signal: AbortSignal.timeout(10_000),
        body: JSON.stringify({ chat_id: tg.chatId, text: `🗓 Autofill BLS\n${text}` }),
      });
      return (await r.json()).ok;
    } catch { return false; }
  }

  /** Reminders due now: 'j1' (tomorrow, from 9:00) and 'j0' (today, from 7:00), not sent yet. */
  function due(clients, now = new Date()) {
    const today = ymd(now), tomorrow = ymd(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1));
    const out = [];
    for (const c of clients) {
      const day = c.reserve?.day;
      if (!day) continue;
      const kind = day === today && now.getHours() >= 7 ? 'j0' : day === tomorrow && now.getHours() >= 9 ? 'j1' : '';
      if (kind && c.rdvRappel !== `${kind}:${day}`) out.push({ c, kind });
    }
    return out;
  }

  let running = null;
  function check() {
    running ||= run().finally(() => { running = null; });
    return running;
  }
  async function run() {
    // Several PCs: a random wait lets the first one's mark arrive by sync before the others look.
    await new Promise(r => setTimeout(r, Math.random() * 20_000));
    const { clients = [] } = await local.get('clients');
    const list = due(clients);
    if (!list.length) return;
    const line = ({ c }) => `• ${c.num != null ? `N°${c.num} ` : ''}${fullName(c)}${c.reserve.time ? ` à ${c.reserve.time}` : ''}`
      + (c.reserve.face ? ' (selfie à faire)' : '');
    const part = (kind, head) => {
      const l = list.filter(x => x.kind === kind).sort((a, b) => (a.c.reserve.time || '').localeCompare(b.c.reserve.time || ''));
      return l.length ? `${head}\n${l.map(line).join('\n')}` : '';
    };
    const today = part('j0', `⏰ RDV BLS اليوم (${frDate(ymd(new Date()))}):`);
    const tomorrow = part('j1', `🗓 RDV BLS غدا (${frDate(list.find(x => x.kind === 'j1')?.c.reserve.day)}):`);
    const text = [today, tomorrow].filter(Boolean).join('\n\n');
    beep();
    chrome.notifications.create(`${NOTIF_PREFIX}${Date.now()}`, {
      type: 'basic', iconUrl: 'bls/icon.png', requireInteraction: true, priority: 2,
      title: today ? `⏰ Rendez-vous BLS aujourd'hui` : '🗓 Rendez-vous BLS demain',
      message: text.slice(0, 900),
    });
    await telegram(await settings(), text);
    const { clients: fresh = [] } = await local.get('clients');
    for (const c of fresh) {
      const d = list.find(x => x.c.id === c.id);
      if (d && c.reserve?.day === d.c.reserve.day) c.rdvRappel = `${d.kind}:${c.reserve.day}`;
    }
    await local.set({ clients: fresh });
  }

  chrome.notifications.onClicked.addListener(async id => {
    if (!id.startsWith(NOTIF_PREFIX)) return;
    chrome.notifications.clear(id);
    const [w] = await chrome.windows.getAll({ windowTypes: ['normal'] });
    if (w) chrome.windows.update(w.id, { focused: true });
  });

  chrome.alarms.create('bls-rdv-rappel', { delayInMinutes: 1, periodInMinutes: 30 });
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'bls-rdv-rappel') check(); });
  // An appointment typed for today or tomorrow: remind within a minute, not at the next half hour.
  let soon;
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || !ch.clients) return;
    const old = new Map((ch.clients.oldValue || []).map(c => [c.id, c.reserve?.day]));
    if ((ch.clients.newValue || []).some(c => c.reserve?.day && old.get(c.id) !== c.reserve.day)) {
      clearTimeout(soon);
      soon = setTimeout(check, 30_000);
    }
  });
})();
