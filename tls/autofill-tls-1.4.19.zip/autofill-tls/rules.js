// Shared by the popup (CSV import) and the page filler (label matching).
// Order matters: the first rule that matches wins (e.g. "lieu délivrance" before "délivré").
globalThis.AA_RULES = [
  // France-Visas fields (client.fv), the most specific first: «nom à la naissance» before «nom» and «naissance».
  { key: 'nomNaissance', inc: /nom.*naissance|birthname|maidenname|jeunefille|surnameatbirth/ },
  { key: 'lieuNaissance', inc: /(lieu|ville|place|city).*(naiss|birth)|birthplace|placeofbirth/ },
  { key: 'paysNaissance', inc: /pays.*naiss|countryofbirth|birthcountry/ },
  { key: 'nationaliteNaissance', inc: /nationalit.*(naiss|birth)/ },
  { key: 'nationalite', inc: /nationalit|citizenship/, exc: /autre|other/ },
  { key: 'sexe', inc: /^sexe|^sex$|gender|^genre/ },
  { key: 'etatCivil', inc: /etatcivil|maritalstatus|civilstatus|situationfamiliale|situationmatrimoniale/ },
  { key: 'cin', inc: /^cin$|numeronational|nationalid|identitynumber|cartenationale|nationalidentity/ },
  { key: 'dateArrivee', inc: /datedarrivee|arrivee|arrival|datedentree/ },
  { key: 'dateDepart', inc: /datededepart|depart|departure/ },
  { key: 'profession', inc: /profession|occupation|metier/, exc: /employeur|employer/ },
  { key: 'employeur', inc: /employeur|employer|etablissementdenseignement/ },
  { key: 'adresse', inc: /adresse|address|domicile/, exc: /mail|electron|courriel|ip|employeur|employer|heberg|hotel|invit/ },
  { key: 'typeDoc', inc: /typededocument|typedudocument|documenttype|typeofdocument|typedepasseport/ },
  { key: 'delivrePar', inc: /delivrepar|autoritedelivr|issuingauthority|issuedby|paysdedelivrance|issuingcountry/ },
  { key: 'autresNationalites', inc: /autresnationalit|othernationalit/ },
  { key: 'destination', inc: /etatmembrededestination|destinationprincipale|maindestination|paysdedestination/ },
  { key: 'premiereEntree', inc: /premiereentree|firstentry|etatmembredepremiereentree/ },
  { key: 'entrees', inc: /nombredentrees|numberofentries|entreesdemandees/ },
  { key: 'objet', inc: /objets?duvoyage|motifs?duvoyage|purposeofjourney|purposeoftravel|motifdusejour|objetdusejour/ },
  { key: 'gmail', inc: /e?mail|courriel|adresseelectronique/, exc: /mailing|postal|parent|employ|societe|company|agence/ },
  { key: 'lieu', inc: /lieu.*(deliv|emis)|placeofissue|issueplace|issuedat|autorite|authority/ },
  { key: 'expire', inc: /expir|validjusqu|validuntil|validite|dateoffin/ },
  { key: 'delivre', inc: /deliv|emission|dateofissue|issuedate|issuedon|issue/ },
  { key: 'passeport', inc: /passeport|passport|numpass|ndepass|travel/ },
  { key: 'naissance', inc: /naissance|birth|dob|nele|datenai/, exc: /lieu|place|pays|country|ville|city/ },
  { key: 'prenom', inc: /prenom|firstname|givenname|fname/ },
  { key: 'nom', inc: /nom|lastname|surname|familyname|lname/, exc: /utilisateur|user|societe|company|agence|pere|mere|nombre|denomin/ },
  { key: 'mobile', inc: /mobile|telephone|^tel|phone|gsm|portable/ },
];

globalThis.AA_DATES = ['naissance', 'delivre', 'expire', 'dateArrivee', 'dateDepart'];
// Keys kept in client.fv (France-Visas form), filled like the others.
globalThis.AA_FV_KEYS = ['nomNaissance', 'lieuNaissance', 'paysNaissance', 'nationaliteNaissance', 'nationalite', 'sexe', 'etatCivil', 'cin', 'dateArrivee', 'dateDepart', 'profession', 'employeur', 'adresse', 'typeDoc', 'delivrePar', 'autresNationalites', 'destination', 'premiereEntree', 'entrees', 'objet'];

globalThis.AA_norm = s => (s || '').toString().normalize('NFD').replace(/[̀-ͯ]/g, '')
  .toLowerCase().replace(/[^a-z0-9]/g, '');

globalThis.AA_match = text => {
  const n = AA_norm(text);
  if (!n) return null;
  for (const r of AA_RULES) if (r.inc.test(n) && !(r.exc && r.exc.test(n))) return r.key;
  return null;
};

// Stamp for a client created on this PC: who (the ☁ login) and which PC. bls.js sends the
// «nouveau client» Telegram from this PC only, once (sent: true then travels to the team).
globalThis.AA_newMeta = async () => {
  const r = await chrome.storage.local.get(['deviceId', 'syncStatus']);
  let pc = r.deviceId;
  if (!pc) { pc = crypto.randomUUID(); await chrome.storage.local.set({ deviceId: pc }); }
  return { by: r.syncStatus?.email || '', pc, at: Date.now(), sent: false };
};

// Accepts "2030-05-14", "14/05/2030", "14-05-2030", "14.05.2030" -> "2030-05-14"
globalThis.AA_toIso = s => {
  s = (s || '').trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const m = s.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);
  return m ? `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}` : '';
};
