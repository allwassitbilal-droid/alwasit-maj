// Gmail + its code come first everywhere. `code` has no fill rule: it only goes where you click.
const FIELDS = [
  ['gmail', 'Gmail'], ['code', 'Code Gmail'], ['tlsmdp', 'Mot de passe TLS'], ['prenom', 'Prénom'], ['nom', 'Nom'], ['naissance', 'Naissance'], ['passeport', 'N° passeport'],
  ['delivre', 'Délivré'], ['expire', 'Expire'], ['lieu', 'Lieu délivrance'], ['mobile', 'Mobile'],
];
// France-Visas form (Cerfa 14076): everything else the consulate asks, kept in client.fv, by group.
// [key, label, kind]: kind = 'wide' (whole line), 'date', or a list of choices.
const FV_GROUPS = [
  ['👤 Identité', [
    ['nomNaissance', 'Nom à la naissance'], ['lieuNaissance', 'Lieu de naissance'], ['paysNaissance', 'Pays de naissance'],
    ['nationalite', 'Nationalité actuelle'], ['nationaliteNaissance', 'Nationalité à la naissance'], ['autresNationalites', 'Autres nationalités'],
    ['sexe', 'Sexe', ['Homme', 'Femme', 'Autre']],
    ['etatCivil', 'État civil', ['Célibataire', 'Marié(e)', 'Partenariat enregistré', 'Séparé(e)', 'Divorcé(e)', 'Veuf(Veuve)', 'Autre']],
    ['cin', 'N° national d\'identité (CIN)'], ['tuteur', 'Autorité parentale / tuteur (mineurs)', 'wide']]],
  ['🛂 Document de voyage', [
    ['typeDoc', 'Type de document', ['Passeport ordinaire', 'Passeport diplomatique', 'Passeport de service', 'Passeport officiel', 'Passeport spécial', 'Autre']],
    ['delivrePar', 'Délivré par (pays)']]],
  ['🏠 Adresse et travail', [
    ['adresse', 'Adresse du domicile', 'wide'], ['email', 'Email personnel'], ['residenceAutre', 'Résidence dans un autre pays'],
    ['profession', 'Profession actuelle'], ['employeur', 'Employeur / établissement (nom, adresse, tél.)', 'wide']]],
  ['✈️ Voyage', [
    ['objet', 'Objet du voyage'], ['destination', 'Destination principale'], ['infoObjet', 'Infos sur l\'objet du voyage', 'wide'],
    ['premiereEntree', 'Pays de première entrée'], ['entrees', 'Entrées demandées', ['Une entrée', 'Deux entrées', 'Entrées multiples']],
    ['dateArrivee', 'Date d\'arrivée', 'date'], ['dateDepart', 'Date de départ', 'date'], ['empreintes', 'Empreintes déjà prises', ['Non', 'Oui']]]],
  ['🏨 Hébergement', [
    ['hebergement', 'Hôtel / personne qui invite', 'wide'], ['hebergementAdresse', 'Adresse de l\'hébergement', 'wide'],
    ['hebergementTel', 'Téléphone de l\'hébergement'], ['hebergementEmail', 'Email de l\'hébergement'], ['entrepriseHote', 'Entreprise / organisation hôte', 'wide']]],
  ['💶 Financement', [
    ['financement', 'Frais payés par', ['Par le demandeur', 'Par un garant']], ['moyens', 'Moyens de subsistance', 'wide']]],
  ['📄 Demande France-Visas', [
    ['reference', 'Référence (FRA…)'], ['dateDemande', 'Date de la demande', 'date'], ['remplisseur', 'Rempli par']]],
];
const FV_FIELDS = FV_GROUPS.flatMap(([, f]) => f);
const FV_DATES = FV_FIELDS.filter(f => f[2] === 'date').map(f => f[0]);
const $ = s => document.querySelector(s);
const form = $('#edit-view');
let clients = [], editingId = null, openId = null, selected = 0;
let enabled = FIELDS.map(f => f[0]); // fields the user wants filled (⚙)
// Folders: each account has an optional `dossier`; `dossiers` also keeps folders that are still empty.
const ALL = '', NONE = '\u0000none', ARCHIVE = '\u0000archive';
let dossiers = [], folder = ALL;
let famOpen = new Set(); // families shown open (▾): by default only the principal shows; kept on this PC only
let view = 'all'; // departures board: all | rdv | tls | manque
let folderHue = new Map(); // folder → its candy color, for the ticket stub

const save = () => chrome.storage.local.set({ clients });
const saveFolders = () => chrome.storage.local.set({ dossiers, folder });
const folderNames = () => [...new Set([...dossiers, ...clients.map(c => c.dossier).filter(Boolean)])]
  .sort((a, b) => a.localeCompare(b));
// Archived clients (RDV taken, file closed) show only under «📦 Archive».
const inFolder = (c, f) => f === ARCHIVE ? !!c.archive : !c.archive && (f === ALL || (f === NONE ? !c.dossier : c.dossier === f));
const frDate = iso => (iso ? iso.split('-').reverse().join('/') : '');
const show = (k, v) => (AA_DATES.includes(k) || FV_DATES.includes(k) ? frDate(v) : v || '');
const fullName = c => `${c.prenom || ''} ${c.nom || ''}`.trim() || '(sans nom)';
// N° of the client (✎ → «N° dossier»): shown in the round badge, and the list is sorted by it. No number = at the end.
const numOf = c => (Number.isFinite(+c.num) && String(c.num).trim() !== '' ? +c.num : Infinity);
const groupNum = g => Math.min(...g.map(numOf));

function el(tag, props = {}, ...kids) {
  const e = Object.assign(document.createElement(tag), props);
  e.append(...kids.filter(k => k != null));
  return e;
}

function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = bad ? 'show bad' : 'show';
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (t.className = ''), 2500);
}

// ---- Family: accounts with the same `famille` id show together; `lien` orders them ----
const LIENS = { principal: 'Principal', conjoint: 'Époux/se', enfant: 'Enfant', autre: 'Autre' };
const lienRank = c => { const i = Object.keys(LIENS).indexOf(c.lien); return i < 0 ? 9 : i; };
const membersOf = f => (f ? clients.filter(c => c.famille === f) : [])
  .sort((a, b) => lienRank(a) - lienRank(b) || fullName(a).localeCompare(fullName(b)));

// Flat list in display order: a family stays together (head first), and a match on one member brings the whole family.
// Departures board (top): quick views over the open folder.
const dayDiff = iso => Math.round((new Date(iso + 'T12:00:00') - new Date(new Date().toDateString() + ' 12:00')) / 864e5);
const tlsDue = c => { const e = tlsExpiry(c.tlsCree); return !!e && !c.archive && daysLeft(e) <= TLS_WARN_DAYS; };
const BOARD = {
  all: { label: 'Tous', test: () => true },
  rdv: { label: 'RDV à venir', test: c => c.etape === 'rdv' && (!c.rdvDate || dayDiff(c.rdvDate) >= 0), title: 'Rendez-vous TLS pris, aujourd\'hui ou plus tard' },
  tls: { label: 'Compte TLS ⏳', test: tlsDue, title: 'Compte TLS qui expire cette semaine ou déjà expiré : nouveau compte à créer' },
  manque: { label: 'Il manque', test: c => c.etape === 'manque', title: 'Dossiers où il manque des documents' },
};
function renderBoard() {
  const base = clients.filter(c => inFolder(c, folder));
  $('#board').replaceChildren(...Object.entries(BOARD).map(([k, b]) => el('button', {
    className: 'gate ' + k + (view === k ? ' on' : ''), title: b.title || 'Tous les clients du dossier',
    onclick: () => { view = view === k && k !== 'all' ? 'all' : k; selected = 0; render(); },
  }, el('b', { textContent: base.filter(b.test).length }), el('span', { textContent: b.label }))));
}

function filtered() {
  const q = AA_norm($('#q').value);
  const hits = clients
    .filter(c => inFolder(c, folder))
    .filter(c => BOARD[view].test(c))
    .filter(c => !q || String(c.num ?? '') === q || AA_norm([c.prenom, c.nom, c.passeport, c.mobile, c.gmail, c.notes].join('')).includes(q));
  const groups = new Map();
  for (const c of hits) {
    const key = c.famille || c.id;
    if (!groups.has(key)) groups.set(key, c.famille ? membersOf(c.famille).filter(m => inFolder(m, folder)) : [c]);
  }
  // Ready (⭐) accounts first; a family with one ready member goes up whole.
  return [...groups.values()]
    // Ready groups first, then the others; inside each, by N° (1, 2, 3…), then by name for those without one.
    .sort((a, b) => isReady(b) - isReady(a) || (groupNum(a) - groupNum(b) || 0) || fullName(a[0]).localeCompare(fullName(b[0]))).flat();
}
const isReady = group => group.some(c => c.pret);

// A family goes together: its members are ready (⭐), or not, together.
async function toggleReady(c) {
  const pret = !c.pret;
  const pretAt = pret ? Date.now() : undefined;
  const group = c.famille ? membersOf(c.famille) : [c];
  for (const m of group) Object.assign(m, { pret, pretAt });
  await save();
  render();
  const who = group.length > 1 ? `Famille ${c.nom || fullName(c)} (${group.length})` : fullName(c);
  toast(pret ? `⭐ ${who} prêt${group.length > 1 ? 's' : ''}` : `${who} n'est plus dans les prêts`);
}

function render() {
  renderFolders();
  renderBoard();
  AATaches.render();
  const list = filtered();
  selected = Math.min(selected, Math.max(list.length - 1, 0));
  $('#count').textContent = `${list.length} / ${clients.length} clients · nom = tout remplir · case + valeur = une case`;
  const blocks = [];
  const nReady = list.filter(c => c.pret).length;
  const section = (cls, text) => el('div', { className: 'section ' + cls, textContent: text });
  if (nReady) blocks.push(section('ready', `⭐ Prêts (wajdin) · ${nReady}`));
  let othersShown = false; // ready groups come first (filtered), then this title once
  const searching = !!$('#q').value.trim();
  for (let i = 0; i < list.length;) {
    const f = list[i].famille;
    let j = i + 1;
    while (f && j < list.length && list[j].famille === f) j++;
    const group = list.slice(i, j);
    if (nReady && !othersShown && !isReady(group)) { blocks.push(section('others', 'Tous les clients')); othersShown = true; }
    if (group.length < 2) blocks.push(item(group[0], i, i === selected));
    else {
      // A family = the principal's ticket only; ▾ under it shows the others (a search always shows them).
      const headIdx = Math.max(0, group.findIndex(c => c.lien === 'principal'));
      const open = famOpen.has(f) || searching;
      const toggle = () => { famOpen.has(f) ? famOpen.delete(f) : famOpen.add(f); chrome.storage.local.set({ famOpen: [...famOpen] }); render(); };
      const others = group.map((c, k) => [c, i + k]).filter((_, k) => k !== headIdx);
      blocks.push(el('div', { className: 'family' + (open ? ' open' : '') },
        item(group[headIdx], i + headIdx, i + headIdx === selected || (!open && selected >= i && selected < j), { n: group.length, open, toggle, names: others.map(([c]) => c.prenom || fullName(c)) }),
        open ? el('div', { className: 'fam-members' }, ...others.map(([c, idx]) => item(c, idx, idx === selected))) : null));
    }
    i = j;
  }
  const emptyText = !clients.length ? 'Aucun client pour l\'instant. Cliquez ➕ Nouveau client ou importez un PDF France-Visas.'
    : view !== 'all' ? `Aucun client dans « ${BOARD[view].label} » ici.` : folder === ARCHIVE ? 'Aucun dossier archivé.' : 'Aucun client dans ce dossier.';
  $('#list').replaceChildren(...(list.length ? blocks : [el('div', { className: 'empty', textContent: emptyText })]));
  $('#list .sel')?.scrollIntoView({ block: 'nearest' }); // keyboard ↑↓ keeps the selected row visible
}

let shineFolder; // folder just clicked: its button shines once
function renderFolders() {
  const names = folderNames();
  if (folder !== ALL && folder !== NONE && folder !== ARCHIVE && !names.includes(folder)) folder = ALL;
  const count = f => clients.filter(c => inFolder(c, f)).length;
  // Candy buttons: each folder keeps its own color (from its name), the open one shines.
  const CANDY = [330, 145, 28, 205, 268, 185, 0, 48, 95, 300];
  const hueOf = n => CANDY[names.indexOf(n) % CANDY.length]; // in A→Z order, so two folders never share a color
  folderHue = new Map(names.map(n => [n, hueOf(n)]));
  const fchip = (f, label, cls = '') => {
    const b = el('button', {
      className: 'fchip ' + cls + (folder === f ? ' on' : '') + (shineFolder === f ? ' shine' : ''),
      onclick: () => { folder = f; shineFolder = f; selected = 0; openId = null; saveFolders(); render(); },
    }, el('span', { className: 'lbl', textContent: label }), el('span', { className: 'cnt', textContent: count(f) }));
    if (f !== NONE && f !== ARCHIVE) b.style.setProperty('--h', f === ALL ? 212 : hueOf(f));
    return b;
  };
  const kids = [fchip(ALL, 'Tous', 'all'), ...names.map(n => fchip(n, n))];
  if (names.length && count(NONE)) kids.push(fchip(NONE, 'Sans dossier', 'none'));
  if (count(ARCHIVE) || folder === ARCHIVE) kids.push(fchip(ARCHIVE, '📦 Archive', 'none archive'));
  kids.push(el('button', { className: 'fchip add', textContent: '+ Dossier', onclick: newFolder }));
  if (folder !== ALL && folder !== NONE && folder !== ARCHIVE) {
    kids.push(
      el('button', { className: 'fchip tool', textContent: '✎', title: 'Renommer le dossier', onclick: renameFolder }),
      el('button', { className: 'fchip tool danger', textContent: '🗑', title: 'Supprimer le dossier', onclick: deleteFolder }));
  }
  $('#folders').replaceChildren(...kids);
  shineFolder = undefined; // the shine plays once, on the click only
}

// Small inline text box (instead of prompt()) -> resolves with the text, or null if cancelled.
function askInline(placeholder, value = '') {
  return new Promise(resolve => {
    let finished = false;
    const box = $('#folder-ask');
    const inp = el('input', { placeholder, value });
    const done = v => { if (finished) return; finished = true; box.hidden = true; resolve(v); };
    inp.onkeydown = e => {
      if (e.key === 'Enter') { e.preventDefault(); done(inp.value.trim() || null); }
      if (e.key === 'Escape') done(null);
    };
    inp.onblur = () => done(null);
    box.replaceChildren(inp, el('button', {
      className: 'primary', textContent: 'OK',
      onmousedown: e => { e.preventDefault(); done(inp.value.trim() || null); },
    }));
    box.hidden = false;
    inp.focus();
    inp.select();
  });
}

async function newFolder() {
  const name = await askInline('Nom du dossier (ex: Omra 2026) puis Entrée');
  if (!name) return;
  if (!dossiers.includes(name)) dossiers.push(name);
  folder = name;
  saveFolders();
  render();
}

async function renameFolder() {
  const old = folder;
  const name = await askInline('Nouveau nom du dossier', old);
  if (!name || name === old) return;
  clients.forEach(c => { if (c.dossier === old) c.dossier = name; });
  dossiers = [...new Set(dossiers.map(d => (d === old ? name : d)).concat(name))];
  folder = name;
  await save();
  saveFolders();
  render();
}

// Two clicks to delete. The accounts are kept and go to "Sans dossier".
async function deleteFolder(e) {
  const btn = e.currentTarget;
  if (!btn.dataset.armed) {
    btn.dataset.armed = '1';
    btn.textContent = 'Supprimer le dossier ?';
    setTimeout(() => renderFolders(), 3000);
    return;
  }
  clients.forEach(c => { if (c.dossier === folder) delete c.dossier; });
  dossiers = dossiers.filter(d => d !== folder);
  folder = ALL;
  await save();
  saveFolders();
  render();
  toast('Dossier supprimé — ses comptes sont dans "Sans dossier"');
}

// Click a value = put it in the field clicked on the page (or copy it if the page blocks extensions)
// Codes and passwords show as dots; a click still puts (or copies) the real value.
const SECRETS = ['code', 'tlsmdp'];
const chip = (label, value, key = null, raw = value) => el('button', {
  className: ['gmail', ...SECRETS].includes(key) ? 'chip gm' : 'chip', title: 'Cliquez une case du formulaire, puis ici',
  onclick: () => insertValue(label, key, raw, value),
}, el('span', { textContent: label }), SECRETS.includes(key) ? '••••••' : value);

// Passport ending soon: the consulate wants it valid well after the trip. ⛔ expired, ⚠️ under 6 months left.
function passportWarning(c) {
  if (!c.expire) return null;
  const left = (new Date(c.expire) - new Date()) / 864e5;
  if (left >= 183) return null;
  const when = frDate(c.expire);
  return left < 0
    ? el('span', { className: 'chip exp bad', textContent: '⛔ Passeport expiré', title: `Expiré le ${when}` })
    : el('span', { className: 'chip exp', textContent: `⚠ Passeport ${when.slice(3)}`, title: `Le passeport expire le ${when} (moins de 6 mois)` });
}

// ---- Follow-up of each file: stage, what is missing, TLS account, appointment, notes ----
const ETAPES = {
  nouveau: ['🆕 Nouveau', 'Dossier ouvert, rien reçu encore'],
  docs: ['📄 Documents en cours', 'Le client a commencé à ramener ses documents'],
  manque: ['⚠️ Il manque', 'Des documents manquent encore'],
  complet: ['✅ Complet', 'Tous les documents sont là'],
  rdv: ['🗓 RDV pris', 'Rendez-vous TLS réservé'],
};
const etapeOf = c => (ETAPES[c.etape] ? c.etape : '');

// TLS account: valid 3 months from «Compte TLS créé le» (same day of month, or the month's last day).
const TLS_MONTHS = 3, TLS_WARN_DAYS = 7;
function tlsExpiry(created) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(created || '')) return '';
  const [y, m, d] = created.split('-').map(Number);
  const last = new Date(Date.UTC(y, m - 1 + TLS_MONTHS + 1, 0)).getUTCDate();
  return new Date(Date.UTC(y, m - 1 + TLS_MONTHS, Math.min(d, last))).toISOString().slice(0, 10);
}
const daysLeft = iso => Math.ceil((new Date(iso + 'T12:00:00') - Date.now()) / 864e5);
function tlsTag(c) {
  const exp = tlsExpiry(c.tlsCree);
  if (!exp || c.archive) return null;
  const d = daysLeft(exp), when = frDate(exp);
  if (d < 0) return el('span', { className: 'tag-tls bad', textContent: '⛔ Compte TLS expiré', title: `Expiré le ${when} : créez un nouveau compte` });
  if (d <= TLS_WARN_DAYS) return el('span', { className: 'tag-tls soon', textContent: `⏳ TLS ${d} j`, title: `Le compte TLS expire le ${when} : nouveau compte à créer` });
  return null;
}
function etapeTag(c) {
  const e = etapeOf(c);
  if (!e) return null;
  const [label, title] = ETAPES[e];
  const text = e === 'rdv' && c.rdvDate ? `🗓 RDV ${frDate(c.rdvDate).slice(0, 5)}${c.rdvHeure ? ' ' + c.rdvHeure : ''}` : label;
  return el('span', { className: 'tag-et e-' + e, textContent: text,
    title: e === 'manque' && c.manque ? 'Il manque : ' + c.manque : e === 'rdv' && c.rdvCentre ? `${title} · ${c.rdvCentre}` : title });
}

const tagsLine = (...tags) => (tags.some(Boolean) ? el('div', { className: 'tags' }, ...tags.filter(Boolean)) : null);

// The stamp on the ticket: the stage of the file, inked like a passport stamp.
function stamp(c) {
  const e = etapeOf(c);
  if (!e || e === 'nouveau') return null;
  let top, bottom = '', cls = e;
  if (e === 'rdv') {
    const d = c.rdvDate ? dayDiff(c.rdvDate) : null, date = c.rdvDate ? frDate(c.rdvDate).slice(0, 5) : '';
    top = d == null ? 'RDV pris' : d < 0 ? 'RDV passé' : d === 0 ? "RDV aujourd'hui" : d === 1 ? 'RDV demain' : `RDV ${date}`;
    bottom = d != null && d < 0 ? date : c.rdvHeure || '';
    if (d != null && d < 0) cls = 'past'; else if (d != null && d <= 1) cls = 'soon';
  } else if (e === 'complet') top = 'Complet ✓';
  else if (e === 'manque') top = 'Il manque';
  else top = 'Documents';
  const [, title] = ETAPES[e];
  return el('div', { className: 'stamp ' + cls, title: e === 'manque' && c.manque ? 'Il manque : ' + c.manque : e === 'rdv' && c.rdvCentre ? `${title} · ${c.rdvCentre}` : title },
    el('b', { textContent: top }), bottom ? el('small', { textContent: bottom }) : null);
}
function tlsChip(c) {
  const exp = tlsExpiry(c.tlsCree);
  if (!exp || c.archive) return null;
  const d = daysLeft(exp), when = frDate(exp);
  if (d < 0) return el('span', { className: 'chip exp bad', textContent: '⛔ Compte TLS expiré', title: `Expiré le ${when} : créez un nouveau compte` });
  if (d <= TLS_WARN_DAYS) return el('span', { className: 'chip tls-soon', textContent: `⏳ Compte TLS ${d} j`, title: `Le compte TLS expire le ${when} : nouveau compte à créer` });
  return null;
}

function item(c, i, isSel, fam) {
  const n = numOf(c), has = Number.isFinite(n);
  const hue = folderHue.get(c.dossier);
  const stub = el('div', { className: 'stub' + (hue == null ? ' nofolder' : ''), title: has ? `N° ${n}${c.dossier ? ' · ' + c.dossier : ''}` : 'Pas de N° : ✎ → N° dossier' },
    el('small', { textContent: 'N°' }), el('b', { className: has && String(n).length > 2 ? 'long' : '', textContent: has ? String(n) : '?' }));
  if (hue != null) stub.style.setProperty('--h', hue);
  const chips = [
    fam ? el('button', { className: 'chip-fam', textContent: `👨‍👩‍👧 Famille · ${fam.n}`, title: fam.open ? 'Cacher les membres' : 'Voir : ' + fam.names.join(', '),
      onclick: e => { e.stopPropagation(); fam.toggle(); } }) : null,
    LIENS[c.lien] && c.famille && !fam ? el('span', { className: 'chip', textContent: LIENS[c.lien] }) : null,
    c.pret ? el('span', { className: 'chip pret', textContent: '★ Prêt' }) : null,
    AAExtras.payChip(c),
    tlsChip(c),
    passportWarning(c),
    etapeOf(c) === 'manque' && c.manque ? el('span', { className: 'chip manque', textContent: '⚠ ' + c.manque }) : null,
    (folder === ALL || folder === ARCHIVE) && c.dossier ? el('span', { className: 'chip', textContent: '📁 ' + c.dossier }) : null,
    c.notes ? el('span', { className: 'chip', textContent: '📝 Note', title: c.notes }) : null,
  ].filter(Boolean);
  const body = el('div', { className: 'body', title: 'Cliquer pour remplir', onclick: () => { openId = c.id; render(); fill(c); } },
    el('div', { className: 'nm', textContent: fullName(c) }),
    el('div', { className: 'meta', textContent: [c.passeport, c.gmail || c.mobile].filter(Boolean).join('  ·  ') || 'Passeport et Gmail à compléter' }),
    chips.length ? el('div', { className: 'chips' }, ...chips) : null);
  const acts = el('div', { className: 'acts' },
    el('button', { className: 'bls login', textContent: 'TLS', title: c.gmail && c.tlsmdp ? `Se connecter à TLScontact (${c.gmail})` : 'Connexion TLS : ajoutez le Gmail et le mot de passe TLS (✎)', onclick: () => tlsLogin(c) }),
    el('button', { textContent: '✎', title: 'Ouvrir le dossier (modifier)', onclick: () => openEdit(c) }),
    el('button', { className: 'star', textContent: c.pret ? '★' : '☆', title: c.pret ? 'Retirer des prêts' : 'Marquer prêt (wajed)', onclick: () => toggleReady(c) }),
    el('button', { textContent: '⧉', title: 'Remplir case par case (valeurs du dossier)', onclick: () => { openId = openId === c.id ? null : c.id; render(); } }));
  const st = stamp(c);
  const ticket = el('div', { className: 'ticket' + (st ? ' has-stamp' : '') }, stub, el('i', { className: 'perf' }), body, st, acts);
  const details = openId === c.id ? fillSheet(c) : null;
  const more = fam ? el('button', { className: 'fam-arrow' + (fam.open ? ' open' : ''), title: fam.open ? 'Cacher la famille' : `Voir la famille (${fam.names.join(', ')})`,
    onclick: fam.toggle }, el('span', { textContent: fam.open ? '▴' : '▾' }), fam.open ? ' Cacher' : ` ${fam.n - 1} autre${fam.n > 2 ? 's' : ''}`) : null;
  return el('div', { className: 'item' + (c.pret ? ' pret' : '') + (c.archive ? ' archived' : '') + (isSel ? ' sel' : '') + (fam ? ' head' : '') }, ticket, details, more);
}

function renderSettings() {
  $('#checks').replaceChildren(...FIELDS.filter(([k]) => k !== 'code' && k !== 'tlsmdp').map(([k, label]) => el('label', {},
    el('input', {
      type: 'checkbox', checked: enabled.includes(k),
      onchange: e => {
        enabled = e.target.checked ? [...enabled, k] : enabled.filter(x => x !== k);
        chrome.storage.local.set({ enabled });
      },
    }), label)));
}
$('#gear').onclick = () => { $('#settings').hidden = !$('#settings').hidden; };

// ---- ⚙ Telegram (shared with the team through the sync) and «Vérifier maintenant» ----
async function loadTelegram() {
  const { teamSettings = {} } = await chrome.storage.local.get('teamSettings');
  const tg = teamSettings.telegram || {};
  $('#tgToken').value = tg.botToken || '';
  $('#tgChat').value = tg.chatId || '';
  $('#tlsUrl').value = teamSettings.tlsLoginUrl || '';
}
$('#tlsUrl').onchange = async () => {
  const { teamSettings = {} } = await chrome.storage.local.get('teamSettings');
  const v = $('#tlsUrl').value.trim();
  if (v && !/^https:\/\/([\w-]+\.)*tlscontact\.com\//i.test(v)) return toast('Collez un lien de tlscontact.com (https://…)', true);
  await chrome.storage.local.set({ teamSettings: { ...teamSettings, tlsLoginUrl: v || undefined } });
  toast(v ? '✓ Page de connexion TLS enregistrée' : 'Page de connexion TLS par défaut');
};
async function saveTelegram() {
  const { teamSettings = {} } = await chrome.storage.local.get('teamSettings');
  const telegram = { ...(teamSettings.telegram || {}), botToken: $('#tgToken').value.trim(), chatId: $('#tgChat').value.trim(), enabled: true };
  await chrome.storage.local.set({ teamSettings: { ...teamSettings, telegram } });
}
$('#tgToken').onchange = saveTelegram;
$('#tgChat').onchange = saveTelegram;
$('#tgFind').onclick = async () => {
  const r = await chrome.runtime.sendMessage({ type: 'telegram-chatid', token: $('#tgToken').value.trim() });
  if (!r?.ok) return toast(r?.error || 'Erreur', true);
  $('#tgChat').value = r.chatId;
  await saveTelegram();
  toast(`✓ Chat trouvé${r.name ? ' : ' + r.name : ''}`);
};
$('#tgTest').onclick = async () => {
  await saveTelegram();
  const r = await chrome.runtime.sendMessage({ type: 'telegram-test' });
  toast(r?.ok ? '✓ Message envoyé sur Telegram' : 'Telegram : ' + (r?.error || '?'), !r?.ok);
};
$('#checkNow').onclick = async () => {
  const r = await chrome.runtime.sendMessage({ type: 'alerts-check' });
  toast(r?.ok ? (r.sent ? `✓ ${r.sent} alerte(s) envoyée(s)` : '✓ Rien à signaler') : (r?.error || 'Erreur'), !r?.ok);
};
loadTelegram();

// ---- ⧉ «Remplir»: the client's values by part of the form, one click each ----
// Click a field on the site, then values here, in order: each one goes in its field and the cursor jumps to the
// next field (↧), so the form fills click after click. ✓ = already put this time.
let autoNext = true, putDone = new Set();
chrome.storage.local.get('autoNext').then(r => { if (r.autoNext === false) autoNext = false; });
const fvVal = (c, k) => c.fv?.[k];
function sheetGroups(c) {
  const core = k => [FIELDS.find(f => f[0] === k)[1], k, c[k]];
  const fv = k => [FV_FIELDS.find(f => f[0] === k)[1], k, fvVal(c, k)];
  const groupFv = i => FV_GROUPS[i][1].map(([k]) => fv(k));
  return [
    ['🛂 Passeport', [core('nom'), core('prenom'), core('naissance'), core('passeport'), core('delivre'), core('expire'), core('lieu'), ...groupFv(1)]],
    ['👤 Identité', groupFv(0)],
    ['🏠 Adresse et travail', [core('mobile'), ...groupFv(2)]],
    ['✈️ Voyage', groupFv(3)],
    ['🏨 Séjour', [...groupFv(4), ...groupFv(5)]],
    ['📧 Gmail et compte TLS', [core('gmail'), core('code'), core('tlsmdp')]],
    ['➕ Champs en plus', (c.extra || '').split('\n').map(l => l.split(/=(.*)/s)).filter(p => p[1] !== undefined).map(([l, v]) => [l.trim(), null, v.trim()])],
  ].map(([t, items]) => [t, items.filter(([, , v]) => v)]).filter(([, items]) => items.length);
}
function fillSheet(c) {
  const sheet = el('div', { className: 'sheet' },
    el('div', { className: 'sheet-head' },
      el('button', { className: 'primary', textContent: '⚡ Tout remplir', title: 'Remplir toutes les cases reconnues de la page', onclick: () => fill(c) }),
      el('label', { className: 'next-toggle', title: 'Après chaque valeur, le curseur passe à la case suivante du formulaire' },
        el('input', { type: 'checkbox', checked: autoNext, onchange: e => { autoNext = e.target.checked; chrome.storage.local.set({ autoNext }); } }), '↧ Case suivante'),
      el('button', { textContent: '↺', title: 'Effacer les ✓', onclick: () => { putDone = new Set([...putDone].filter(x => !x.startsWith(c.id + ':'))); render(); } })),
    el('div', { className: 'sheet-tip', textContent: 'Cliquez la 1ʳᵉ case sur le site, puis les valeurs dans l\'ordre.' }));
  for (const [title, items] of sheetGroups(c)) {
    const keys = items.map(([, k]) => k).filter(Boolean);
    sheet.append(el('div', { className: 'sheet-group' },
      el('div', { className: 'sheet-title' }, el('span', { textContent: title }),
        keys.length ? el('button', { className: 'small', textContent: 'Remplir', title: 'Remplir les cases reconnues de cette partie', onclick: () => fill(c, keys) }) : null),
      el('div', { className: 'sheet-vals' }, ...items.map(([label, k, raw]) => {
        const id = `${c.id}:${k || label}`;
        const shown = SECRETS.includes(k) ? '••••••' : show(k, raw);
        const b = el('button', { className: 'val' + (putDone.has(id) ? ' done' : '') + (['gmail', ...SECRETS].includes(k) ? ' gm' : ''), title: 'Cliquez une case du site, puis ici' },
          el('span', { textContent: label }), el('b', { textContent: shown }));
        b.onclick = async () => { if (await insertValue(label, k, raw, show(k, raw))) { putDone.add(id); b.classList.add('done'); } };
        return b;
      }))));
  }
  return sheet;
}

// Runs filler.js in the page. `frames`: undefined = main frame, true = all frames, [ids] = those frames.
async function runInTab(fn, arg, frames) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const target = { tabId: tab.id };
  if (frames === true) target.allFrames = true;
  else if (frames) target.frameIds = frames;
  await chrome.scripting.executeScript({ target, files: ['rules.js', 'filler.js'] });
  const res = await chrome.scripting.executeScript({
    target,
    func: (fn, arg) => globalThis.__agenceAutofill[fn](arg),
    args: [fn, arg ?? null],
  });
  return frames === true ? res : res[0].result;
}

async function fill(c, only) {
  try {
    const payload = { extra: only ? '' : c.extra };
    for (const k of enabled) payload[k] = c[k];
    for (const k of AA_FV_KEYS) if (c.fv?.[k]) payload[k] = c.fv[k];
    if (only) for (const k of Object.keys(payload)) if (k !== 'extra' && !only.includes(k)) delete payload[k];
    const res = await runInTab('fill', payload, true);
    const n = res.reduce((s, r) => s + (r.result?.filled.length || 0), 0);
    if (!n) return toast('Aucun champ reconnu : cliquez une case puis une valeur', true);
    toast(`✓ ${n} champs remplis`);
  } catch (e) {
    toast('Page protégée : cliquez une valeur pour la copier, puis Ctrl+V', true);
  }
}

async function insertValue(label, key, raw, shown) {
  try {
    // Frame where the user clicked a field most recently
    const times = await runInTab('lastTime', null, true);
    const best = times.reduce((a, b) => ((b.result || 0) > (a?.result || 0) ? b : a), null);
    const r = best?.result && await runInTab('insert', { key, value: raw, next: autoNext }, [best.frameId]);
    if (r) { toast(`✓ ${label} mis${r.moved ? ' — case suivante prête' : ''}`); return true; }
    if (!best?.result) { await navigator.clipboard.writeText(shown); toast(`Cliquez d'abord une case sur le site (${label} copié : Ctrl+V)`, true); return false; }
  } catch { /* page where extensions cannot write: copy instead */ }
  await navigator.clipboard.writeText(shown);
  toast(`${label} copié — cliquez la case et faites Ctrl+V`);
  return true;
}

async function capture() {
  try {
    const data = await runInTab('capture');
    if (!Object.keys(data).length) return toast('Aucune donnée trouvée sur la page', true);
    const same = data.passeport && clients.find(c => c.passeport === data.passeport);
    const fv = {};
    for (const k of AA_FV_KEYS) if (data[k]) { fv[k] = data[k]; delete data[k]; }
    openEdit(same ? { ...same, ...data, fv: { ...same.fv, ...fv } } : { ...data, fv });
  } catch (e) {
    toast('Impossible sur cette page (' + e.message + ')', true);
  }
}

function openEdit(c = {}, opt = {}) {
  editingId = c.id || null;
  pendingPdf = null;
  if (!opt.keepScan) {
    pendingPassport = null;
    $('#pread').hidden = true;
    $('#pstatus').textContent = '';
  }
  for (const [k] of FIELDS) form.elements[k].value = c[k] || '';
  form.elements.extra.value = c.extra || '';
  form.elements.num.value = c.num ?? ''; // the N° is typed by the user, never set automatically
  AAExtras.fillPay(form, c);
  AAExtras.renderWa($('#wa-box'), c);
  form.elements.lien.value = c.lien || '';
  editFamille = c.famille || '';
  for (const k of FOLLOW) form.elements[k].value = c[k] || '';
  if (!c.id && !c.etape) form.elements.etape.value = 'nouveau';
  for (const [k] of FV_FIELDS) form.elements['fv_' + k].value = c.fv?.[k] || '';
  renderFvCount();
  editArchive = !!c.archive;
  for (const i of document.querySelectorAll('.secret input')) i.classList.add('hide');
  for (const b of document.querySelectorAll('.secret .eye')) b.classList.remove('on');
  renderFollow();
  renderFamily();
  // New account goes into the folder currently open
  form.elements.dossier.value = editingId || c.dossier ? c.dossier || '' : (folder !== ALL && folder !== NONE && folder !== ARCHIVE ? folder : '');
  $('#dossier-list').replaceChildren(...folderNames().map(n => el('option', { value: n })));
  $('#edit-title').textContent = editingId ? fullName(c) : 'Nouveau client';
  wizard = !editingId; // a new client: one step at a time, the passport scan first
  setStep(1);
  $('#del').textContent = 'Supprimer';
  delete $('#del').dataset.armed;
  $('#list-view').hidden = true;
  form.hidden = false;
  if (wizard && !c.nom && !c.prenom) $('#pdrop').focus(); else form.elements.prenom.focus();
  renderFiles(editingId);
}

// ---- Files of the client (only here in ✎, never in the list) ----
async function renderFiles(id) {
  const box = $('#file-rows');
  const note = text => box.replaceChildren(el('div', { className: 'hint', textContent: text }));
  if (!id) return note('Enregistrez d\'abord le client, puis ✎ pour ajouter ses fichiers.');
  note('Chargement…');
  try {
    const lists = await Promise.all(AAFiles.SLOTS.map(([slot]) => AAFiles.list(id, slot)));
    if (editingId !== id) return; // form closed meanwhile
    box.replaceChildren(...AAFiles.SLOTS.map(([slot, label], i) => fileRow(id, slot, label, lists[i][0])));
  } catch (e) {
    if (editingId === id) note(e.message);
  }
}

function fileRow(id, slot, label, f) {
  const btn = (text, title, onclick, cls = '') => el('button', { type: 'button', textContent: text, title, onclick, className: cls });
  return el('div', { className: 'frow' },
    el('span', { className: 'flabel', textContent: label }),
    el('span', { className: 'fname', textContent: f ? '✓ ' + f.name : '—', title: f?.name || '' }),
    f && btn('👁', 'Ouvrir', () => AAFiles.open(f.path).catch(e => toast(e.message, true))),
    f && btn('🗑', 'Supprimer (2 clics)', e => deleteFile(e, id, f.path), 'danger'),
    btn(f ? 'Remplacer' : 'Ajouter', '', () => pickFile(id, slot)));
}

function pickFile(id, slot) {
  const inp = $('#upload');
  inp.accept = slot === 'photo' ? 'image/*' : 'image/*,.pdf';
  inp.onchange = async () => {
    const file = inp.files[0];
    inp.value = '';
    if (!file) return;
    toast('Envoi…');
    try {
      await AAFiles.upload(id, slot, file);
      toast('✓ Fichier ajouté');
    } catch (e) { toast(e.message, true); }
    if (editingId === id) renderFiles(id);
  };
  inp.click();
}

async function deleteFile(e, id, path) {
  const btn = e.currentTarget;
  if (!btn.dataset.armed) { btn.dataset.armed = '1'; btn.textContent = 'Sûr ?'; return; }
  try {
    await AAFiles.remove([path]);
    toast('Fichier supprimé');
  } catch (err) { toast(err.message, true); }
  if (editingId === id) renderFiles(id);
}

function closeEdit() {
  form.hidden = true;
  $('#list-view').hidden = false;
  render();
  $('#q').focus();
}

// Saves the open form (a new account gets its id here). false = not saved.
async function saveForm() {
  const data = Object.fromEntries(FIELDS.map(([k]) => [k, form.elements[k].value.trim()]));
  data.extra = form.elements.extra.value.trim();
  data.dossier = form.elements.dossier.value.trim();
  const num = form.elements.num.value.trim();
  data.num = num === '' ? undefined : +num;
  Object.assign(data, AAExtras.readPay(form));
  const twin = data.num !== undefined && clients.find(c => c.id !== editingId && numOf(c) === data.num);
  saveForm.warn = twin ? `Enregistré — attention : le N° ${data.num} est aussi celui de ${fullName(twin)}` : '';
  data.lien = form.elements.lien.value;
  data.famille = editFamille;
  for (const k of FOLLOW) data[k] = form.elements[k].value.trim() || undefined;
  const fv = {};
  for (const [k] of FV_FIELDS) { const v = form.elements['fv_' + k].value.trim(); if (v) fv[k] = v; }
  data.fv = Object.keys(fv).length ? fv : undefined;
  data.archive = editArchive || undefined;
  if (!data.nom && !data.prenom) { toast('Nom ou prénom obligatoire', true); return false; }
  if (editingId) Object.assign(clients.find(c => c.id === editingId), data);
  else { editingId = crypto.randomUUID(); clients.push({ id: editingId, ...data, ajout: await AA_newMeta() }); }
  await save();
  if (pendingPdf) { AAFiles.upload(editingId, 'formulaire', pendingPdf).catch(() => {}); pendingPdf = null; }
  if (pendingPassport) { AAFiles.upload(editingId, 'passeport', pendingPassport).catch(() => {}); pendingPassport = null; }
  return true;
}

form.onsubmit = async e => {
  e.preventDefault();
  if (!await saveForm()) return;
  toast(saveForm.warn || 'Client enregistré', !!saveForm.warn);
  closeEdit();
};

// ---- ✎ «Suivi du dossier» and «Compte TLS»: stage, missing documents, appointment, notes, archive ----
const FOLLOW = ['etape', 'manque', 'tlsCree', 'rdvDate', 'rdvHeure', 'rdvCentre', 'notes'];
let editArchive = false;
const today = () => new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);

function renderFollow() {
  const f = form.elements, et = f.etape.value;
  $('#manque-row').hidden = et !== 'manque';
  $('#rdv-rows').hidden = et !== 'rdv';
  // TLS account: expiry shown under the date, colored when a new account is due.
  const exp = tlsExpiry(f.tlsCree.value);
  const box = $('#tls-exp');
  if (!exp) { box.textContent = 'Date de création du compte TLS : il dure 3 mois.'; box.className = 'hint'; }
  else {
    const d = daysLeft(exp);
    box.className = 'hint tls-exp ' + (d < 0 ? 'bad' : d <= TLS_WARN_DAYS ? 'soon' : 'ok');
    box.textContent = d < 0 ? `⛔ Expiré le ${frDate(exp)} : créez un nouveau compte TLS`
      : d <= TLS_WARN_DAYS ? `⏳ Expire le ${frDate(exp)} (dans ${d} j) : nouveau compte à créer`
      : `✓ Valide jusqu'au ${frDate(exp)} (encore ${d} j)`;
  }
  // Archive: offered once the appointment is taken; an archived file can come back.
  const btn = $('#archive');
  btn.hidden = !editArchive && et !== 'rdv';
  btn.textContent = editArchive ? '↩ Sortir de l\'archive' : '📦 Archiver (RDV pris, dossier terminé)';
  btn.className = editArchive ? 'small' : 'small primary';
  $('#archived-note').hidden = !editArchive;
}
for (const k of ['etape', 'tlsCree']) form.elements[k].addEventListener('input', renderFollow);
$('#tls-today').onclick = () => { form.elements.tlsCree.value = today(); renderFollow(); toast('Compte TLS créé aujourd\'hui : il expire dans 3 mois'); };
$('#archive').onclick = async () => {
  editArchive = !editArchive;
  if (!(await saveForm())) { editArchive = !editArchive; return; }
  // A family is archived (or comes back) as a whole.
  const cur = clients.find(c => c.id === editingId);
  const group = cur.famille ? membersOf(cur.famille) : [cur];
  for (const m of group) { if (editArchive) { m.archive = true; m.pret = false; } else delete m.archive; }
  await save();
  const who = group.length > 1 ? `Famille ${cur.nom || fullName(cur)} (${group.length})` : fullName(cur);
  toast(editArchive ? `📦 ${who} archivé — voir «📦 Archive»` : `↩ ${who} remis dans la liste`);
  closeEdit();
};


// ---- ✎ France-Visas groups: each one a card, put in its slot (the step of the form it belongs to) ----
(function buildFv() {
  for (const slot of document.querySelectorAll('.fv-slot')) {
    const [title, fields] = FV_GROUPS[+slot.dataset.group];
    const grid = el('div', { className: 'grid' });
    for (const [k, label, kind] of fields) {
      const name = 'fv_' + k;
      let input;
      if (Array.isArray(kind)) {
        input = el('input', { name, autocomplete: 'off' });
        input.setAttribute('list', 'fvl-' + k);
        grid.append(el('datalist', { id: 'fvl-' + k }, ...kind.map(v => el('option', { value: v }))));
      } else input = el('input', { name, type: kind === 'date' ? 'date' : 'text', autocomplete: 'off' });
      input.addEventListener('input', renderFvCount);
      grid.append(el('label', { className: kind === 'wide' ? 'wide' : '' }, label, input));
    }
    const card = el('section', { className: 'card fv-card' }, el('div', { className: 'sec-title', textContent: title }), grid);
    card.dataset.step = slot.dataset.step;
    slot.replaceWith(card);
  }
})();
function renderFvCount() {
  const n = FV_FIELDS.filter(([k]) => form.elements['fv_' + k].value.trim()).length;
  $('#fv-count').textContent = `🇫🇷 ${n} / ${FV_FIELDS.length}`;
  $('#fv-count').title = `${n} champs France-Visas remplis sur ${FV_FIELDS.length}`;
}

// ---- 📄 PDF France-Visas → client: read in the panel (pdf.js, no internet), nothing is sent anywhere ----
let pdfjs;
async function readFvPdf(file) {
  if (!/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') throw new Error(`${file.name} : ce n'est pas un PDF`);
  if (!pdfjs) {
    pdfjs = await import(chrome.runtime.getURL('lib/pdf.min.mjs'));
    pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdf.worker.min.mjs');
  }
  const doc = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false, verbosity: 0 }).promise;
  const pages = [];
  for (let p = 1; p <= Math.min(doc.numPages, 3); p++) {
    const tc = await (await doc.getPage(p)).getTextContent();
    pages.push(tc.items.filter(i => i.str !== undefined).map(i => ({ s: i.str, x: i.transform[4], y: i.transform[5], w: i.width })));
  }
  doc.loadingTask?.destroy?.() ?? doc.cleanup?.();
  return AAFV.parse(pages);
}
const CORE_FROM_PDF = ['nom', 'prenom', 'naissance', 'passeport', 'delivre', 'expire', 'mobile'];

// Bottom bar: one or several PDFs → each updates its client (same passport, or same France-Visas reference) or makes a new one.
$('#fvImport').onclick = () => $('#fvFile').click();
$('#fvFile').onchange = async e => {
  const files = [...e.target.files];
  e.target.value = '';
  if (!files.length) return;
  const current = folder !== ALL && folder !== NONE && folder !== ARCHIVE ? folder : '';
  let added = 0, updated = 0, last = null;
  const errors = [];
  for (const file of files) {
    try {
      const r = await readFvPdf(file);
      const same = clients.find(c => (r.passeport && c.passeport === r.passeport) || (r.fv.reference && c.fv?.reference === r.fv.reference));
      const core = Object.fromEntries(CORE_FROM_PDF.filter(k => r[k]).map(k => [k, r[k]]));
      if (same) { Object.assign(same, core, { fv: { ...same.fv, ...r.fv } }); last = same; updated++; }
      else {
        last = { id: crypto.randomUUID(), ...core, fv: r.fv, etape: 'nouveau', ...(current && { dossier: current }), ajout: await AA_newMeta() };
        clients.push(last);
        added++;
      }
      // The PDF itself goes into the client's 📄 Formulaire (when connected ☁).
      AAFiles.upload(last.id, 'formulaire', file).catch(() => {});
    } catch (err) { errors.push(err.message); }
  }
  await save();
  render();
  if (errors.length) toast(errors[0], true);
  else toast(`📄 France-Visas : ${added} ajouté(s), ${updated} mis à jour`);
  if (files.length === 1 && last && !errors.length) openEdit(last); // one PDF: show what was read
};

// ✎: read a PDF into the open form (nothing saved until «Enregistrer»)
$('#fvFill').onclick = () => $('#fvFormFile').click();
$('#fvFormFile').onchange = async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const r = await readFvPdf(file);
    for (const k of CORE_FROM_PDF) if (r[k]) form.elements[k].value = r[k];
    for (const [k, v] of Object.entries(r.fv)) if (form.elements['fv_' + k]) form.elements['fv_' + k].value = v;
    renderFvCount();
    pendingPdf = file;
    toast(`✓ ${Object.keys(r.fv).length + CORE_FROM_PDF.filter(k => r[k]).length} champs lus — vérifiez puis Enregistrer`);
  } catch (err) { toast(err.message, true); }
};
let pendingPdf = null; // PDF read in ✎: stored in 📄 Formulaire once the client is saved


// ---- Steps: a new client goes one step at a time (scan first); ✎ shows all, the steps jump to their part ----
const STEPS = 6;
let wizard = false, step = 1;
function setStep(n) {
  step = Math.max(1, Math.min(STEPS, n));
  for (const sec of form.querySelectorAll('[data-step]')) sec.classList.toggle('on', +sec.dataset.step === step);
  for (const b of document.querySelectorAll('#steps button')) {
    const g = +b.dataset.go;
    b.className = (g === step ? 'cur' : '') + (wizard && g < step ? ' done' : '');
  }
  form.classList.toggle('wizard', wizard);
  $('#prev').hidden = !wizard || step === 1;
  $('#next').hidden = !wizard || step === STEPS;
  $('#saveBtn').hidden = wizard && step < STEPS;
  $('#del').hidden = wizard || !editingId;
  form.querySelector('.scroll').scrollTop = 0;
}
function goStep(n) {
  if (wizard) return setStep(n);
  // ✎: everything shows; scroll to the first card of that step
  form.querySelector(`[data-step="${n}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  for (const b of document.querySelectorAll('#steps button')) b.classList.toggle('cur', +b.dataset.go === n);
}
for (const b of document.querySelectorAll('#steps button')) b.onclick = () => goStep(+b.dataset.go);
$('#next').onclick = () => {
  if (step === 1 && !form.elements.nom.value.trim() && !form.elements.prenom.value.trim()) {
    return toast('Scannez le passeport ou tapez au moins le nom', true);
  }
  setStep(step + 1);
};
$('#prev').onclick = () => setStep(step - 1);

// ---- Step 1: passport photo read right here (same OCR as the scan page) ----
const NATIONS = { MAR: 'Marocaine', DZA: 'Algérienne', TUN: 'Tunisienne', FRA: 'Française', ESP: 'Espagnole', SEN: 'Sénégalaise', MRT: 'Mauritanienne', EGY: 'Égyptienne' };
let pendingPassport = null; // photo read in step 1: stored in 🛂 Passeport once the client is saved
let scanning = false;
async function scanPassport(file) {
  if (!file?.type?.startsWith('image/')) return toast('Choisissez une photo (JPG, PNG)', true);
  if (scanning) return toast('Lecture en cours… attendez', true);
  scanning = true;
  $('#pread').hidden = false;
  $('#pimg').src = URL.createObjectURL(file);
  const prog = $('#pprog');
  prog.hidden = false; prog.value = 0;
  const status = t => { $('#pstatus').textContent = t; };
  status('Préparation de la lecture… (la première fois prend quelques secondes)');
  try {
    const r = await AAOcr.readPassport(file, status, m => { if (m.status === 'recognizing text') prog.value = m.progress; });
    prog.hidden = true;
    if (!r) { status('✗ Lignes du bas (P<MAR…) introuvables : reprenez une photo plus nette, ou tapez à la main.'); return; }
    const f = form.elements;
    for (const k of ['prenom', 'nom', 'naissance', 'passeport', 'expire', 'delivre', 'lieu']) if (r[k]) f[k].value = r[k];
    if (r.nationalite && !f.fv_nationalite.value) f.fv_nationalite.value = NATIONS[r.nationalite] || r.nationalite;
    if (r.sexe && !f.fv_sexe.value) f.fv_sexe.value = r.sexe === 'M' ? 'Homme' : r.sexe === 'F' ? 'Femme' : '';
    if (r.nationalite === 'MAR' && !f.fv_delivrePar.value) f.fv_delivrePar.value = 'Maroc';
    if (r.passeport && !f.fv_typeDoc.value) f.fv_typeDoc.value = 'Passeport ordinaire';
    renderFvCount();
    pendingPassport = file;
    const ok = (b, l) => `${b ? '✓' : '✗'} ${l}`;
    status([ok(r.checks.passeport, 'N° passeport'), ok(r.checks.naissance, 'Naissance'), ok(r.checks.expire, 'Expire'),
      r.delivre ? '✓ Délivré (à vérifier)' : '✗ Délivré : à taper', r.lieu ? '✓ Lieu (à vérifier)' : '✗ Lieu : à taper'].join('  ·  ')
      + ' — vérifiez les noms, puis «Suivant →»');
    // Same passport already here: say so (Enregistrer will update that client, not make a twin).
    const same = !editingId && r.passeport && clients.find(c => c.passeport === r.passeport);
    if (same) { toast(`Ce passeport est déjà là : ${fullName(same)} — ouvert pour le compléter`); openEdit({ ...same, ...pickScan(r, f) }, { keepScan: true }); }
  } catch (e) {
    prog.hidden = true;
    status('Erreur de lecture : ' + e.message);
  } finally { scanning = false; }
}
const pickScan = (r, f) => Object.fromEntries(['prenom', 'nom', 'naissance', 'passeport', 'expire', 'delivre', 'lieu'].filter(k => f[k].value).map(k => [k, f[k].value]));
$('#pdrop').onclick = () => $('#pfile').click();
$('#pdrop').onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('#pfile').click(); } };
$('#pfile').onchange = e => { const f = e.target.files[0]; e.target.value = ''; if (f) scanPassport(f); };
$('#pdrop').ondragover = e => { e.preventDefault(); $('#pdrop').classList.add('over'); };
$('#pdrop').ondragleave = () => $('#pdrop').classList.remove('over');
$('#pdrop').ondrop = e => { e.preventDefault(); $('#pdrop').classList.remove('over'); scanPassport(e.dataTransfer.files[0]); };
// Ctrl+V of a photo anywhere in the open form = scan it
document.addEventListener('paste', e => {
  if (form.hidden) return;
  const img = [...(e.clipboardData?.files || [])].find(f => f.type.startsWith('image/'));
  if (!img) return;
  e.preventDefault();
  if (wizard) setStep(1);
  scanPassport(img);
});
$('#scanMany').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('scan.html') });

// ---- Family box in ✎ ----
let editFamille = '', linkable = new Map();
function renderFamily() {
  const others = membersOf(editFamille).filter(m => m.id !== editingId);
  $('#fam-members').replaceChildren(...others.map(m => el('button', {
    type: 'button', className: 'fam-m', title: 'Ouvrir (ce compte est enregistré d\'abord)',
    onclick: async () => { if (await saveForm()) openEdit(m); },
  }, el('span', { textContent: LIENS[m.lien] || '' }), fullName(m))));
  $('#fam-leave').hidden = !editFamille;
  linkable = new Map(clients.filter(c => c.id !== editingId && (!editFamille || c.famille !== editFamille))
    .map(c => [`${fullName(c)} · ${c.passeport || c.mobile || c.id.slice(0, 6)}`, c]));
  $('#fam-list').replaceChildren(...[...linkable.keys()].map(v => el('option', { value: v })));
}

// Gives the account being edited a family id (it becomes the head if it has no role yet).
function ensureFamily(cur) {
  if (!cur.famille) { cur.famille = crypto.randomUUID(); cur.lien ||= 'principal'; }
  editFamille = cur.famille;
  form.elements.lien.value = cur.lien;
}

$('#fam-add').onclick = async () => {
  if (!await saveForm()) return;
  const cur = clients.find(c => c.id === editingId);
  ensureFamily(cur);
  await save();
  const hasSpouse = membersOf(cur.famille).some(m => m.lien === 'conjoint');
  // Same name, folder and Gmail as the family (change them if needed).
  openEdit({ famille: cur.famille, lien: hasSpouse ? 'enfant' : 'conjoint', nom: cur.nom, dossier: cur.dossier, gmail: cur.gmail, code: cur.code });
  toast('Nouveau membre de la famille : complétez puis Enregistrer');
};

$('#fam-link').onchange = async e => {
  const other = linkable.get(e.target.value);
  e.target.value = '';
  if (!other || !await saveForm()) return;
  const cur = clients.find(c => c.id === editingId);
  if (!cur.famille && other.famille) cur.famille = other.famille;
  ensureFamily(cur);
  // The other account joins, with its whole family if it already had one.
  const old = other.famille;
  for (const c of clients) if (c === other || (old && c.famille === old)) c.famille = cur.famille;
  await save();
  renderFamily();
  toast(`✓ ${fullName(other)} ajouté à la famille`);
};

$('#fam-leave').onclick = () => {
  editFamille = '';
  form.elements.lien.value = '';
  renderFamily();
  toast('Retiré de la famille — cliquez Enregistrer pour confirmer');
};

$('#del').onclick = async () => {
  const btn = $('#del');
  if (!btn.dataset.armed) { btn.dataset.armed = '1'; btn.textContent = 'Cliquez encore pour supprimer'; return; }
  AAFiles.removeAll(editingId).catch(() => {}); // its files go too (if connected)
  clients = clients.filter(c => c.id !== editingId);
  await save();
  closeEdit();
};
$('#cancel').onclick = closeEdit;
// 👁 shows a hidden code; every form opening hides them again.
for (const b of document.querySelectorAll('.secret .eye')) {
  b.onclick = () => { const i = b.previousElementSibling; i.classList.toggle('hide'); b.classList.toggle('on', !i.classList.contains('hide')); };
}
$('#back').onclick = closeEdit;
$('#ver').textContent = 'v' + (chrome.runtime.getManifest?.().version || '');
$('#add').onclick = () => openEdit();
$('#capture').onclick = capture;
$('#newClient').onclick = () => openEdit();

$('#q').oninput = () => { selected = 0; render(); };
$('#q').onkeydown = e => {
  const list = filtered();
  if (e.key === 'ArrowDown') { selected = Math.min(selected + 1, list.length - 1); render(); e.preventDefault(); }
  if (e.key === 'ArrowUp') { selected = Math.max(selected - 1, 0); render(); e.preventDefault(); }
  if (e.key === 'Enter' && list[selected]) fill(list[selected]);
};

// ---- CSV import / export (Excel friendly: ";" separator, dates jj/mm/aaaa) ----
function parseCSV(text) {
  text = text.replace(/^﻿/, '');
  const first = text.split(/\r?\n/)[0];
  const sep = [';', ',', '\t'].sort((a, b) => first.split(b).length - first.split(a).length)[0];
  const rows = [];
  let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"' && text[i + 1] === '"') { cur += '"'; i++; }
      else if (ch === '"') q = false;
      else cur += ch;
    } else if (ch === '"') q = true;
    else if (ch === sep) { row.push(cur); cur = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cur); rows.push(row); row = []; cur = '';
    } else cur += ch;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(v => v.trim()));
}

$('#import').onclick = () => $('#file').click();
$('#file').onchange = async e => {
  const file = e.target.files[0];
  if (!file) return;
  const [head, ...rows] = parseCSV(await file.text());
  const special = { champsenplus: 'extra', dossier: 'dossier', code: 'code', codegmail: 'code', motdepasse: 'code', motdepassetls: 'tlsmdp', famille: 'famille', lien: 'lien', n: 'num', no: 'num', num: 'num', numero: 'num', ndossier: 'num', numerodossier: 'num',
    etape: 'etape', cequimanque: 'manque', manque: 'manque', comptetlscree: 'tlsCree', comptetlscreele: 'tlsCree', daterdv: 'rdvDate', rdv: 'rdvDate',
    heurerdv: 'rdvHeure', centre: 'rdvCentre', centrerdv: 'rdvCentre', notes: 'notes', archive: 'archive', archiv: 'archive',
    expirecomptetls: '', expiretls: '' };
  for (const [k, label] of FV_FIELDS) special[AA_norm(label)] ??= 'fv:' + k;
  for (const k of AA_FV_KEYS) special[AA_norm(FV_FIELDS.find(f => f[0] === k)[1])] = 'fv:' + k;
  const IMPORT_DATES = ['tlsCree', 'rdvDate'];
  const etapeKey = v => Object.keys(ETAPES).find(k => k === v || AA_norm(ETAPES[k][0]).includes(AA_norm(v))) || undefined;
  const keys = (head || []).map(h => (AA_norm(h) in special ? special[AA_norm(h)] : AA_match(h)));
  const current = folder !== ALL && folder !== NONE && folder !== ARCHIVE ? folder : '';
  if (!keys.includes('nom') && !keys.includes('prenom')) return toast('Colonnes Nom/Prénom introuvables', true);
  let added = 0, updated = 0;
  for (const r of rows) {
    const data = {};
    keys.forEach((k, i) => { if (k && r[i]?.trim()) data[k] = AA_DATES.includes(k) || IMPORT_DATES.includes(k) ? AA_toIso(r[i]) : r[i].trim(); });
    if (data.etape !== undefined) data.etape = etapeKey(data.etape);
    // France-Visas columns go to data.fv (also those matched by the fill rules, e.g. «Profession»)
    for (const k of Object.keys(data)) {
      const fk = k.startsWith('fv:') ? k.slice(3) : AA_FV_KEYS.includes(k) ? k : null;
      if (!fk) continue;
      (data.fv ||= {})[fk] = FV_DATES.includes(fk) ? AA_toIso(data[k]) || data[k] : data[k];
      delete data[k];
    }
    if (data.archive !== undefined) data.archive = /^(oui|1|x|yes|true)$/i.test(data.archive) || undefined;
    if (data.num !== undefined) { if (/^\d+$/.test(data.num)) data.num = +data.num; else delete data.num; }
    if (!data.nom && !data.prenom) continue;
    if (!data.dossier && current) data.dossier = current; // imported into the open folder
    const same = data.passeport && clients.find(c => c.passeport === data.passeport);
    if (same) { Object.assign(same, data); updated++; }
    else { clients.push({ id: crypto.randomUUID(), ...data, ajout: await AA_newMeta() }); added++; }
  }
  await save();
  e.target.value = '';
  render();
  toast(`${added} ajoutés, ${updated} mis à jour`);
};

$('#export').onclick = () => {
  const cell = v => (/[;"\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);
  const lines = [['N°', ...FIELDS.map(f => f[1]), 'Champs en plus', 'Dossier', 'Famille', 'Lien',
    'Étape', 'Ce qui manque', 'Compte TLS créé le', 'Expire compte TLS', 'Date RDV', 'Heure RDV', 'Centre RDV', 'Notes', 'Archivé',
    ...FV_FIELDS.map(f => f[1])].join(';'),
    ...[...clients].sort((a, b) => numOf(a) - numOf(b) || 0).map(c => [c.num ?? '', ...FIELDS.map(([k]) => cell(show(k, c[k]))), cell(c.extra || ''), cell(c.dossier || ''),
      c.famille || '', c.lien || '', ETAPES[c.etape]?.[0] || '', cell(c.manque || ''), frDate(c.tlsCree), frDate(tlsExpiry(c.tlsCree)),
      frDate(c.rdvDate), c.rdvHeure || '', cell(c.rdvCentre || ''), cell(c.notes || ''), c.archive ? 'oui' : '',
      ...FV_FIELDS.map(([k]) => cell(show(k, c.fv?.[k] || '')))].join(';'))];
  const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv' });
  el('a', { href: URL.createObjectURL(blob), download: `clients-${new Date().toISOString().slice(0, 10)}.csv` }).click();
};

// ---- Team sharing (☁): the background worker does the sync, this only logs in and shows the state ----
const preset = globalThis.AA_CONFIG || {};
$('#server-fields').hidden = !!(preset.supabaseUrl && preset.supabaseKey);
$('#cloudBtn').onclick = () => { $('#cloud').hidden = !$('#cloud').hidden; };

function renderCloud(st = {}) {
  const on = st.state !== 'off' && !!st.email;
  $('#cloudBtn').className = st.state === 'error' ? 'err' : on ? 'on' : '';
  $('#cloudBtn').title = on ? 'Partagé avec l\'équipe' : 'Non connecté : comptes seulement sur ce PC';
  $('#login').hidden = on;
  $('#logged').hidden = !on;
  const msg = on
    ? `☁ Connecté : <b></b> · ${st.live ? 'mise à jour en direct ✓' : 'synchro chaque minute'}`
    : 'Connectez-vous pour partager les comptes avec l\'équipe.';
  $('#cloud-status').innerHTML = msg;
  if (on) $('#cloud-status b').textContent = st.email || '';
  if (st.state === 'error') $('#cloud-status').append(el('div', { style: 'color:var(--danger)', textContent: 'Erreur : ' + st.error }));
}

$('#login').onsubmit = async e => {
  e.preventDefault();
  const f = e.target.elements;
  const btn = e.target.querySelector('button');
  btn.disabled = true;
  btn.textContent = 'Connexion…';
  const r = await chrome.runtime.sendMessage({
    type: 'login', url: f.url.value, key: f.key.value, email: f.email.value.trim(), password: f.password.value,
  });
  btn.disabled = false;
  btn.textContent = 'Se connecter';
  if (r?.ok) { f.password.value = ''; toast('Connecté ✓ les comptes sont partagés'); }
  else toast('Connexion impossible : ' + (r?.error || '?'), true);
};
$('#logout').onclick = async () => { await chrome.runtime.sendMessage({ type: 'logout' }); toast('Déconnecté'); };
$('#syncNow').onclick = async () => {
  await chrome.runtime.sendMessage({ type: 'sync-now' });
  toast('Synchronisé ✓');
};

// Changes from the scan page or from colleagues (via the background sync) show up right away.
chrome.storage.onChanged.addListener(ch => {
  // Always take the new list (a booking marks a client while a form may be open); the open form keeps its values.
  if (ch.clients) { clients = ch.clients.newValue || []; if (form.hidden) render(); }
  if (ch.syncStatus) renderCloud(ch.syncStatus.newValue);
  if (ch.teamSettings && $('#settings').hidden) loadTelegram();
});
chrome.storage.local.get(['syncStatus', 'syncConfig']).then(r => {
  renderCloud(r.syncStatus);
  if (r.syncConfig) { $('#login').elements.url.value = r.syncConfig.url; $('#login').elements.key.value = r.syncConfig.key; }
});
chrome.runtime.sendMessage({ type: 'sync-now' }).catch(() => {});

chrome.storage.local.get(['clients', 'enabled', 'dossiers', 'folder', 'famOpen']).then(r => {
  clients = r.clients || [];
  famOpen = new Set(r.famOpen || []);
  if (r.enabled) enabled = r.enabled;
  // Gmail is new: switch it on once for PCs that saved their ⚙ choice before it existed.
  if (!enabled.includes('gmail') && !r.enabled?.includes('-gmail')) {
    enabled.push('gmail', '-gmail');
    chrome.storage.local.set({ enabled });
  }
  dossiers = r.dossiers || [];
  folder = r.folder ?? ALL;
  renderSettings();
  render();
});

// ---- «À faire aujourd'hui» (taches.js): the automatic tasks, from the clients ----
function showClient(c) {
  folder = c.archive ? ARCHIVE : ALL; view = 'all'; openId = null; selected = 0;
  $('#q').value = `${c.prenom || ''} ${c.nom || ''}`.trim() || c.passeport || '';
  render();
  $('#list .sel')?.scrollIntoView({ block: 'center' });
}
// «TLS» on a client: the service worker (tlslogin.js) opens TLScontact and signs in with its Gmail + TLS password.
async function tlsLogin(c) {
  if (!c.gmail || !c.tlsmdp) return toast('Ajoutez le Gmail et le mot de passe TLS du client (✎ → Gmail et compte TLS)', true);
  const win = await chrome.windows.getCurrent().catch(() => null);
  const r = await chrome.runtime.sendMessage({ type: 'tls-login', clientId: c.id, windowId: win?.id }).catch(e => ({ ok: false, error: e.message }));
  toast(r?.ok ? `Connexion TLS : ${fullName(c)}…` : (r?.error || 'Connexion TLS impossible'), !r?.ok);
}

// ✎ «💰 Paiement»: price, payments, «Tout payé» (extras.js)
AAExtras.wirePay(form);

AATaches.init({
  clients: () => clients,
  show: showClient,
  auto: today => {
    const out = [], at = h => (h ? ' à ' + h : '');
    for (const c of clients) {
      if (c.archive) continue;
      if (c.etape === 'rdv' && c.rdvDate) {
        const d = dayDiff(c.rdvDate);
        if (d === 0) out.push({ key: `rdv0:${c.id}:${c.rdvDate}`, icon: '🗓', rank: 1, time: c.rdvHeure, client: c, text: `RDV TLS aujourd'hui${at(c.rdvHeure)}` });
        if (d === 1) out.push({ key: `rdv1:${c.id}:${c.rdvDate}`, icon: '🗓', rank: 4, time: c.rdvHeure, client: c, text: `RDV TLS demain${at(c.rdvHeure)} : préparer le dossier` });
      }
      if (tlsDue(c)) {
        const e = tlsExpiry(c.tlsCree), d = daysLeft(e);
        out.push({ key: `tls:${c.id}:${e}`, icon: '⏳', rank: d < 0 ? 2 : 5, client: c,
          text: d < 0 ? 'Compte TLS expiré : créer un nouveau compte' : `Compte TLS expire dans ${d} j : créer le nouveau` });
      }
      // «Il manque»: a reminder to call the client, once a day.
      if (c.etape === 'manque') out.push({ key: `manque:${c.id}:${today}`, icon: '📎', rank: 6, client: c, text: `Relancer : il manque ${c.manque || 'des documents'}` });
    }
    return out;
  },
});

// What is new in this version: shown to the team members who still have an older one (update.js).
AAUpdate.init([
  "Mise à jour automatique : une fois installée sur le PC (installer-maj.cmd), chaque nouvelle version arrive toute seule",
  "Bouton « TLS » sur chaque client : ouvre TLScontact, répond Oui/Oui, remplit l'email et le mot de passe",
  "💰 Paiement et 💬 WhatsApp dans chaque dossier (✎)",
  "☀️ Chaque matin à 8h30, résumé de la journée sur Telegram"
]);
