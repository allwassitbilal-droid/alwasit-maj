-- Agence Autofill : base partagée de l'équipe.
-- À coller dans Supabase → SQL Editor → New query → Run (une seule fois).

create table if not exists public.clients (
  id text primary key,
  data jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by text
);

-- Seuls les comptes de l'équipe (connectés) peuvent lire / écrire. Personne d'autre.
revoke all on public.clients from anon;
grant select, insert, update, delete on public.clients to authenticated;
alter table public.clients enable row level security;

drop policy if exists "equipe lit" on public.clients;
drop policy if exists "equipe ajoute" on public.clients;
drop policy if exists "equipe modifie" on public.clients;
drop policy if exists "equipe supprime" on public.clients;

create policy "equipe lit" on public.clients for select to authenticated using (true);
create policy "equipe ajoute" on public.clients for insert to authenticated with check (true);
create policy "equipe modifie" on public.clients for update to authenticated using (true) with check (true);
create policy "equipe supprime" on public.clients for delete to authenticated using (true);

-- Mises à jour en direct pour tout le monde.
alter publication supabase_realtime add table public.clients;
