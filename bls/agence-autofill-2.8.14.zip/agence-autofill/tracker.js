// Runs in every page: remembers the last form field the user clicked,
// so a value clicked in the side panel can be put into it.
document.addEventListener('focusin', e => {
  const t = e.target;
  if (t.matches?.('input, textarea, select, [contenteditable=""], [contenteditable="true"]')) {
    globalThis.__aaLast = { el: t, t: Date.now() };
  }
}, true);
