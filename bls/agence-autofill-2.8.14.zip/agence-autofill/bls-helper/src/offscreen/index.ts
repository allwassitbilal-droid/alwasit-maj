import type { OffscreenRequest } from "../shared/messages";

const BEEPS = 8;
const FREQ_HZ = 880;
const GAP_S = 0.4;
const LEN_S = 0.2;

chrome.runtime.onMessage.addListener((msg: OffscreenRequest) => {
  if (msg?.type !== "offscreen-beep") return;
  const ctx = new AudioContext();
  for (let i = 0; i < BEEPS; i++) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain).connect(ctx.destination);
    osc.frequency.value = FREQ_HZ;
    gain.gain.value = 0.25;
    osc.start(ctx.currentTime + i * GAP_S);
    osc.stop(ctx.currentTime + i * GAP_S + LEN_S);
  }
  setTimeout(() => void ctx.close(), (BEEPS * GAP_S + 1) * 1000);
});
