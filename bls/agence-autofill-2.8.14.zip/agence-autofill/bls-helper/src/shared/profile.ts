// Applicant profile used to pre-fill BLS forms, plus the pure logic that decides which field is which.
// The profile follows the Schengen visa application form section by section (1. personal details ...
// 7. accommodation); section 8, the BLS account, lives with each family member (profiles.ts).
// Field detection reads a field's label/name/placeholder text in Arabic, French and English.

export type Gender = "" | "male" | "female";

export type FieldKind = "text" | "date" | "choice";

export interface Choice {
  value: string;
  ar: string;
}

export interface FieldDef {
  key: ProfileKey;
  /** Arabic label, shown in the settings page and fill reports. */
  ar: string;
  /** The form's French label, shown under it. */
  fr: string;
  kind: FieldKind;
  choices?: readonly Choice[];
  placeholder?: string;
}

export interface Section {
  n: number;
  title: string;
  fr: string;
  fields: readonly FieldDef[];
}

const PROFILE_KEYS = [
  // 1. personal details
  "lastName",
  "birthSurname",
  "firstName",
  "birthDate",
  "birthPlace",
  "birthCountry",
  "nationality",
  "nationalityAtBirth",
  "gender",
  "maritalStatus",
  // 2. trip
  "travelPurpose",
  "destinationState",
  "firstEntryState",
  "entries",
  "arrivalDate",
  "departureDate",
  // 3. passport
  "passportType",
  "passportNumber",
  "passportIssueDate",
  "passportExpiryDate",
  "passportIssuedBy",
  "passportIssuePlace",
  "nationalId",
  // 4. contact
  "address",
  "city",
  "postalCode",
  "email",
  "phone",
  // 5. work
  "occupation",
  "employerName",
  "employerAddress",
  "employerCity",
  "employerPostalCode",
  "employerEmail",
  "employerPhone",
  "jobDetails",
  // 6. biometrics and visa history
  "fingerprintsTaken",
  "fingerprintsDate",
  "previousVisaNumber",
  "previousVisaExpiry",
  // 7. accommodation in Spain
  "accommodationType",
  "hostName",
  "hostAddress",
  "hostCity",
  "hostPostalCode",
  "hostPhone",
  "hostEmail",
] as const;

export type ProfileKey = (typeof PROFILE_KEYS)[number];
export type Profile = Record<ProfileKey, string>;

export const PROFILE_KEY = "profile";

export const EMPTY_PROFILE: Profile = Object.fromEntries(PROFILE_KEYS.map((k) => [k, ""])) as Profile;

const text = (key: ProfileKey, ar: string, fr: string, placeholder?: string): FieldDef => ({ key, ar, fr, kind: "text", ...(placeholder ? { placeholder } : {}) });
const date = (key: ProfileKey, ar: string, fr: string): FieldDef => ({ key, ar, fr, kind: "date" });
const choice = (key: ProfileKey, ar: string, fr: string, choices: readonly Choice[]): FieldDef => ({ key, ar, fr, kind: "choice", choices });

/** The Schengen visa application form, in its own order and numbering. */
export const SECTIONS: readonly Section[] = [
  {
    n: 1,
    title: "المعلومات الشخصية",
    fr: "Informations personnelles",
    fields: [
      text("lastName", "الاسم العائلي (النسب)", "Nom de famille", "ALAOUI"),
      text("birthSurname", "الاسم العائلي عند الولادة", "Nom de naissance"),
      text("firstName", "الاسم الشخصي", "Prénom", "MOHAMED"),
      date("birthDate", "تاريخ الازدياد", "Date de naissance"),
      text("birthPlace", "مكان الازدياد", "Lieu de naissance"),
      text("birthCountry", "بلد الازدياد", "Pays de naissance", "Maroc"),
      text("nationality", "الجنسية الحالية", "Nationalité actuelle", "Marocaine"),
      text("nationalityAtBirth", "الجنسية عند الولادة", "Nationalité à la naissance"),
      choice("gender", "الجنس", "Sexe", [
        { value: "male", ar: "ذكر" },
        { value: "female", ar: "أنثى" },
      ]),
      choice("maritalStatus", "الحالة العائلية", "État civil", [
        { value: "single", ar: "عازب(ة)" },
        { value: "married", ar: "متزوج(ة)" },
        { value: "divorced", ar: "مطلق(ة)" },
        { value: "widowed", ar: "أرمل(ة)" },
      ]),
    ],
  },
  {
    n: 2,
    title: "تفاصيل الرحلة",
    fr: "Détails du voyage",
    fields: [
      choice("travelPurpose", "الهدف من السفر", "Motif principal du voyage", [
        { value: "tourism", ar: "سياحة" },
        { value: "family", ar: "زيارة عائلية" },
        { value: "business", ar: "أعمال" },
        { value: "studies", ar: "دراسة" },
      ]),
      text("destinationState", "وجهة السفر الرئيسية", "État membre de destination principale", "Espagne"),
      text("firstEntryState", "دولة أول دخول لشنغن", "État membre de première entrée", "Espagne"),
      choice("entries", "عدد مرات الدخول", "Nombre d'entrées demandées", [
        { value: "one", ar: "دخول واحد" },
        { value: "two", ar: "دخولين" },
        { value: "multi", ar: "دخول متعدد" },
      ]),
      date("arrivalDate", "تاريخ الدخول المتوقع", "Date d'entrée prévue"),
      date("departureDate", "تاريخ المغادرة المتوقع", "Date de départ prévue"),
    ],
  },
  {
    n: 3,
    title: "جواز السفر",
    fr: "Informations sur le passeport",
    fields: [
      choice("passportType", "نوع وثيقة السفر", "Type de document de voyage", [
        { value: "ordinary", ar: "جواز عادي" },
        { value: "service", ar: "جواز خدمة" },
      ]),
      text("passportNumber", "رقم الجواز", "Numéro de passeport"),
      date("passportIssueDate", "تاريخ الإصدار", "Date de délivrance"),
      date("passportExpiryDate", "تاريخ انتهاء الصلاحية", "Date d'expiration"),
      text("passportIssuedBy", "صادر عن (البلد)", "Délivré par (pays)", "Maroc"),
      text("passportIssuePlace", "مكان الإصدار", "Lieu de délivrance"),
      text("nationalId", "رقم البطاقة الوطنية", "Numéro d'identification nationale (CIN)"),
    ],
  },
  {
    n: 4,
    title: "العنوان والاتصال",
    fr: "Coordonnées et adresse",
    fields: [
      text("address", "العنوان الكامل", "Adresse complète"),
      text("city", "المدينة", "Ville"),
      text("postalCode", "الرمز البريدي", "Code postal"),
      text("email", "البريد الإلكتروني", "Adresse e-mail"),
      text("phone", "الهاتف المحمول", "Téléphone mobile", "+212..."),
    ],
  },
  {
    n: 5,
    title: "المهنة والعمل",
    fr: "Informations professionnelles",
    fields: [
      text("occupation", "المهنة الحالية", "Profession actuelle", "Employé, Étudiant..."),
      text("employerName", "اسم الشركة / المؤسسة", "Nom de l'employeur / établissement"),
      text("employerAddress", "عنوان مقر العمل", "Adresse de l'employeur"),
      text("employerCity", "مدينة مقر العمل", "Ville de l'employeur"),
      text("employerPostalCode", "الرمز البريدي لمقر العمل", "Code postal de l'employeur"),
      text("employerEmail", "البريد الإلكتروني لمقر العمل", "E-mail de l'employeur"),
      text("employerPhone", "هاتف مقر العمل", "Téléphone de l'employeur"),
      text("jobDetails", "تفاصيل المهنة / المنصب", "Intitulé du poste"),
    ],
  },
  {
    n: 6,
    title: "البصمات والتأشيرات السابقة",
    fr: "Données biométriques et historique",
    fields: [
      choice("fingerprintsTaken", "واش سبق خداو ليك البصمات؟", "Empreintes déjà relevées ?", [
        { value: "no", ar: "لا" },
        { value: "yes", ar: "نعم" },
      ]),
      date("fingerprintsDate", "تاريخ أخذ البصمات", "Date de prise d'empreintes"),
      text("previousVisaNumber", "رقم التأشيرة السابقة", "Numéro de la vignette visa"),
      date("previousVisaExpiry", "تاريخ انتهاء التأشيرة السابقة", "Date d'expiration du visa"),
    ],
  },
  {
    n: 7,
    title: "الإقامة فإسبانيا",
    fr: "Hébergement / garant",
    fields: [
      choice("accommodationType", "نوع الإقامة", "Type d'hébergement", [
        { value: "hotel", ar: "فندق" },
        { value: "invitation", ar: "استضافة (عائلة / صديق)" },
      ]),
      text("hostName", "اسم الفندق أو المستضيف", "Nom de l'hôtel ou du garant"),
      text("hostAddress", "عنوان الإقامة", "Adresse de l'hébergement"),
      text("hostCity", "المدينة", "Ville"),
      text("hostPostalCode", "الرمز البريدي", "Code postal"),
      text("hostPhone", "هاتف الفندق / المستضيف", "Téléphone de l'hébergement"),
      text("hostEmail", "البريد الإلكتروني", "E-mail de l'hébergement"),
    ],
  },
];

const FIELDS: readonly FieldDef[] = SECTIONS.flatMap((s) => s.fields);
const FIELD = Object.fromEntries(FIELDS.map((f) => [f.key, f])) as Record<ProfileKey, FieldDef>;

export const DATE_KEYS: ReadonlySet<ProfileKey> = new Set(FIELDS.filter((f) => f.kind === "date").map((f) => f.key));
export const CHOICE_KEYS: ReadonlySet<ProfileKey> = new Set(FIELDS.filter((f) => f.kind === "choice").map((f) => f.key));

/** Arabic labels, used in the options page and in fill reports. */
export const PROFILE_LABELS: Record<ProfileKey, string> = Object.fromEntries(FIELDS.map((f) => [f.key, f.ar])) as Record<ProfileKey, string>;

/** The fields a passport + contact details cover: what "the profile is complete" means. */
export const CORE_KEYS: readonly ProfileKey[] = [...SECTIONS[0]!.fields, ...SECTIONS[2]!.fields, ...SECTIONS[3]!.fields]
  .map((f) => f.key)
  .filter((k) => !["birthSurname", "nationalityAtBirth", "maritalStatus", "nationalId", "passportType"].includes(k));

export function normalizeProfile(raw: unknown): Profile {
  const r = typeof raw === "object" && raw !== null ? (raw as Record<string, unknown>) : {};
  const out = { ...EMPTY_PROFILE };
  for (const key of PROFILE_KEYS) {
    const v = r[key];
    if (typeof v !== "string") continue;
    const t = v.trim();
    const f = FIELD[key];
    if (f.kind === "choice") out[key] = f.choices!.some((c) => c.value === t) ? t : "";
    else if (f.kind === "date") out[key] = /^\d{4}-\d{2}-\d{2}$/.test(t) ? t : "";
    else out[key] = t;
  }
  return out;
}

/**
 * The value to fill for a field: the profile's own, or a sensible fallback (a passport is issued by
 * the holder's country; the first entry is usually the destination; the passport is usually ordinary).
 */
export function fieldValue(p: Profile, key: ProfileKey): string {
  if (p[key]) return p[key];
  if (key === "passportIssuedBy") return p.nationality;
  if (key === "firstEntryState") return p.destinationState;
  if (key === "passportType") return "ordinary";
  return "";
}

// ---- which profile field a form control is ----

const EMPLOYER_RE = /employer|employeur|company|entreprise|soci[ée]t[ée]|institut|[ée]tablissement|صاحب العمل|جهة العمل|الشركة|المؤسسة|مقر العمل/;
const HOST_RE = /\bhost|h[ôo]te\b|h[ôo]tel|accommodation|h[ée]bergement|المستضيف|الفندق|الإقامة/;

/** For employer / host blocks: which of their own fields this is. */
function subField(d: string, prefix: "employer" | "host"): ProfileKey {
  if (/postal|zip|code postal|الرمز البريدي/.test(d)) return `${prefix}PostalCode`;
  if (/\be[- ]?mail|courriel|البريد/.test(d)) return `${prefix}Email`;
  if (/phone|t[ée]l[ée]phone|(?<!\p{L})tel(?!\p{L})|contact ?n|هاتف/u.test(d)) return `${prefix}Phone`;
  if (/\bcity\b|ville|المدينة/.test(d)) return `${prefix}City`;
  if (/address|adresse|العنوان/.test(d)) return `${prefix}Address`;
  return `${prefix}Name`;
}

/**
 * Checked before the skip list: fields that name another party or a variant ("... at birth",
 * "issued by", employer, host) but that the Schengen form profile does hold.
 */
const PRIORITY: ReadonlyArray<readonly [ProfileKey | ((d: string) => ProfileKey | null), RegExp]> = [
  ["birthSurname", /(surname|name|nom) (at|à la) (birth|naissance)|nom de naissance|اسم الولادة|(الاسم|النسب) عند الولادة/],
  // \S, not \w: "nationalité" (é isn't a \w character).
  ["nationalityAtBirth", /nationalit\S* (at|à la) (birth|naissance)|الجنسية عند الولادة/],
  ["birthCountry", /country of birth|birth ?country|pays de naissance|بلد (الميلاد|الازدياد)/],
  ["passportIssuedBy", /issued by|issuing country|issue ?country|country of issue|d[ée]livr[ée] par|pays de d[ée]livrance|صادر عن|بلد (الإصدار|الاصدار)/],
  ["passportType", /(passport|document) ?type|type (de|of) (document|passeport|passport)|نوع (الوثيقة|وثيقة السفر|جواز|الجواز)/],
  ["nationalId", /national ?id|identification nationale|\bcin\b|البطاقة الوطنية|الهوية الوطنية/],
  ["previousVisaExpiry", /visa.*(valid|expir)|(valid|expir).*visa|انتهاء التأشيرة/],
  ["previousVisaNumber", /(visa|vignette).*(number|num[ée]ro|n°)|(number|num[ée]ro).*(visa|vignette)|رقم التأشيرة/],
  [(d) => (/date/.test(d) ? "fingerprintsDate" : "fingerprintsTaken"), /fingerprint|empreintes|البصمات/],
  ["accommodationType", /(accommodation|h[ée]bergement) ?type|type (of|d.)? ?(accommodation|h[ée]bergement)|نوع الإقامة/],
  [(d) => subField(d, "employer"), EMPLOYER_RE],
  [(d) => subField(d, "host"), HOST_RE],
  ["maritalStatus", /marital|civil status|[ée]tat civil|situation familiale|الحالة العائلية|الحالة الاجتماعية/],
  ["travelPurpose", /purpose of (the )?(journey|travel|trip|visit|stay)|main purpose|motif (principal )?(du |de )?voyage|but du voyage|الهدف من السفر|الغرض من/],
  ["firstEntryState", /first entry|premi[èe]re entr[ée]e|أول دخول/],
  ["destinationState", /(state|country) of (main )?destination|main destination|destination principale|[ée]tat membre de destination|وجهة/],
  ["entries", /number of entries|entries requested|nombre d.entr[ée]es|عدد مرات الدخول/],
  ["arrivalDate", /(date of|intended) (arrival|entry)|arrival date|date d.(arriv[ée]e|entr[ée]e)|تاريخ (الدخول|الوصول)/],
  ["departureDate", /(date of|intended) departure|departure date|date de (d[ée]part|sortie)|تاريخ المغادرة/],
  ["jobDetails", /job title|intitul[ée] du poste|تفاصيل المهنة|المنصب/],
  ["occupation", /occupation|profession|m[ée]tier|المهنة/],
];

/**
 * Ordered rules: the first match wins, so specific rules (passport expiry, place of birth)
 * come before generic ones (any date of birth, any name).
 */
const RULES: ReadonlyArray<readonly [ProfileKey, RegExp]> = [
  ["passportExpiryDate", /expir|expiry|valid(ity| until)|date d'?expiration|fin de validit|valable jusqu|انتهاء|صلاحية|صالح حتى/],
  ["passportIssuePlace", /place of issue|issue ?place|issu(ed|ing) (at|place|authority)|lieu de d[ée]livrance|autorit[ée]|مكان (الإصدار|الاصدار)|جهة (الإصدار|الاصدار)/],
  ["passportIssueDate", /issue ?date|date of issue|issued on|date de d[ée]livrance|d[ée]livr[ée] le|تاريخ (الإصدار|الاصدار)/],
  ["passportNumber", /passport|passeport|جواز|travel ?doc/],
  ["birthPlace", /place of birth|birth ?place|lieu de naissance|مكان (الميلاد|الازدياد|الولادة)/],
  ["birthDate", /birth|naissance|\bdob\b|الميلاد|الازدياد|الولادة/],
  ["postalCode", /postal|zip|code postal|الرمز البريدي/],
  // "e mail": labels reach here with "-" turned into a space, and PDFs split "E - mail".
  ["email", /\be[- ]?mail|courriel|البريد/],
  // "tel" as a word of its own: \b would also match inside "hôtel" (ô isn't an ASCII word character).
  ["phone", /phone|mobile|t[ée]l[ée]phone|(?<!\p{L})tel(?!\p{L})|gsm|contact ?n(o|umber)|الهاتف|الجوال/u],
  ["address", /address|adresse|العنوان/],
  ["city", /\bcity\b|ville|المدينة/],
  ["nationality", /nationalit|الجنسية/],
  ["gender", /gender|\bsex\b|sexe|الجنس/],
  ["firstName", /first ?name|given ?name|forename|pr[ée]nom|\bfname\b|الاسم الشخصي|الاسم الأول/],
  ["lastName", /last ?name|surname|family ?name|nom de famille|\blname\b|^nom\b|الاسم العائلي|اللقب|النسب/],
];

/**
 * Fields that mention a known word but must not be filled from the applicant's profile: other
 * people's sections on the BLS form (sponsor, guardian, EU family member, contact person), residence
 * permits, and the appointment's own type/category pickers.
 * Labels taken from the site's /locales/{lang}/formTemplate.json.
 */
const SKIP_RE = new RegExp(
  [
    String.raw`\btype\b|category|cat[ée]gorie|visa|نوع|فئة`,
    String.raw`sponsor|guardian|invitee|contact person|family member|eu ?family`,
    String.raw`garant|tuteur|membre de (la )?famille|personne de contact`,
    String.raw`الكفيل|الراعي|الوصي|الشخص المسؤول|أفراد الأسرة`,
    String.raw`permit|permis|تصريح`,
  ].join("|"),
);

/**
 * Other people's blocks and residence permits, which the priority rules must not claim either
 * (a guardian's address is not the host's; "تصريح الإقامة" is a permit, not accommodation).
 */
const OTHER_PARTY_RE =
  /sponsor|guardian|eu ?family|family member|contact person|tuteur|personne de contact|membre de (la )?famille|permit|permis|الكفيل|الوصي|الشخص المسؤول|أفراد الأسرة|تصريح/;

/** Picks the profile field a form control represents from its descriptive text, or null. */
export function classifyField(descriptor: string): ProfileKey | null {
  const d = descriptor
    .replace(/([a-z])([A-Z])/g, "$1 $2") // passportNumber -> passport Number (before lowercasing)
    .toLowerCase()
    .replace(/[_\-.*:]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!d || OTHER_PARTY_RE.test(d)) return null;
  for (const [key, re] of PRIORITY) if (re.test(d)) return typeof key === "function" ? key(d) : key;
  if (SKIP_RE.test(d)) return null;
  for (const [key, re] of RULES) if (re.test(d)) return key;
  return null;
}

/** Formats an ISO date for a text input, following its placeholder hint when there is one. */
export function formatDateFor(iso: string, hint: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!m) return iso;
  const [, y, mo, d] = m;
  const h = hint.toLowerCase();
  if (/y{4}[-/.]m{2}[-/.]d{2}|a{4}[-/.]m{2}[-/.]j{2}/.test(h)) return `${y}-${mo}-${d}`;
  if (/m{2}[-/.]d{2}[-/.]y{4}/.test(h)) return `${mo}/${d}/${y}`;
  const sep = /[jd]{2}([-.])m{2}/.exec(h)?.[1] ?? "/";
  return `${d}${sep}${mo}${sep}${y}`;
}

/** How each choice shows up as an option on the BLS form (fr / en / ar). */
const CHOICE_RE: Record<string, RegExp> = {
  male: /^(m|male|man|homme|masculin|ذكر)$/,
  female: /^(f|female|woman|femme|f[ée]minin|أنثى|انثى)$/,
  single: /single|c[ée]libataire|عازب/,
  married: /married|mari[ée]|متزوج/,
  divorced: /divorc|مطلق/,
  widowed: /widow|veu(f|ve)|أرمل/,
  tourism: /touris|سياح/,
  family: /famil|visit|زيارة/,
  business: /business|affaire|أعمال/,
  studies: /stud|[ée]tude|دراسة/,
  one: /single|one|une|unique|^1$|واحد/,
  two: /two|double|deux|^2$|دخولين/,
  multi: /multi|متعدد/,
  ordinary: /ordinary|ordinaire|normal|عادي/,
  service: /service|خدمة/,
  hotel: /h[ôo]tel|فندق/,
  invitation: /invit|host|h[ôo]te|private|particuli|استضاف/,
  yes: /^(yes|oui|نعم)$/,
  no: /^(no|non|لا)$/,
};

/** French country names the profile may hold, to their English form (BLS lists countries in English). */
const COUNTRY_ALIASES: Record<string, string> = {
  maroc: "morocco",
  marocaine: "moroccan",
  marocain: "moroccan",
  espagne: "spain",
  allemagne: "germany",
  italie: "italy",
  belgique: "belgium",
  "pays-bas": "netherlands",
  suisse: "switzerland",
  autriche: "austria",
  grèce: "greece",
  algérie: "algeria",
  tunisie: "tunisia",
  "المغرب": "morocco",
  "مغربية": "moroccan",
  "مغربي": "moroccan",
  "إسبانيا": "spain",
};

/** Keys holding a country or nationality, matched with aliases and a shared stem. */
const COUNTRY_KEYS: ReadonlySet<ProfileKey> = new Set([
  "nationality",
  "nationalityAtBirth",
  "birthCountry",
  "passportIssuedBy",
  "destinationState",
  "firstEntryState",
]);

/** Index of the option (by visible text or value) that best represents value, or -1. */
export function matchOption(options: ReadonlyArray<{ text: string; value: string }>, key: ProfileKey, value: string): number {
  const norm = (s: string) => s.trim().toLowerCase();
  if (CHOICE_KEYS.has(key)) {
    const re = CHOICE_RE[value];
    return re ? options.findIndex((o) => re.test(norm(o.text)) || re.test(norm(o.value))) : -1;
  }
  const raw = norm(value);
  if (!raw) return -1;
  for (const v of COUNTRY_KEYS.has(key) && COUNTRY_ALIASES[raw] ? [raw, COUNTRY_ALIASES[raw]] : [raw]) {
    const exact = options.findIndex((o) => norm(o.text) === v || norm(o.value) === v);
    if (exact >= 0) return exact;
    const loose = options.findIndex((o) => norm(o.text).startsWith(v) || (v.length >= 4 && norm(o.text).includes(v)));
    if (loose >= 0) return loose;
    if (!COUNTRY_KEYS.has(key)) continue;
    // "Moroccan" vs a country list's "Morocco": accept a shared stem, but only when a single option has it.
    const stem = v.slice(0, Math.max(5, v.length - 3));
    const hits = options.flatMap((o, i) => (norm(o.text).startsWith(stem) ? [i] : []));
    if (hits.length === 1) return hits[0]!;
  }
  return -1;
}

/** The signup form's passport type picker, and the option nearly every applicant has. */
export const PASSPORT_TYPE_RE = /passport ?type|type (of|de) (passport|passeport)|نوع (جواز|الجواز)/i;
export const ORDINARY_PASSPORT_RE = /ordinary|ordinaire|normal|عادي/i;

/** A phone input holding nothing but the country prefix the site pre-fills ("+212"). */
export const isDialCodeOnly = (v: string): boolean => /^\+\d{1,4}$/.test(v.trim());

/**
 * The profile phone in international form for an input that may already show a dial code:
 * "0612345678" in a "+212" field becomes "+212612345678"; "+33..." and "0033..." are kept as given.
 */
export function phoneForInput(phone: string, current: string): string {
  const p = phone.replace(/[\s\-().]/g, "");
  if (!p || p.startsWith("+")) return p;
  if (p.startsWith("00")) return `+${p.slice(2)}`;
  const dial = isDialCodeOnly(current) ? current.trim() : "";
  if (!dial) return p;
  const cc = dial.slice(1);
  if (p.startsWith("0")) return dial + p.slice(1);
  return p.startsWith(cc) && p.length > cc.length + 8 ? `+${p}` : dial + p;
}

/** Digits only, to compare a phone value with what a formatting input displays. */
export const phoneDigits = (v: string): string => v.replace(/\D/g, "");
