// Fills the login form with the active client's account and submits it, then keeps submitting until
// the login goes through (BLS is often busy and drops logins). The site is an SPA, so the form is
// watched for rather than looked up once. Settings are read live, so switching Relogin on from the
// toolbar takes effect without a reload.
// Agence Autofill change: no 2-per-2-minutes / 4-per-hour limit. The only stop is BLS saying the email
// or password is wrong, so a wrong password isn't retried until the account gets locked.
import type { Account, Settings } from "../shared/settings";
import { setNativeValue } from "./util";

/** First click comes this long after filling (the site's form must take the values in). */
const SUBMIT_DELAY_MS = 500;

export const BAD_LOGIN_TEXT = "🔒 BLS قال الإيميل ولا المودباس غالط: وقفت الدخول الأوتوماتيكي. صلح المودباس فالفيشة ديال الكليان (✎) وعاود";

/** BLS's own error saying the credentials are wrong (not a busy server, which is worth retrying). */
const BAD_CREDENTIALS_RE =
  /invalid (e-?mail|email|user|password|credentials|login)|incorrect|wrong (e-?mail|password)|identifiants? (invalide|incorrect)|mot de passe (incorrect|erron|invalide)|غير صحيح|خاطئ|خاطئة|غلط/i;

/** Messages the page shows near the form: alerts, toasts, red error texts. */
export function badCredentialsShown(root: ParentNode = document): boolean {
  const els = root.querySelectorAll('[role="alert"], [data-sonner-toast], [class*="destructive"], [class*="error"], .alert-danger');
  // "Captcha incorrect" is not about the account: keep trying.
  return [...els].some((e) => BAD_CREDENTIALS_RE.test(e.textContent ?? "") && !/captcha/i.test(e.textContent ?? ""));
}

/**
 * Starts watching for the login form; returns a function that re-checks it now (after a settings change).
 * onBlocked is told once when BLS says the credentials are wrong.
 */
export function startAutoLogin(settings: () => Settings, account: () => Account, onBlocked: (text: string) => void = () => {}): () => void {
  let queued = false;
  let stopped = false; // wrong credentials: no more auto-submits until the account changes
  let lastSubmit = 0;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let stoppedFor = "";

  // Exactly one password field: a change-password or signup form must never get the saved password.
  const loginForm = () => {
    const passwords = document.querySelectorAll<HTMLInputElement>('input[type="password"]');
    const emailEl = document.querySelector<HTMLInputElement>("input#email, input[name='email']");
    const passEl = document.querySelector<HTMLInputElement>("input#password, input[name='password']");
    return passwords.length === 1 && emailEl && passEl && passwords[0] === passEl ? { emailEl, passEl } : null;
  };

  const tryFill = () => {
    queued = false;
    const s = settings();
    const a = account();
    if (stoppedFor && stoppedFor !== `${a.email}\n${a.password}`) { stopped = false; stoppedFor = ""; } // account edited
    if (!s.enabled || !s.autoLogin || !a.email || !a.password) return;
    const form = loginForm();
    if (!form) return;
    if (badCredentialsShown()) {
      if (!stopped) { stopped = true; stoppedFor = `${a.email}\n${a.password}`; onBlocked(BAD_LOGIN_TEXT); }
      return;
    }
    // (Re)fill when the form is new or the site emptied it after a failed try.
    if (form.emailEl.value !== a.email) setNativeValue(form.emailEl, a.email);
    if (form.passEl.value !== a.password) setNativeValue(form.passEl, a.password);
    if (!s.autoSubmit || stopped || timer) return;
    // Gap between two clicks while still on the login form: «Login(s)» in the BLS bar.
    const retryMs = s.loginRetrySec * 1000;
    const wait = Math.max(SUBMIT_DELAY_MS, lastSubmit + retryMs - Date.now());
    timer = setTimeout(() => {
      timer = undefined;
      const f = loginForm();
      if (!f || stopped || !settings().autoSubmit) return;
      const button = f.passEl.closest("form")?.querySelector<HTMLButtonElement>("button[type='submit']");
      if (!button || button.disabled) return void setTimeout(tryFill, 300); // request still running
      lastSubmit = Date.now();
      button.click();
      setTimeout(tryFill, retryMs); // still on the form then: try again
    }, wait);
  };

  tryFill();
  new MutationObserver(() => {
    if (queued) return;
    queued = true;
    setTimeout(tryFill, 50); // not requestAnimationFrame: it never fires in a hidden tab
  }).observe(document.documentElement, { childList: true, subtree: true });
  return tryFill;
}
