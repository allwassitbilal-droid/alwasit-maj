// Alerts of Autofill TLS (service worker): Windows notification + sound + Telegram.
//  1. TLS accounts: a TLScontact account lasts 3 months from «Compte TLS créé le». A warning goes 7 days before
//     (a new account has to be made), and again once it has expired.
//  2. Passports that expire within 6 months, or have expired.
//  3. New clients (one Telegram per batch, from the PC that added them).
// Each warning goes once per client and date (c.tlsAlert / c.expAlert, synced, so other PCs don't send it again).
// Archived clients (RDV taken, file closed) get no warning.
(() => {
  const local = chrome.storage.local;
  const NOTIF_PREFIX = 'tls:';
  const TLS_MONTHS = 3;
  const TLS_WARN_DAYS = 7;
  const PASS_WARN_DAYS = 183;
  const DAY = 864e5;

  const fullName = c => `${c.prenom || ''} ${c.nom || ''}`.trim() || '(sans nom)';
  const frDate = iso => (iso ? iso.split('-').reverse().join('/') : '');
  const at = iso => new Date(iso + 'T12:00:00').getTime();
  const telegramOf = async () => ((await local.get('teamSettings')).teamSettings || {}).telegram || {};

  // ---- TLS account: created + 3 months (same day of month, or the month's last day) ----
  function tlsExpiry(c) {
    if (!c.tlsCree || !/^\d{4}-\d{2}-\d{2}$/.test(c.tlsCree)) return '';
    const [y, m, d] = c.tlsCree.split('-').map(Number);
    const last = new Date(Date.UTC(y, m - 1 + TLS_MONTHS + 1, 0)).getUTCDate();
    const e = new Date(Date.UTC(y, m - 1 + TLS_MONTHS, Math.min(d, last)));
    return e.toISOString().slice(0, 10);
  }
  function tlsStage(c, now = Date.now()) {
    const exp = tlsExpiry(c);
    if (!exp || c.archive) return '';
    const left = (at(exp) - now) / DAY;
    return left < 0 ? 'expired' : left <= TLS_WARN_DAYS ? 'soon' : '';
  }
  function passportStage(c, now = Date.now()) {
    if (!c.expire || c.archive) return '';
    const left = (at(c.expire) - now) / DAY;
    return left < 0 ? 'expired' : left < PASS_WARN_DAYS ? 'soon' : '';
  }
  globalThis.AATls = { tlsExpiry, tlsStage, passportStage };

  // ---- sending ----
  async function beep() {
    try {
      if (!(await chrome.offscreen.hasDocument())) {
        await chrome.offscreen.createDocument({
          url: 'sound/offscreen.html', reasons: ['AUDIO_PLAYBACK'], justification: 'Play an alert sound for client warnings',
        });
        await new Promise(r => setTimeout(r, 200));
      }
      await chrome.runtime.sendMessage({ type: 'offscreen-beep' });
    } catch { /* no sound: the notification still shows */ }
  }

  async function telegram(token, method, body) {
    const init = { signal: AbortSignal.timeout(10_000) };
    if (body) Object.assign(init, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    return (await fetch(`https://api.telegram.org/bot${encodeURIComponent(token)}/${method}`, init)).json();
  }
  async function sendTelegram(tg, text) {
    if (!tg?.botToken || !tg?.chatId) return { ok: false, error: 'خاص التوكن و chat id' };
    try {
      const r = await telegram(tg.botToken, 'sendMessage', { chat_id: tg.chatId, text: `🛂 Autofill TLS\n${text}` });
      return r.ok ? { ok: true } : { ok: false, error: r.description || 'Telegram رفض الرسالة' };
    } catch (e) { return { ok: false, error: e.message }; }
  }
  async function findChatId(token) {
    if (!token) return { ok: false, error: 'دخل التوكن ديال البوت أولا' };
    try {
      const r = await telegram(token, 'getUpdates');
      if (!r.ok) return { ok: false, error: r.description || 'التوكن غلط' };
      const chat = [...(r.result || [])].reverse().find(u => u.message)?.message?.chat;
      if (!chat) return { ok: false, error: 'صيفط أي رسالة للبوت ديالك فـ Telegram وعاود' };
      return { ok: true, chatId: String(chat.id), name: chat.first_name || chat.title || chat.username || '' };
    } catch (e) { return { ok: false, error: e.message }; }
  }

  function notifyPc(title, message) {
    beep();
    chrome.notifications.create(`${NOTIF_PREFIX}${Date.now()}`, {
      type: 'basic', iconUrl: 'sound/icon.png', title, message: message.slice(0, 900), priority: 2, requireInteraction: true,
    });
  }
  // Click on a warning opens the panel's window in front.
  chrome.notifications.onClicked.addListener(async id => {
    if (!id.startsWith(NOTIF_PREFIX)) return;
    chrome.notifications.clear(id);
    const [w] = await chrome.windows.getAll({ windowTypes: ['normal'] });
    if (w) chrome.windows.update(w.id, { focused: true });
  });

  // ---- the check (every 6 hours, at start, and from the panel's «Vérifier maintenant») ----
  /** Warnings due now, with the text of each kind; `force` = warn again even about the ones already sent. */
  function report(clients, now = Date.now(), force = false) {
    const due = (stageOf, mark) => clients.filter(c => { const st = stageOf(c, now); return st && (force || mark(c) !== `${st}:${markDate(c, stageOf)}`); });
    const markDate = (c, stageOf) => (stageOf === tlsStage ? tlsExpiry(c) : c.expire);
    const tls = due(tlsStage, c => c.tlsAlert), pass = due(passportStage, c => c.expAlert);
    const days = iso => Math.ceil((at(iso) - now) / DAY);
    const tlsLine = c => { const e = tlsExpiry(c); const d = days(e);
      return `• ${c.num != null ? `N°${c.num} ` : ''}${fullName(c)}${c.gmail ? ` (${c.gmail})` : ''}: ${frDate(e)}` + (d >= 0 ? ` — باقي ${d} يام` : ''); };
    const passLine = c => { const d = days(c.expire);
      return `• ${fullName(c)}${c.passeport ? ` (${c.passeport})` : ''}: ${frDate(c.expire)}` + (d >= 0 ? ` — باقي ${d} يوم` : ''); };
    const part = (list, st, head, line) => { const l = list.filter(c => st(c, now) === head[0]); return l.length ? `${head[1]}\n${l.map(line).join('\n')}` : ''; };
    const tlsText = [
      part(tls, tlsStage, ['soon', '⏳ كونطات TLS غادي يساليو من هنا لسيمانة، خاص تصاوب كونط جديد:'], tlsLine),
      part(tls, tlsStage, ['expired', '⛔ كونطات TLS سالاو، خاص كونط جديد:'], tlsLine),
    ].filter(Boolean).join('\n\n');
    const passText = [
      part(pass, passportStage, ['soon', '⚠️ باسبورات غادي يساليو قبل 6 شهور:'], passLine),
      part(pass, passportStage, ['expired', '⛔ باسبورات ساليين:'], passLine),
    ].filter(Boolean).join('\n\n');
    return { tls, pass, tlsText, passText };
  }

  let checking = null;
  function check(force = false) {
    checking ||= checkOnce(force).finally(() => { checking = null; });
    return checking;
  }
  async function checkOnce(force) {
    // Several PCs run this: a random wait lets the first one's marks arrive by sync before the others look.
    if (!force) await new Promise(r => setTimeout(r, Math.random() * 20_000));
    const { clients = [] } = await local.get('clients');
    const r = report(clients, Date.now(), force);
    if (!r.tls.length && !r.pass.length) return { ok: true, sent: 0 };
    // The PC always shows the TLS accounts warning (a new account to make this week).
    if (r.tlsText) notifyPc(`⏳ Comptes TLS à renouveler (${r.tls.length})`, r.tlsText);
    const tg = await telegramOf();
    let tgError = '';
    if (tg.botToken && tg.chatId) {
      const text = [r.tlsText, r.passText].filter(Boolean).join('\n\n');
      const s = await sendTelegram(tg, text);
      if (!s.ok) tgError = s.error;
    } else if (!r.tlsText) {
      return { ok: false, error: 'Telegram pas configuré (⚙ → Telegram)' }; // passports: Telegram only
    }
    const { clients: fresh = [] } = await local.get('clients');
    for (const c of fresh) {
      if (r.tls.some(d => d.id === c.id)) c.tlsAlert = `${tlsStage(c)}:${tlsExpiry(c)}`;
      if (!tgError && tg.botToken && r.pass.some(d => d.id === c.id)) c.expAlert = `${passportStage(c)}:${c.expire}`;
    }
    await local.set({ clients: fresh });
    return tgError ? { ok: false, error: 'Telegram : ' + tgError } : { ok: true, sent: r.tls.length + r.pass.length };
  }

  chrome.alarms.create('tls-alerts', { delayInMinutes: 1, periodInMinutes: 6 * 60 });
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'tls-alerts') { check(); sendNewClients().catch(() => {}); } });

  // A TLS account date just set or changed: check that client within a minute, not in up to 6 hours.
  let soonTimer;
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.teamSettings?.newValue?.telegram?.chatId && !ch.teamSettings?.oldValue?.telegram?.chatId) check();
    if (ch.clients) {
      const old = new Map((ch.clients.oldValue || []).map(c => [c.id, c.tlsCree]));
      if ((ch.clients.newValue || []).some(c => c.tlsCree && old.get(c.id) !== c.tlsCree)) {
        clearTimeout(soonTimer);
        soonTimer = setTimeout(() => check(), 30_000);
      }
    }
  });

  // ---- New clients: one Telegram per batch, from the PC that created them (c.ajout, rules.js) ----
  const NEW_MAX_AGE_MS = 24 * 3600_000;
  const NEW_MAX_LINES = 25;
  let newTimer;
  async function sendNewClients() {
    const tg = await telegramOf();
    if (!tg.botToken || !tg.chatId) return;
    const { clients = [], deviceId } = await local.get(['clients', 'deviceId']);
    const mine = clients.filter(c => c.ajout && !c.ajout.sent && c.ajout.pc === deviceId);
    if (!mine.length) return;
    const fresh = mine.filter(c => Date.now() - (c.ajout.at || 0) < NEW_MAX_AGE_MS);
    if (fresh.length) {
      const line = c => `• ${fullName(c).toUpperCase()}${c.dossier ? ` · 📁 ${c.dossier}` : ''}${c.passeport ? ` · ${c.passeport}` : ''}`;
      const by = [...new Set(fresh.map(c => c.ajout.by).filter(Boolean))].join(', ');
      const text = `➕ ${fresh.length > 1 ? `${fresh.length} كليان جداد` : 'كليان جديد'}${by ? ` — زادو: ${by}` : ''}\n`
        + fresh.slice(0, NEW_MAX_LINES).map(line).join('\n') + (fresh.length > NEW_MAX_LINES ? `\n… و ${fresh.length - NEW_MAX_LINES} آخرين` : '');
      const r = await sendTelegram(tg, text);
      if (!r.ok) return;
    }
    const { clients: now = [] } = await local.get('clients');
    for (const c of now) if (mine.some(m => m.id === c.id)) c.ajout = { ...c.ajout, sent: true };
    await local.set({ clients: now });
  }
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || !ch.clients) return;
    const before = new Set((ch.clients.oldValue || []).map(c => c.id));
    if (!(ch.clients.newValue || []).some(c => !before.has(c.id) && c.ajout && !c.ajout.sent)) return;
    clearTimeout(newTimer);
    newTimer = setTimeout(() => sendNewClients().catch(() => {}), 4000);
  });

  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    const job = msg?.type === 'alerts-check' ? check(true)
      : msg?.type === 'telegram-test' ? telegramOf().then(tg => sendTelegram(tg, '✅ تجربة: التنبيهات واصلة لهاد الشات'))
      : msg?.type === 'telegram-chatid' ? findChatId(msg.token)
      : null;
    if (!job) return false;
    job.then(reply, e => reply({ ok: false, error: e.message }));
    return true;
  });
})();
