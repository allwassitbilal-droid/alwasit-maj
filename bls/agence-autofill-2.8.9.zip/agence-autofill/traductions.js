// «📝 Traductions» in the panel (same file in Autofill TLS and Autofill BLS): the documents the agency has
// translated for its clients. One row per document in the Supabase table "traductions" (supabase-traductions.sql
// in alwasit-maj), shared with the phone's «Traductions» tab: same fields, same table. Needs ☁ (the team login);
// the background worker gives a fresh token for each call (files-auth, like files.js).
// A document stays in the list until someone deletes it (🗑, two clicks): nothing goes away by itself.
// data: { id, type, client, de, vers, pages, prix, paye, etat, traducteur, envoi, livraison, remise, notes, cree, by }
// envoi = sent to the translator, livraison = to give back by, remise = given back to the client.
globalThis.AATrad = (() => {
  const TABLE = 'traductions';
  const ETATS = { traducteur: '✍️ Chez le traducteur', prete: '✅ Prête', remise: '📦 Remise au client' };
  const TYPES = ['Acte de naissance', 'Copie intégrale', 'Fiche anthropométrique (casier)', 'Certificat de résidence', 'Attestation de travail',
    'Bulletins de paie', 'Relevé bancaire', 'Attestation de scolarité', 'Diplôme', 'Relevé de notes', 'Acte de mariage', 'Livret de famille',
    'Certificat de vie individuelle', 'Registre de commerce', 'Attestation CNSS', 'Contrat de travail', 'Permis de conduire', 'Jugement'];
  const LANGUES = ['Arabe', 'Français', 'Espagnol', 'Anglais', 'Allemand', 'Italien', 'Néerlandais', 'Portugais'];
  const FILTERS = [['', 'Toutes'], ['cours', 'En cours'], ['prete', '✅ Prêtes'], ['remise', '📦 Remises'], ['reste', '💰 Reste']];
  const el = (tag, props = {}, ...kids) => {
    const e = Object.assign(document.createElement(tag), props);
    e.append(...kids.filter(k => k != null && k !== false));
    return e;
  };
  const say = (m, bad) => (globalThis.toast ? globalThis.toast(m, bad) : console.log(m));
  const ymd = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const norm = s => String(s ?? '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const frDate = iso => (iso ? iso.split('-').reverse().join('/') : '');
  const money = n => `${Number(n).toLocaleString('fr-FR')} DH`;
  const amount = v => {
    const n = parseFloat(String(v ?? '').replace(/\s/g, '').replace(',', '.'));
    return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) / 100 : undefined;
  };
  const pay = d => {
    const prix = amount(d.prix);
    if (prix === undefined) return null;
    const paye = amount(d.paye) || 0;
    return { prix, paye, reste: Math.max(0, Math.round((prix - paye) * 100) / 100) };
  };
  const added = ms => { if (!ms) return ''; const d = new Date(ms); return `ajoutée le ${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const langs = d => [d.de, d.vers].filter(Boolean).join(' → ');
  const late = d => d.livraison && d.etat !== 'remise' && d.livraison < ymd();

  let rows = [], loaded = false, me = '', ui = { q: '', f: '' }, editing = null, armed = false, timer = null;

  // ---- Server (PostgREST with the team login) ----
  async function api(path, opts = {}) {
    const a = await chrome.runtime.sendMessage({ type: 'files-auth' });
    if (!a?.token) throw new Error('Connectez-vous (☁) pour voir les traductions de l\'équipe');
    const r = await fetch(`${a.url}/rest/v1/${path}`, {
      ...opts, headers: { apikey: a.key, Authorization: 'Bearer ' + a.token, 'Content-Type': 'application/json', ...opts.headers },
    });
    if (!r.ok) {
      const m = (await r.json().catch(() => ({}))).message || 'erreur ' + r.status;
      throw new Error(/traductions/.test(m) ? 'Tableau «traductions» absent : lancez supabase-traductions.sql dans Supabase' : m);
    }
    return r;
  }
  async function load() {
    try {
      const out = [];
      for (let from = 0; ; from += 1000) {
        const r = await api(`${TABLE}?select=id,data`, { headers: { Range: `${from}-${from + 999}` } });
        const data = await r.json();
        out.push(...data.map(x => ({ ...x.data, id: x.id })));
        if (data.length < 1000) break;
      }
      rows = out;
      loaded = true;
      const { syncStatus } = await chrome.storage.local.get('syncStatus');
      me = syncStatus?.email || me;
    } catch (e) {
      if (!loaded) box().replaceChildren(el('p', { className: 'tr-empty', textContent: e.message }));
      return say(e.message, true);
    }
    if (!editing) list();
  }
  async function upsert(data) {
    await api(TABLE, { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify({ id: data.id, data, updated_at: new Date().toISOString(), updated_by: me || null }) });
  }
  async function del(id) {
    await api(`${TABLE}?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE' });
  }

  // ---- View ----
  const view = () => document.querySelector('#trad-view');
  const box = () => document.querySelector('#trad-body');
  function show() {
    document.querySelector('#list-view').hidden = true;
    view().hidden = false;
    editing = null;
    if (loaded) list(); else box().replaceChildren(el('p', { className: 'tr-empty', textContent: 'Chargement…' }));
    load();
    clearInterval(timer);
    timer = setInterval(() => { if (!view().hidden && !editing) load(); }, 60e3); // a document added on the phone shows within a minute
  }
  function hide() {
    clearInterval(timer);
    view().hidden = true;
    document.querySelector('#list-view').hidden = false;
  }

  function results() {
    const q = norm(ui.q.trim());
    let r = rows;
    if (ui.f === 'cours') r = r.filter(d => d.etat !== 'remise');
    else if (ui.f === 'prete' || ui.f === 'remise') r = r.filter(d => d.etat === ui.f);
    else if (ui.f === 'reste') r = r.filter(d => pay(d)?.reste > 0);
    if (q) r = r.filter(d => norm(`${d.client} ${d.type} ${d.de} ${d.vers} ${d.traducteur} ${d.notes}`).includes(q));
    return [...r].sort((x, y) => (y.cree || 0) - (x.cree || 0)); // newest first, one under the other
  }

  function item(d) {
    const p = pay(d);
    return el('li', { className: 'tr-item', onclick: () => form(d) },
      el('div', { className: 'tr-pages' }, el('b', { textContent: d.pages ? String(d.pages) : '–' }), el('span', { textContent: +d.pages > 1 ? 'pages' : 'page' })),
      el('div', { className: 'tr-main' },
        el('div', { className: 'tr-type', textContent: d.type || '(type ?)' }),
        el('div', { className: 'tr-meta', textContent: [d.client && '👤 ' + d.client, langs(d) && '🌐 ' + langs(d)].filter(Boolean).join('  ') }),
        d.traducteur || d.envoi || d.remise ? el('div', { className: 'tr-meta', textContent: [d.traducteur && '✍️ ' + d.traducteur, d.envoi && '📤 envoyé le ' + frDate(d.envoi).slice(0, 5), d.remise && '📦 remis le ' + frDate(d.remise).slice(0, 5)].filter(Boolean).join('  ') }) : null,
        el('div', { className: 'tr-tags' },
          d.etat ? el('span', { className: 'tr-tag ' + d.etat, textContent: ETATS[d.etat] || d.etat }) : null,
          d.livraison && d.etat !== 'remise' ? el('span', { className: 'tr-tag' + (late(d) ? ' late' : ''), textContent: `${late(d) ? '⏰ En retard' : '📅 Pour le'} ${frDate(d.livraison).slice(0, 5)}` }) : null,
          p ? el('span', { className: 'tr-tag ' + (p.reste > 0 ? 'due' : 'prete'), textContent: p.reste > 0 ? `💰 Reste ${money(p.reste)}` : `✓ Payé ${money(p.prix)}` }) : null),
        d.cree ? el('div', { className: 'tr-added', textContent: added(d.cree) + (d.by ? ' · ' + d.by.split('@')[0] : '') }) : null));
  }

  function list() {
    editing = null;
    const q = el('input', { placeholder: 'Chercher : client, document, langue…', value: ui.q, autocomplete: 'off' });
    const ul = el('ul', { className: 'tr-list' });
    const count = el('div', { className: 'tr-count' });
    const chips = el('div', { className: 'tr-chips' });
    const fillList = () => {
      chips.replaceChildren(...FILTERS.map(([v, t]) => el('button', { type: 'button', className: ui.f === v ? 'on' : '', textContent: t, onclick: () => { ui.f = v; fillList(); } })));
      const r = results();
      count.textContent = `${r.length} document${r.length > 1 ? 's' : ''}`;
      ul.replaceChildren(...(r.length ? r.slice(0, 500).map(item) : [el('li', { className: 'tr-empty', textContent: rows.length ? 'Aucun document trouvé.' : 'Aucune traduction. ＋ pour ajouter un document.' })]));
    };
    q.oninput = () => { ui.q = q.value; fillList(); };
    const reste = rows.reduce((s, d) => s + (pay(d)?.reste || 0), 0);
    const sum = el('div', { className: 'tr-sum' },
      el('div', {}, el('b', { textContent: String(rows.filter(d => d.etat !== 'remise').length) }), el('span', { textContent: 'en cours' })),
      el('div', {}, el('b', { textContent: String(rows.filter(late).length) }), el('span', { textContent: 'en retard' })),
      el('div', {}, el('b', { className: reste ? 'due' : '', textContent: reste ? money(reste) : '0' }), el('span', { textContent: 'reste à payer' })));
    box().replaceChildren(q, chips, sum, count, ul);
    fillList();
    document.querySelector('#trad-title').textContent = '📝 Traductions';
  }

  function form(d) {
    const isNew = !d;
    d = d ? { ...d } : { etat: 'traducteur', de: 'Arabe', vers: 'Français', envoi: ymd() };
    editing = d;
    armed = false;
    document.querySelector('#trad-title').textContent = isNew ? 'Nouveau document' : (d.type || 'Traduction');
    const lab = (t, input, cls) => el('label', { className: cls || '' }, t, input);
    const inp = (name, value, { list, ...props } = {}) => {
      const i = el('input', { name, value: value ?? '', autocomplete: 'off', ...props });
      if (list) i.setAttribute('list', list); // read-only as a property
      return i;
    };
    const f = el('form', { className: 'tr-form' });
    const etat = el('select', { name: 'etat' }, ...Object.entries(ETATS).map(([k, t]) => el('option', { value: k, textContent: t, selected: (d.etat || 'traducteur') === k })));
    const prix = inp('prix', d.prix, { placeholder: 'ex : 150', inputMode: 'decimal' });
    const paye = inp('paye', d.paye, { placeholder: '0', inputMode: 'decimal' });
    const hint = el('div', { className: 'tr-hint' });
    const syncPay = () => {
      const p = pay({ prix: prix.value, paye: paye.value });
      hint.className = 'tr-hint ' + (p ? (p.reste > 0 ? 'due' : 'ok') : '');
      hint.textContent = !p ? 'Tapez le prix pour suivre ce qui reste à payer.' : p.reste > 0 ? `Reste à payer : ${money(p.reste)}` : '✓ Tout est payé';
    };
    prix.oninput = paye.oninput = syncPay;
    // «clients» is popup.js's list (a top-level let, visible to the panel's scripts)
    const clients = [...new Set((typeof globalThis.AATradClients === 'function' ? globalThis.AATradClients() : []).map(c => `${c.prenom || ''} ${c.nom || ''}`.trim()).filter(Boolean))].sort();
    const delBtn = isNew ? null : el('button', { type: 'button', className: 'danger', textContent: '🗑 Supprimer', onclick: () => remove(d, delBtn) });
    f.append(
      el('div', { className: 'card' }, el('div', { className: 'sec-title', textContent: 'Document' }),
        el('div', { className: 'grid' },
          lab('Type de document', inp('type', d.type, { list: 'tr-dl-types', placeholder: 'Ex : Acte de naissance' }), 'wide'),
          lab('Client (à qui appartient le document)', inp('client', d.client, { list: 'tr-dl-clients', placeholder: 'Nom et prénom' }), 'wide'),
          lab('Langue du document', inp('de', d.de, { list: 'tr-dl-langs' })),
          lab('Traduire en', inp('vers', d.vers, { list: 'tr-dl-langs' })),
          lab('Nombre de pages', inp('pages', d.pages, { type: 'number', min: 1 })),
          lab('Traducteur', inp('traducteur', d.traducteur, { list: 'tr-dl-trad', placeholder: 'Nom du traducteur' }), 'wide'),
          lab('Envoyé au traducteur le', inp('envoi', d.envoi, { type: 'date' })),
          lab('À livrer le', inp('livraison', d.livraison, { type: 'date' })),
          lab('État', etat),
          lab('Remis au client le', inp('remise', d.remise, { type: 'date' })),
          lab('Notes', el('textarea', { name: 'notes', rows: 2, value: d.notes || '', placeholder: 'Ex : original à rendre…' }), 'wide'))),
      el('div', { className: 'card' }, el('div', { className: 'sec-title', textContent: '💰 Paiement' }),
        el('div', { className: 'grid' }, lab('Prix (DH)', prix), lab('Déjà payé (DH)', paye)),
        el('div', { className: 'tr-payrow' }, el('button', { type: 'button', className: 'small', textContent: 'Tout payé', onclick: () => { if (amount(prix.value) === undefined) return prix.focus(); paye.value = amount(prix.value); syncPay(); } }), hint)),
      d.cree ? el('div', { className: 'tr-added', textContent: added(d.cree) + (d.by ? ' · ' + d.by.split('@')[0] : '') + ' — reste dans la liste tant qu\'on ne le supprime pas' }) : null,
      el('datalist', { id: 'tr-dl-types' }, ...TYPES.map(v => el('option', { value: v }))),
      el('datalist', { id: 'tr-dl-langs' }, ...LANGUES.map(v => el('option', { value: v }))),
      el('datalist', { id: 'tr-dl-clients' }, ...clients.map(v => el('option', { value: v }))),
      el('datalist', { id: 'tr-dl-trad' }, ...[...new Set(rows.map(r => r.traducteur).filter(Boolean))].sort().map(v => el('option', { value: v }))),
      el('div', { className: 'actions' },
        el('button', { type: 'submit', className: 'primary', textContent: isNew ? 'Ajouter le document' : 'Enregistrer' }),
        el('button', { type: 'button', textContent: 'Annuler', onclick: () => list() }),
        delBtn ? el('span', { className: 'grow' }) : null, delBtn));
    syncPay();
    etat.onchange = () => { if (etat.value === 'remise' && !f.elements.remise.value) f.elements.remise.value = ymd(); };
    f.onsubmit = e => { e.preventDefault(); save(f, d, isNew); };
    box().replaceChildren(f);
    f.elements.type.focus();
  }

  async function save(f, d, isNew) {
    const E = f.elements, v = k => E[k].value.trim();
    if (!v('type')) { say('Tapez le type de document', true); return E.type.focus(); }
    if (!v('client')) { say('Tapez le nom du client', true); return E.client.focus(); }
    const btn = f.querySelector('button[type=submit]');
    btn.disabled = true;
    const id = d.id || 'tr' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const data = JSON.parse(JSON.stringify({
      ...d, id, type: v('type'), client: v('client'), de: v('de') || undefined, vers: v('vers') || undefined,
      pages: v('pages') === '' ? undefined : +v('pages'), livraison: v('livraison') || undefined, etat: v('etat') || 'traducteur',
      traducteur: v('traducteur') || undefined, envoi: v('envoi') || undefined,
      remise: v('remise') || (v('etat') === 'remise' ? ymd() : undefined), // «Remise au client» without a date: today
      notes: v('notes') || undefined, prix: amount(v('prix')), paye: amount(v('paye')),
      cree: d.cree || Date.now(), by: d.by || me || undefined,
    }));
    try {
      await upsert(data);
      rows = [...rows.filter(r => r.id !== id), data];
      say(isNew ? '✓ Document ajouté (aussi sur le téléphone)' : '✓ Enregistré');
      list();
    } catch (e) {
      btn.disabled = false;
      say('Pas enregistré : ' + e.message, true);
    }
  }

  // Two clicks: the first arms, the second (within 3 s) deletes.
  async function remove(d, btn) {
    if (!armed) {
      armed = true;
      btn.textContent = '🗑 Cliquez encore pour supprimer';
      setTimeout(() => { if (armed) { armed = false; if (btn.isConnected) btn.textContent = '🗑 Supprimer'; } }, 3000);
      return;
    }
    try {
      await del(d.id);
      rows = rows.filter(r => r.id !== d.id);
      say('Document supprimé');
      list();
    } catch (e) { say('Pas supprimé : ' + e.message, true); }
  }

  // The view and its button (📝 next to ☁ at the top of the panel) are added here, so popup.html stays as it is.
  function mount() {
    const v = el('div', { id: 'trad-view', className: 'view', hidden: true },
      el('div', { className: 'edit-head' },
        el('button', { type: 'button', className: 'icon', title: 'Retour', textContent: '←', onclick: () => (editing ? list() : hide()) }),
        el('h2', { id: 'trad-title', textContent: '📝 Traductions' }),
        el('span', { className: 'grow' }),
        el('button', { type: 'button', className: 'primary tr-add', title: 'Nouveau document à traduire', textContent: '＋', onclick: () => form(null) })),
      el('div', { id: 'trad-body', className: 'scroll' }));
    document.body.append(v);
    const cloud = document.querySelector('#cloudBtn');
    cloud?.before(el('button', { id: 'tradBtn', type: 'button', className: 'icon', title: 'Traductions (documents de l\'équipe)', textContent: '📝', onclick: show }));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount); else mount();

  return { show, hide, _test: { results, pay, late } };
})();
