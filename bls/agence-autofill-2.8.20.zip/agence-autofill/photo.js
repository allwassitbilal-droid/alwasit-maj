// 🖼 The client's face on his card (where the N° is), so he is found at a glance.
// A small thumbnail (c.thumb, ~5 KB JPEG) is made from the photo of his Fichiers (slot «photo») and kept in the
// client, so it is shared ☁ with every PC and never downloaded again. Made when a photo is added (Fichiers),
// and, for clients who already had one, once, in the background (one client at a time).
globalThis.AAPhoto = (() => {
  const W = 96, H = 120; // 4:5, like a visa photo

  async function thumb(blob) {
    const img = await createImageBitmap(blob);
    // Centre crop to 4:5 (a visa photo already is; a phone photo is cut around its centre, a bit higher)
    const r = W / H;
    let sw = img.width, sh = img.height, sx = 0, sy = 0;
    if (sw / sh > r) { sw = Math.round(sh * r); sx = Math.round((img.width - sw) / 2); }
    else { sh = Math.round(sw / r); sy = Math.round((img.height - sh) * 0.3); }
    const c = new OffscreenCanvas(W, H);
    const g = c.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, W, H);
    g.drawImage(img, sx, sy, sw, sh, 0, 0, W, H);
    const out = await c.convertToBlob({ type: 'image/jpeg', quality: 0.72 });
    return await new Promise(ok => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.readAsDataURL(out); });
  }

  async function setThumb(id, dataUrl) {
    const c = clients.find(x => x.id === id);
    if (!c || c.thumb === dataUrl) return;
    c.thumb = dataUrl;
    await save();
    if (document.querySelector('#list-view') && !document.querySelector('#list-view').hidden) render();
  }

  // A photo added in Fichiers → its thumbnail at once (from the file itself, nothing downloaded)
  function hookUpload() {
    if (!globalThis.AAFiles || AAFiles._photoHook) return;
    const up = AAFiles.upload;
    AAFiles.upload = async (id, slot, file) => {
      const r = await up(id, slot, file);
      if (slot === 'photo' && /^image\//.test(file.type)) thumb(file).then(t => setThumb(id, t)).catch(() => {});
      return r;
    };
    AAFiles._photoHook = true;
  }

  // Clients who already had a photo: download it once, make the thumbnail. Misses are retried after 3 days.
  const TRIED = 'thumbTried';
  let busy = false;
  async function backfill() {
    if (busy || !globalThis.AAFiles) return;
    busy = true;
    try {
      const { [TRIED]: tried = {}, syncStatus } = await chrome.storage.local.get([TRIED, 'syncStatus']);
      if (syncStatus && syncStatus.state === 'off') return;
      const todo = clients.filter(c => c.id && !c.thumb && !c.archive && !(Date.now() - (tried[c.id] || 0) < 3 * 864e5)).slice(0, 40);
      for (const c of todo) {
        tried[c.id] = Date.now();
        try {
          const [f] = await AAFiles.list(c.id, 'photo');
          if (f && /\.(jpe?g|png|webp)$/i.test(f.name)) {
            const blob = await AAFiles.fetchBlob(f.path);
            await setThumb(c.id, await thumb(blob));
          }
        } catch (e) {
          if (/Connectez-vous/.test(e.message)) break; // not logged in: try later
        }
        await chrome.storage.local.set({ [TRIED]: tried });
        await new Promise(r => setTimeout(r, 400));
      }
    } finally { busy = false; }
  }

  /** The stub of the card: the photo, with the N° under it. */
  function stub(stubEl, c) {
    if (!c.thumb) return stubEl;
    stubEl.classList.add('has-photo');
    stubEl.prepend(Object.assign(document.createElement('img'), { src: c.thumb, alt: '', loading: 'lazy', decoding: 'async' }));
    return stubEl;
  }

  function init() {
    hookUpload();
    setTimeout(backfill, 4000);
    setInterval(backfill, 10 * 60e3);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  return { thumb, stub, backfill, setThumb };
})();
