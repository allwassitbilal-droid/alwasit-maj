// Watch loop: scans the next N months for an enabled day, then hands off to booking.
// Also drives peak-time scheduling (auto start/stop and a one-time warm reload before each peak).
// Only one tab watches at a time: starting asks the background for leadership (see background/index.ts).
import type { LeaderReply, LogEntry, Tone, WatchState } from "../shared/messages";
import { askBackground, sendToBackground } from "../shared/messages";
import { computePhase, effectiveIntervalSec, isHot, timerLagMs, type Phase } from "../shared/schedule";
import type { Settings } from "../shared/settings";
import { dayAllowed, parseIsoDate } from "../shared/slots";
import { lastApiMonth, onApiData, type ApiDay, type ApiMonth } from "./apidata";
import { prepareBooking } from "./booking";
import {
  availableDays,
  calendarSummary,
  dayTime,
  diagnostics,
  findCalendar,
  formTouched,
  isOff,
  monthLabel,
  monthSignature,
  monthText,
  navButton,
} from "./dom";
import { httpTrouble, resetRetries, showRetry } from "./retry";
import { contextAlive, onSignupPage, rateGuard, session, sleep, waitFor } from "./util";

const MONTH_SETTLE_MS = 1200;
const NO_CALENDAR_RETRY_MS = 3000;
const LOG_MAX = 20;
/** After another tab refused us leadership, peak auto-start waits this long before asking again. */
const CLAIM_RETRY_MS = 15_000;
const LAG_ALERT_WINDOW_MS = 30 * 60_000;
/** Missed confirm windows in a row after which watching stays stopped (the user is away). */
export const MAX_MISSED_CONFIRMS = 3;

export class Watcher {
  private running = false;
  /** Set after a manual stop or a find, so peak time doesn't restart the loop behind the user's back. */
  private suppressed = false;
  private autoStarted = false;
  private lastPhase: Phase["phase"] = "normal";
  private statusText = "متوقف";
  private tone: Tone = "info";
  private checks = 0;
  private nextCheckAt: number | null = null;
  /** Overrun of the last completed wait; non-zero means Chrome is throttling this tab. */
  private lagMs = 0;
  private claiming = false;
  private claimRetryAt = 0;
  private readonly entries: LogEntry[] = [];
  private readonly listeners = new Set<() => void>();
  /** Last enabled-dates signature recorded per month, so history logs changes, not every poll. */
  private readonly seen = new Map<string, string>();
  private wake: (() => void) | null = null;
  /** Between a find and the end of booking (the user's confirm click, or its timeout). */
  private booking = false;
  /** Confirm windows missed in a row; reset by a manual start. */
  private missed = 0;
  /** Stopped (manually or by another tab) during a booking: don't resume after it. */
  private stopRequested = false;

  /**
   * @param busy True while something else drives the page (form filling opens date pickers):
   * peak time then neither starts watching nor reloads.
   */
  constructor(
    private settings: Settings,
    private readonly busy: () => boolean = () => false,
  ) {}

  get currentSettings(): Settings {
    return this.settings;
  }

  updateSettings(s: Settings): void {
    this.settings = s;
    this.wake?.(); // apply a new interval immediately
    this.emit();
  }

  /** Subscribe to state changes; returns an unsubscribe function. */
  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  state(): WatchState {
    const sched = this.phase();
    return {
      running: this.running,
      text: this.statusText,
      tone: this.tone,
      onCalendar: !onSignupPage() && !!(findCalendar() || monthLabel()),
      sched,
      intervalSec: effectiveIntervalSec(this.settings, sched),
      checks: this.checks,
      nextCheckAt: this.nextCheckAt,
      lagSec: Math.round(this.lagMs / 1000),
      log: [...this.entries],
    };
  }

  /** Adds a line to the activity log from outside the watch loop (e.g. form filling). */
  note(text: string, tone: Tone = "info"): void {
    this.event(text, tone);
  }

  diag(): string {
    return diagnostics({ status: this.statusText, running: this.running, checks: this.checks });
  }

  start(): void {
    this.suppressed = false;
    this.missed = 0;
    this.autoStarted = false;
    void this.begin("▶️ بدأت المراقبة", true);
  }

  stop(): void {
    sendToBackground({ type: "resume", on: false });
    this.suppressed = true;
    this.stopRequested = true;
    this.autoStarted = false;
    this.halt("⏹️ وقفت المراقبة");
  }

  /** Another tab took over watching: stop here and don't auto-restart. */
  yieldLeadership(): void {
    this.suppressed = true;
    this.stopRequested = true;
    this.autoStarted = false;
    if (this.running) this.halt("⏸️ تبويب آخر خدا المراقبة، هاد التبويب وقف");
  }

  /** Open days in BLS's answer that pass the date filter. */
  private usableApiDates(m: ApiMonth): string[] {
    return m.dates.filter((d) => dayAllowed(parseIsoDate(d) ?? 0, this.settings.filter));
  }

  private lastApiSig = "";
  /** BLS's answers to the site's calendar requests (no extra request): logged, and they wake the loop. */
  private onApi({ month, day }: { month?: ApiMonth; day?: ApiDay }): void {
    if (month) {
      const usable = this.usableApiDates(month);
      const sig = `${month.month}:${usable.join(",")}`;
      if (!usable.length || sig === this.lastApiSig) return;
      this.lastApiSig = sig;
      const days = usable.map((d) => d.slice(8, 10)).join("، ");
      this.event(`📡 BLS: ${usable.length} نهار متاح فـ ${month.month} (${days})`, "ok");
      // Napping: look at the page now rather than at the next check.
      if (this.running && !this.booking) this.wake?.();
    }
    if (day) {
      const [, mm, dd] = day.date.split("-");
      this.event(
        day.hours.length
          ? `🕘 ${dd}/${mm}: ${day.hours.map((h) => `${h.start}${h.free > 1 ? ` (${h.free})` : ""}`).join("، ")}`
          : `🕘 ${dd}/${mm}: حتى ساعة ما بقات خاوية`,
        day.hours.length ? "ok" : "warn",
      );
    }
  }

  /** Call once on page load. */
  init(): void {
    onApiData((e) => this.onApi(e));
    // A freshly loaded page isn't watching, even if this tab was the leader before the reload.
    sendToBackground({ type: "release" });
    const p = this.phase();
    this.lastPhase = p.phase;
    // Opened mid-peak: don't warm-reload this page again.
    if (isHot(p)) session.set(this.warmKey(p), "1");
    setInterval(() => this.tick(), 1000);
    this.tick();
  }

  private phase(): Phase {
    return computePhase(this.settings.peak, new Date());
  }

  private warmKey(p: Phase): string {
    return `blsWarm:${new Date().toDateString()}:${"peak" in p ? p.peak : ""}`;
  }

  private emit(): void {
    for (const fn of this.listeners) fn();
  }

  private setStatus(text: string, tone: Tone = "info"): void {
    this.statusText = text;
    this.tone = tone;
    sendToBackground({ type: "state", running: this.running });
    this.emit();
  }

  /** Status + a line in the activity log, for events worth remembering (not every check). */
  private event(text: string, tone: Tone = "info"): void {
    this.entries.unshift({ at: Date.now(), text, tone });
    this.entries.length = Math.min(this.entries.length, LOG_MAX);
    if (tone === "warn" || tone === "err") sendToBackground({ type: "log", text, tone });
    this.setStatus(text, tone);
  }

  private notify(text: string, tone: Tone): void {
    this.event(text, tone);
    document.title = `🟢 ${text}`;
    sendToBackground({ type: "notify", text });
  }

  /** Starts the loop once this tab is the leader; a manual start (takeover) stops any other watching tab. */
  private async begin(reason: string, takeover: boolean): Promise<void> {
    if (this.running || this.claiming) return;
    if (onSignupPage()) return void this.setStatus("صفحة التسجيل: المراقبة كتخدم غير فصفحة التواريخ", "warn");
    this.claiming = true;
    // Background unreachable (e.g. mid-update): watch anyway rather than silently not at all.
    const ok = (await askBackground<LeaderReply>({ type: "claim", takeover }))?.ok ?? true;
    this.claiming = false;
    if (this.running) return;
    if (this.suppressed) {
      // stopped while waiting for the claim
      sendToBackground({ type: "release" });
      return;
    }
    if (!ok) {
      this.autoStarted = false;
      this.claimRetryAt = Date.now() + CLAIM_RETRY_MS;
      this.setStatus("تبويب آخر ديال BLS كيراقب دابا: هاد التبويب كيستنى", "warn");
      return;
    }
    this.running = true;
    this.lagMs = 0;
    this.event(reason);
    void this.loop();
  }

  private halt(reason: string): void {
    this.running = false;
    this.lagMs = 0;
    this.wake?.();
    sendToBackground({ type: "release" });
    this.event(reason);
  }

  private nap(ms: number): Promise<void> {
    const started = Date.now();
    this.nextCheckAt = started + ms;
    this.emit();
    return new Promise((resolve) => {
      const done = (timedOut: boolean) => {
        clearTimeout(t);
        this.wake = null;
        this.nextCheckAt = null;
        if (timedOut) this.checkLag(timerLagMs(ms, Date.now() - started));
        resolve();
      };
      const t = setTimeout(() => done(true), ms);
      this.wake = () => done(false);
    });
  }

  /** Reports when Chrome starts (or stops) delaying this tab's checks, so a "watching" tab isn't silently asleep. */
  private checkLag(lag: number): void {
    const was = this.lagMs > 0;
    this.lagMs = lag;
    if (!was && lag > 0) {
      const text =
        `🐢 Chrome كيبطّأ هاد التبويب: الفحص تأخر ${Math.round(lag / 1000)}ث على وقتو` +
        (document.hidden ? " (التبويب مخفي)" : "") +
        ". خلي BLS فنافذة بوحدها ظاهرة";
      this.event(text, "warn");
      if (rateGuard("blsLagAlert", 1, LAG_ALERT_WINDOW_MS)) sendToBackground({ type: "notify", text });
    } else if (was && !lag) {
      this.event("✅ الفحص رجع لوقتو");
    }
  }

  private async loop(): Promise<void> {
    while (this.running) {
      try {
        if (availableDays() === null) {
          if (await this.serverTrouble()) return;
          const grids = document.querySelectorAll('[role="grid"]').length;
          const days = document.querySelectorAll("button[data-day]").length;
          this.setStatus(`التقويم ما لقيتوش فالصفحة (grid:${grids}, أيام:${days}) — جرب «تشخيص»`, "warn");
          await this.nap(NO_CALENDAR_RETRY_MS);
          continue;
        }
        resetRetries();
        sendToBackground({ type: "resume", on: true });
        const days = await this.scanMonths();
        if (days) return void this.onFound(days);
        await this.nap(effectiveIntervalSec(this.settings, this.phase()) * 1000);
      } catch (err) {
        console.error("[BLS Helper]", err);
        if (!contextAlive()) {
          this.running = false;
          return;
        }
        this.event(`خطأ: ${err instanceof Error ? err.message : String(err)} — حدّث الصفحة (F5)`, "err");
        await sleep(NO_CALENDAR_RETRY_MS);
      }
    }
  }

  /**
   * Enabled days in the visible month that pass the date filter. Every distinct set of enabled
   * days (filtered or not) is also sent to the history, since it tells when dates get released.
   */
  private inspect(): { usable: HTMLButtonElement[]; total: number } {
    const all = availableDays() ?? [];
    const key = monthSignature();
    const dates = all.map((b) => b.getAttribute("data-day") ?? "").filter(Boolean);
    const sig = dates.join(",");
    if (this.seen.get(key) !== sig) {
      this.seen.set(key, sig);
      if (dates.length) sendToBackground({ type: "seen", month: monthText(), dates });
    }
    return { usable: all.filter((b) => dayAllowed(dayTime(b), this.settings.filter)), total: all.length };
  }

  private describe({ usable, total }: { usable: HTMLButtonElement[]; total: number }): string {
    const count = usable.length === total ? `${total}` : `${usable.length} مناسب من ${total}`;
    return `${monthText()} (${count})${calendarSummary()}`;
  }

  /** Clicks a month nav button and watches every 60ms; returns usable days as soon as they show. */
  private async gotoMonth(btn: HTMLButtonElement): Promise<{ usable: HTMLButtonElement[]; total: number }> {
    const before = monthSignature();
    const clickedAt = Date.now();
    btn.click();
    await waitFor(() => {
      const sig = monthSignature();
      return sig && sig !== before;
    }, 5000, 20);
    const t = Date.now();
    let r = this.inspect();
    while (!r.usable.length && Date.now() - t < MONTH_SETTLE_MS) {
      // BLS's own answer for this month already says no usable day: no need to wait for the page to settle.
      const api = lastApiMonth();
      if (api && api.at >= clickedAt && !this.usableApiDates(api).length) break;
      await sleep(60);
      r = this.inspect();
    }
    return r;
  }

  /** One pass: current month, forward N-1 months, then back (the way back also refreshes data). */
  private async scanMonths(): Promise<HTMLButtonElement[] | null> {
    this.setStatus(`كنفحص... (#${this.checks + 1})`);
    const report: string[] = [];
    let r = this.inspect();
    report.push(this.describe(r));
    if (r.usable.length) return r.usable;

    let steps = 0;
    for (let i = 1; i < this.settings.months && this.running; i++) {
      const next = navButton("next");
      if (isOff(next)) break;
      r = await this.gotoMonth(next!);
      steps++;
      report.push(this.describe(r));
      if (r.usable.length) return r.usable;
    }
    for (let i = 0; i < steps; i++) {
      const prev = navButton("prev");
      if (isOff(prev)) break;
      r = await this.gotoMonth(prev!);
      if (r.usable.length) return r.usable;
    }
    this.checks++;
    this.setStatus(`فحص #${this.checks} ${new Date().toLocaleTimeString()} ← ${report.join(" ، ")}`);
    return null;
  }

  /**
   * BLS refused or failed (429 / 5xx): stop the loop and let the retry dialog reload the page; watching comes
   * back after the reload by itself. True when that happened.
   */
  private async serverTrouble(): Promise<boolean> {
    const t = await httpTrouble(true);
    if (!t || !this.running) return false;
    this.running = false;
    this.nextCheckAt = null;
    sendToBackground({ type: "release" });
    this.event(`⚠️ BLS رجع خطأ ${t.status}: غادي نعاود نحمّل الصفحة`, "warn");
    const stopped = () => {
      sendToBackground({ type: "resume", on: false });
      this.suppressed = true;
      this.event("⏹️ وقفت المراقبة");
    };
    if (!showRetry(t, stopped)) stopped();
    return true;
  }

  private async onFound(days: HTMLButtonElement[]): Promise<void> {
    sendToBackground({ type: "resume", on: false });
    this.running = false;
    this.suppressed = true;
    for (const d of days) d.style.outline = "3px solid #0a8550";

    if (!this.settings.autoPrepare) {
      sendToBackground({ type: "release" });
      this.notify(`🎯 كاين ${days.length} تاريخ متاح فـ ${monthText()}`, "ok");
      return;
    }
    this.event(`🎯 لقيت ${days.length} نهار متاح فـ ${monthText()}، كنحضّر الحجز...`, "ok");
    // Leadership is held until booking ends, so no other tab starts watching mid-booking.
    this.booking = true;
    this.stopRequested = false;
    let missed = false;
    try {
      const r = await prepareBooking(days, {
        settings: this.settings,
        notify: (t) => this.notify(t, "warn"),
        status: (t) => this.event(t, "warn"),
        beep: () => sendToBackground({ type: "beep" }),
      });
      // Agence Autofill: the client gets marked «Réservé», and the queue may move to the next one.
      if (r.ok && r.booked) sendToBackground({ type: "booked", ...r.booked });
      missed = !!r.missed;
      this.missed = missed ? this.missed + 1 : 0;
      const again = missed && this.missed < MAX_MISSED_CONFIRMS && !this.stopRequested;
      this.notify(missed ? `${r.msg}. ${again ? "رجعت للمراقبة" : "المراقبة وقفات"}` : r.msg, r.ok ? "ok" : "warn");
      missed = again;
    } catch (err) {
      console.error("[BLS Helper]", err);
      this.notify("وقع خطأ فتحضير الحجز: كمل بيدك", "err");
    } finally {
      this.booking = false;
      sendToBackground({ type: "release" });
    }
    // The days may still be open: watch again so the next find gives the user another chance.
    if (missed) {
      this.suppressed = false;
      void this.begin("🔁 رجعت للمراقبة بعد ما فاتك التأكيد", false);
    }
  }

  /** A warm reload would throw away a booking waiting for the user's click, or a form being filled. */
  private reloadUnsafe(): string {
    if (this.booking) return "كاين حجز كيتسنى التأكيد ديالك";
    if (this.busy()) return "التعمار ديال الفورم خدام";
    if (availableDays() === null && formTouched()) return "كاين فورم معمّر فالصفحة";
    return "";
  }

  private tick(): void {
    // On signup a date picker's calendar would pass for the slot calendar, and a warm reload would
    // wipe a half-filled form: peak scheduling does nothing there. Same while a form is being filled.
    if (!contextAlive() || onSignupPage()) return;
    const p = this.phase();
    if (p.phase !== this.lastPhase) {
      const prev = this.lastPhase;
      this.lastPhase = p.phase;
      if (!isHot(p)) {
        this.suppressed = false;
        if (this.autoStarted && this.running) {
          this.autoStarted = false;
          sendToBackground({ type: "resume", on: false });
          this.halt("⏹️ سالات الذروة، وقفت المراقبة");
        }
      }
      this.wake?.();
      // Refresh the session once right before each peak.
      if (p.phase === "pre" && this.settings.peak.warmReload && (prev === "normal" || prev === "off")) {
        const key = this.warmKey(p);
        if (!session.get(key)) {
          session.set(key, "1");
          const why = this.reloadUnsafe();
          if (why) {
            this.event(`⏭️ ما عاودتش تحميل الصفحة قبل الذروة: ${why}`, "warn");
          } else {
            location.reload();
            return;
          }
        }
      }
    }
    if (
      this.settings.enabled &&
      isHot(p) &&
      !this.running &&
      !this.suppressed &&
      !this.busy() &&
      Date.now() >= this.claimRetryAt &&
      availableDays() !== null
    ) {
      this.autoStarted = true;
      void this.begin("🔥 وقت الذروة: بدأت المراقبة أوتوماتيك", false);
    }
  }
}
