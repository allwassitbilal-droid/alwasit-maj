// Injected into the page (after rules.js). Finds fields by their label and fills / reads them.
(() => {
  const { AA_match: match, AA_toIso: toIso, AA_DATES: DATES } = globalThis;
  const SKIP = /^(hidden|submit|button|checkbox|radio|file|image|reset|password|search)$/;

  const fields = () => [...document.querySelectorAll('input,select,textarea')]
    .filter(el => !SKIP.test(el.type) && !el.disabled && !el.readOnly && el.getClientRects().length);

  const textOf = node => {
    let s = '';
    const w = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    while (w.nextNode()) {
      if (!w.currentNode.parentElement.closest('select,option,script,style')) s += ' ' + w.currentNode.nodeValue;
    }
    return s.trim();
  };

  // Possible descriptions of a field, most reliable first.
  const candidates = el => {
    const out = [];
    if (el.labels) for (const l of el.labels) out.push(textOf(l));
    out.push(el.getAttribute('aria-label'));
    const lb = el.getAttribute('aria-labelledby');
    if (lb) out.push(lb.split(/\s+/).map(id => document.getElementById(id)?.textContent || '').join(' '));
    // Label written next to the field in the same small container (<div><label>Nom</label><input></div>)
    let n = el.parentElement;
    for (let i = 0; i < 4 && n && n !== document.body; i++, n = n.parentElement) {
      if (n.querySelectorAll('input,select,textarea').length > 1) break;
      const t = textOf(n);
      if (t) { if (t.length <= 80) out.push(t); break; }
    }
    out.push(el.placeholder, el.name, el.id, el.title);
    return out.filter(Boolean);
  };

  const keyOf = el => {
    for (const t of candidates(el)) { const k = match(t); if (k) return k; }
    return null;
  };

  // First field found for each key (fields in `skip` are ignored).
  const map = (skip = new Set()) => {
    const m = {};
    for (const el of fields()) {
      if (skip.has(el)) continue;
      const k = keyOf(el);
      if (k && !m[k]) m[k] = el;
    }
    return m;
  };

  // "Email = x@y.com" lines -> [["Email", "x@y.com"], ...]
  const parseExtra = s => (s || '').split('\n').map(l => l.split(/=(.*)/s))
    .filter(p => p[1] !== undefined && p[0].trim()).map(([l, v]) => [l.trim(), v.trim()]);

  // Field whose label is exactly the wanted name, otherwise one whose label contains it.
  const findByLabel = (label, used) => {
    const n = AA_norm(label);
    const free = fields().filter(el => !used.has(el)).map(el => [el, candidates(el).map(AA_norm)]);
    return (free.find(([, c]) => c.includes(n)) || free.find(([, c]) => c.some(t => t.includes(n))) || [])[0];
  };

  const fmt = (el, key, v) => {
    if (!DATES.includes(key)) return v;
    const iso = toIso(v);
    if (!iso) return v;
    if (el.type === 'date') return iso;
    const [y, mo, d] = iso.split('-');
    return /^(aaaa|yyyy)/i.test(el.placeholder || '') ? iso : `${d}/${mo}/${y}`;
  };

  const setVal = (el, v) => {
    if (el.tagName === 'SELECT') {
      const nv = AA_norm(v);
      const opts = [...el.options];
      const opt = opts.find(o => AA_norm(o.value) === nv || AA_norm(o.text) === nv)
        || opts.find(o => nv && AA_norm(o.text).includes(nv));
      if (!opt) return false;
      el.value = opt.value;
    } else {
      // Native setter so React/Vue/Angular pages notice the change.
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  };

  const flash = el => {
    const old = el.style.outline;
    el.style.outline = '2px solid #2dd4bf';
    setTimeout(() => { el.style.outline = old; }, 1500);
  };

  // Field the user last clicked in this frame (tracker.js), or the one still focused.
  const lastField = () => {
    const last = globalThis.__aaLast?.el;
    if (last?.isConnected) return last;
    const a = document.activeElement;
    return a?.matches?.('input, textarea, select, [contenteditable]') ? a : null;
  };

  globalThis.__agenceAutofill = {
    lastTime() {
      const el = lastField();
      return el ? (globalThis.__aaLast?.el === el ? globalThis.__aaLast.t : 1) : 0;
    },
    insert({ key, value }) {
      const el = lastField();
      if (!el) return false;
      if (el.isContentEditable) {
        el.focus();
        document.execCommand('insertText', false, value);
      } else if (!setVal(el, fmt(el, key, value))) return false;
      el.focus();
      flash(el);
      return true;
    },
    fill(client) {
      const filled = [], used = new Set();
      // Custom fields first, so they win over the automatic rules.
      for (const [label, v] of parseExtra(client.extra)) {
        const el = findByLabel(label, used);
        if (el && setVal(el, v)) { filled.push(label); used.add(el); flash(el); }
      }
      const m = map(used);
      for (const [k, el] of Object.entries(m)) {
        if (client[k] && setVal(el, fmt(el, k, client[k]))) { filled.push(k); flash(el); }
      }
      return { filled, found: Object.keys(m) };
    },
    capture() {
      const out = {};
      for (const [k, el] of Object.entries(map())) {
        let v = (el.tagName === 'SELECT' ? el.selectedOptions[0]?.text : el.value) || '';
        v = v.trim();
        if (DATES.includes(k)) v = toIso(v);
        if (v) out[k] = v;
      }
      return out;
    },
  };
})();
