// The BLS settings the on-page bar can't hold. Telegram and peak hours go to "teamSettings" (shared with
// the team by sync.js); the Login pace stays in this PC's "blsSettings". The page script validates both
// (BLS Helper's normalizeSettings), so only the fields edited here change.
const f = document.getElementById('f').elements;
const $ = s => document.querySelector(s);
const say = (sel, text, ok) => { const m = $(sel); m.textContent = text; m.className = 'msg ' + (ok ? 'ok' : 'bad'); };
let s = {}, team = {};

chrome.storage.local.get(['blsSettings', 'teamSettings']).then(r => {
  s = r.blsSettings || {};
  team = r.teamSettings || {};
  const tg = team.telegram || s.telegram || {}, p = team.peak || s.peak || {};
  f.loginRetrySec.value = String(s.loginRetrySec ?? 3);
  f.tgEnabled.checked = !!tg.enabled;
  f.botToken.value = tg.botToken || '';
  f.chatId.value = tg.chatId || '';
  f.peakEnabled.checked = !!p.enabled;
  f.peakTimes.value = p.times || '';
  f.leadMin.value = p.leadMin ?? 2;
  f.durationMin.value = p.durationMin ?? 10;
  f.peakInterval.value = p.intervalSec ?? 10;
  f.warmReload.checked = p.warmReload ?? true;
});

const save = async () => {
  s = { ...s, loginRetrySec: +f.loginRetrySec.value };
  team = {
    ...team,
    telegram: { enabled: f.tgEnabled.checked, botToken: f.botToken.value.trim(), chatId: f.chatId.value.trim() },
    peak: {
      ...(team.peak || s.peak || {}),
      enabled: f.peakEnabled.checked, times: f.peakTimes.value.trim(),
      leadMin: +f.leadMin.value, durationMin: +f.durationMin.value, intervalSec: +f.peakInterval.value, warmReload: f.warmReload.checked,
    },
  };
  await chrome.storage.local.set({ blsSettings: s, teamSettings: team });
};

document.getElementById('f').onsubmit = async e => {
  e.preventDefault();
  await save();
  say('#saved', '✓ Enregistré', true);
};

$('#findChat').onclick = async () => {
  const r = await chrome.runtime.sendMessage({ type: 'telegramChatId', token: f.botToken.value.trim() });
  if (r?.ok) { f.chatId.value = r.chatId; say('#tgMsg', `✓ Chat trouvé : ${r.name || r.chatId}. Cliquez Enregistrer.`, true); }
  else say('#tgMsg', r?.error || 'Erreur', false);
};

$('#passports').onclick = async () => {
  await save();
  say('#tgMsg', '⏳ Vérification…', true);
  const r = await chrome.runtime.sendMessage({ type: 'checkPassports' });
  if (!r?.ok) return say('#tgMsg', r?.error || 'Pas de réponse', false);
  say('#tgMsg', r.sent ? `✓ ${r.sent} passeport(s) envoyé(s) sur Telegram` : '✓ Aucun passeport expiré ou à moins de 6 mois', true);
};

$('#test').onclick = async () => {
  await save();
  const r = await chrome.runtime.sendMessage({ type: 'telegramTest' });
  say('#tgMsg', r?.ok ? '✓ Message de test envoyé' : 'Telegram : ' + (r?.error || 'pas de réponse'), r?.ok);
};

// Diagnostic file to send when BLS misbehaves (built by bls.js, without the Telegram token).
$('#diagExport').onclick = async () => {
  say('#diagMsg', '⏳ Préparation…', true);
  const r = await chrome.runtime.sendMessage({ type: 'diagExport' }).catch(e => ({ ok: false, error: e.message }));
  if (!r || r.ok === false) return say('#diagMsg', r?.error || 'Pas de réponse', false);
  const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(r, null, 1)], { type: 'application/json' }));
  a.download = `diagnostic-bls-${stamp}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 10_000);
  say('#diagMsg', `✓ Fichier téléchargé (${r.log.length} lignes d'historique, ${r.pages.length} page(s) BLS)`, true);
};
