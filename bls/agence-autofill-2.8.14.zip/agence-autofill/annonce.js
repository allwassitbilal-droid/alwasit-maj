// 🔄 «Nouvelle mise à jour» on Telegram (service worker; shared by Autofill TLS and Autofill BLS).
// When a PC starts a version that the team has not been told about yet, it sends once to the team's Telegram chat:
// the version and what is new (nouveautes.json, written with each update). The version is marked in the team
// settings (teamSettings.majAnnoncee, synced ☁) so the other PCs, updating a few minutes later, don't send it again.
(() => {
  const local = chrome.storage.local;
  const M = chrome.runtime.getManifest();
  const APP = /TLS/i.test(M.name) ? 'tls' : 'bls';
  const newer = (a, b) => { // a > b, versions like 2.8.7
    const x = String(a || '0').split('.').map(Number), y = String(b || '0').split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
    return false;
  };

  async function notes() {
    try { return (await (await fetch(chrome.runtime.getURL('nouveautes.json'), { cache: 'no-store' })).json())[M.version] || []; } catch { return []; }
  }
  function text(lines) {
    const head = `🔄 ميزاجور جديدة — ${APP === 'tls' ? 'Autofill TLS 🇫🇷' : 'Autofill BLS 🇪🇸'} v${M.version}`;
    const body = lines.length ? lines.map(l => '• ' + l).join('\n') : '• تحسينات صغيرة';
    return `${head}\n\n${body}\n\nكتوصل لكاع البيسيات بوحدها فـ 15 دقيقة. إلا كان الپانو محلول، كليكي على «Redémarrer».`;
  }
  async function send(tg, msg) {
    try {
      const r = await fetch(`https://api.telegram.org/bot${encodeURIComponent(tg.botToken)}/sendMessage`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, signal: AbortSignal.timeout(15_000),
        body: JSON.stringify({ chat_id: tg.chatId, text: msg }),
      });
      return (await r.json()).ok;
    } catch { return false; }
  }

  let running = null;
  const check = () => (running ||= run().finally(() => { running = null; }));
  async function run() {
    const { teamSettings: t0, syncStatus, blsSettings } = await local.get(['teamSettings', 'syncStatus', 'blsSettings']);
    // Only with ☁ (the mark must reach the other PCs) and when the team row has arrived.
    if (!syncStatus?.email || !t0) return;
    if (!newer(M.version, t0.majAnnoncee)) return;
    const tg = t0.telegram || blsSettings?.telegram || {}; // same as the morning summary (matin.js)
    if (!tg.botToken || !tg.chatId) return;
    // Several PCs update at about the same time: wait a random moment, so the first one's mark arrives first.
    await new Promise(r => setTimeout(r, 10_000 + Math.random() * 50_000));
    const { teamSettings = {} } = await local.get('teamSettings');
    if (!newer(M.version, teamSettings.majAnnoncee)) return;
    const before = teamSettings.majAnnoncee;
    await local.set({ teamSettings: { ...teamSettings, majAnnoncee: M.version } }); // mark first: fewer doubles
    if (!(await send(tg, text(await notes())))) {
      const { teamSettings: ts = {} } = await local.get('teamSettings');
      if (ts.majAnnoncee === M.version) await local.set({ teamSettings: { ...ts, majAnnoncee: before } }); // try again later
    }
  }

  chrome.alarms.create('annonce-maj', { delayInMinutes: 1, periodInMinutes: 10 });
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'annonce-maj') check(); });
  globalThis.AAAnnonce = { check, text, newer };
})();
