// Settings schema, defaults and validation. Storage holds two keys:
// "settings" (everything below) and "account" (credentials, never sent to the popup).

export type DayPick = "earliest" | "latest";
export type SlotPick = "earliest" | "latest" | "random";

export interface PeakSettings {
  enabled: boolean;
  /** Comma/space separated "HH:MM" list, e.g. "09:00, 15:00". */
  times: string;
  leadMin: number;
  durationMin: number;
  intervalSec: number;
  /** Reload the page once just before each peak to refresh the session. */
  warmReload: boolean;
}

export interface DateFilter {
  /** Inclusive bounds as "YYYY-MM-DD"; empty = unbounded. */
  from: string;
  to: string;
  /** Weekdays to skip, 0 = Sunday ... 6 = Saturday. */
  excludeDays: number[];
}

export interface TelegramSettings {
  enabled: boolean;
  botToken: string;
  chatId: string;
}

export interface Settings {
  /** Master switch for all automation. */
  enabled: boolean;
  autoLogin: boolean;
  autoSubmit: boolean;
  /** Seconds between two Login clicks while still on the login form (Agence Autofill). */
  loginRetrySec: number;
  autoNav: boolean;
  /** Pre-select day and time when a date appears; the user always clicks the final confirm. */
  autoPrepare: boolean;
  /** Agence Autofill: also click the final confirm (and its "are you sure?") instead of waiting for the user. */
  autoConfirm: boolean;
  /** Agence Autofill: after a booking, go on with the next ⭐ ready client (sign in, search, book). */
  queue: boolean;
  /** Floating status panel on BLS pages. */
  showWidget: boolean;
  intervalSec: number;
  months: number;
  dayPick: DayPick;
  slotPick: SlotPick;
  slotDelayMs: number;
  peak: PeakSettings;
  filter: DateFilter;
  telegram: TelegramSettings;
}

export interface Account {
  email: string;
  password: string;
}

export const LIMITS = {
  intervalSec: [15, 600],
  loginRetrySec: [1, 60],
  months: [1, 4],
  slotDelayMs: [0, 3000],
  leadMin: [0, 30],
  durationMin: [1, 120],
  peakIntervalSec: [10, 60],
} as const satisfies Record<string, readonly [number, number]>;

export const DEFAULT_SETTINGS: Settings = {
  enabled: true,
  autoLogin: true,
  autoSubmit: true,
  loginRetrySec: 3,
  autoNav: true,
  autoPrepare: true,
  autoConfirm: false,
  queue: false,
  showWidget: true,
  intervalSec: 20,
  months: 2,
  dayPick: "earliest",
  slotPick: "earliest",
  slotDelayMs: 400,
  peak: {
    enabled: false,
    times: "",
    leadMin: 2,
    durationMin: 10,
    intervalSec: 10,
    warmReload: true,
  },
  filter: { from: "", to: "", excludeDays: [] },
  telegram: { enabled: false, botToken: "", chatId: "" },
};

const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const isoDate = (v: unknown): string => (typeof v === "string" && ISO_DATE_RE.test(v.trim()) ? v.trim() : "");
const str = (v: unknown): string => (typeof v === "string" ? v.trim() : "");

function weekdays(v: unknown): number[] {
  if (!Array.isArray(v)) return [];
  const days = v.map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 6);
  return [...new Set(days)].sort((a, b) => a - b);
}

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null;

const bool = (v: unknown, fallback: boolean): boolean => (typeof v === "boolean" ? v : fallback);

function num(v: unknown, [min, max]: readonly [number, number], fallback: number): number {
  const n = typeof v === "string" ? Number.parseInt(v, 10) : v;
  if (typeof n !== "number" || !Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function oneOf<T extends string>(v: unknown, allowed: readonly T[], fallback: T): T {
  return allowed.includes(v as T) ? (v as T) : fallback;
}

/** Turns anything read from storage (or a form) into a valid Settings object. */
export function normalizeSettings(raw: unknown): Settings {
  const r = isObj(raw) ? raw : {};
  const p = isObj(r.peak) ? r.peak : {};
  const f = isObj(r.filter) ? r.filter : {};
  const tg = isObj(r.telegram) ? r.telegram : {};
  const d = DEFAULT_SETTINGS;
  return {
    enabled: bool(r.enabled, d.enabled),
    autoLogin: bool(r.autoLogin, d.autoLogin),
    autoSubmit: bool(r.autoSubmit, d.autoSubmit),
    loginRetrySec: num(r.loginRetrySec, LIMITS.loginRetrySec, d.loginRetrySec),
    autoNav: bool(r.autoNav, d.autoNav),
    autoPrepare: bool(r.autoPrepare, d.autoPrepare),
    autoConfirm: bool(r.autoConfirm, d.autoConfirm),
    queue: bool(r.queue, d.queue),
    showWidget: bool(r.showWidget, d.showWidget),
    intervalSec: num(r.intervalSec, LIMITS.intervalSec, d.intervalSec),
    months: num(r.months, LIMITS.months, d.months),
    dayPick: oneOf(r.dayPick, ["earliest", "latest"], d.dayPick),
    slotPick: oneOf(r.slotPick, ["earliest", "latest", "random"], d.slotPick),
    slotDelayMs: num(r.slotDelayMs, LIMITS.slotDelayMs, d.slotDelayMs),
    peak: {
      enabled: bool(p.enabled, d.peak.enabled),
      times: typeof p.times === "string" ? p.times.trim() : d.peak.times,
      leadMin: num(p.leadMin, LIMITS.leadMin, d.peak.leadMin),
      durationMin: num(p.durationMin, LIMITS.durationMin, d.peak.durationMin),
      intervalSec: num(p.intervalSec, LIMITS.peakIntervalSec, d.peak.intervalSec),
      warmReload: bool(p.warmReload, d.peak.warmReload),
    },
    filter: {
      from: isoDate(f.from),
      to: isoDate(f.to),
      excludeDays: weekdays(f.excludeDays),
    },
    telegram: {
      enabled: bool(tg.enabled, d.telegram.enabled),
      botToken: str(tg.botToken),
      chatId: str(tg.chatId),
    },
  };
}

export function normalizeAccount(raw: unknown): Account {
  const r = isObj(raw) ? raw : {};
  return {
    email: typeof r.email === "string" ? r.email.trim() : "",
    password: typeof r.password === "string" ? r.password : "",
  };
}
