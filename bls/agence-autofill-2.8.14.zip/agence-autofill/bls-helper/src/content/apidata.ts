// Agence Autofill: what BLS answered to the site's own calendar requests (read in the page by page/peek.ts,
// no extra request). A month: which days are open. A day: its hours with free places.
const PEEK_TAG = "aa-bls-api";

export interface ApiMonth {
  /** "YYYY-MM" */
  month: string;
  /** Open days, "YYYY-MM-DD", sorted. */
  dates: string[];
  at: number;
}

export interface ApiHour {
  start: string;
  end: string;
  free: number;
}

export interface ApiDay {
  date: string;
  hours: ApiHour[];
  at: number;
}

type Listener = (e: { month?: ApiMonth; day?: ApiDay }) => void;

let lastMonth: ApiMonth | null = null;
const listeners = new Set<Listener>();

const unwrap = (b: unknown): unknown => (b && typeof b === "object" && "data" in (b as object) ? (b as { data: unknown }).data : b);

/** /slots/calendar → open days of that month; null when it isn't the expected shape. */
export function parseCalendar(body: unknown): ApiMonth | null {
  const d = unwrap(body) as { year?: unknown; month?: unknown; days?: unknown } | null;
  if (!d || !Array.isArray(d.days)) return null;
  const y = Number(d.year);
  const m = Number(d.month);
  if (!Number.isInteger(y) || !Number.isInteger(m) || m < 1 || m > 12) return null;
  const dates = (d.days as Array<{ date?: unknown; calendarConfig?: { isAvailable?: unknown } }>)
    .filter((x) => typeof x?.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(x.date) && x.calendarConfig?.isAvailable === true)
    .map((x) => x.date as string)
    .sort();
  return { month: `${y}-${String(m).padStart(2, "0")}`, dates, at: Date.now() };
}

const hhmm = (v: unknown): string => {
  const m = /^(\d{1,2}):(\d{2})/.exec(String(v ?? ""));
  return m ? `${m[1]!.padStart(2, "0")}:${m[2]}` : "";
};

/** /slots/date-slots?date=… → that day's hours with free places (free > 0), sorted. */
export function parseDateSlots(body: unknown, url: string): ApiDay | null {
  const list = unwrap(body);
  const date = /[?&]date=(\d{4}-\d{2}-\d{2})/.exec(url)?.[1];
  if (!Array.isArray(list) || !date) return null;
  const seen = new Set<string>();
  const hours: ApiHour[] = [];
  for (const group of list as Array<{ slots?: unknown }>) {
    if (!Array.isArray(group?.slots)) continue;
    for (const s of group.slots as Array<Record<string, unknown>>) {
      const free = Number(s?.numberOfAppointmentsAvailable);
      const start = hhmm(s?.startTime);
      if (!start || !(free > 0) || seen.has(start + (s?.id ?? ""))) continue;
      seen.add(start + (s?.id ?? ""));
      hours.push({ start, end: hhmm(s?.endTime), free });
    }
  }
  hours.sort((a, b) => a.start.localeCompare(b.start));
  return { date, hours, at: Date.now() };
}

export const lastApiMonth = (): ApiMonth | null => lastMonth;

const days = new Map<string, ApiDay>();
/** BLS's hours for a day ("YYYY-MM-DD"), if its answer came after `since`. */
export const apiDay = (date: string, since = 0): ApiDay | null => {
  const d = days.get(date);
  return d && d.at >= since ? d : null;
};

/** "08:15" → minutes since midnight. */
export const hourMins = (h: string): number => Number(h.slice(0, 2)) * 60 + Number(h.slice(3, 5));

export function onApiData(fn: Listener): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

/** Starts listening to the page hook. */
export function startApiData(): void {
  window.addEventListener("message", (e: MessageEvent) => {
    if (e.source !== window || e.origin !== location.origin) return;
    const msg = e.data as { tag?: unknown; kind?: unknown; url?: unknown; body?: unknown } | null;
    if (!msg || msg.tag !== PEEK_TAG || typeof msg.url !== "string") return;
    if (msg.kind === "calendar") {
      const month = parseCalendar(msg.body);
      if (!month) return;
      lastMonth = month;
      for (const fn of listeners) fn({ month });
    } else if (msg.kind === "date-slots") {
      const day = parseDateSlots(msg.body, msg.url);
      if (!day) return;
      days.set(day.date, day);
      for (const fn of listeners) fn({ day });
    }
  });
}
