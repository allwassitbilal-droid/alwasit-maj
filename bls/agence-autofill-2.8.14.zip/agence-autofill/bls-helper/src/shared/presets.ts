// One-tap date ranges for the search ("this week", "next month"...), as the filter's from/to strings.
// Pure: "now" is passed in so it is testable.

export type PresetId = "any" | "week" | "twoWeeks" | "month" | "nextMonth";

export const PRESETS: ReadonlyArray<{ id: PresetId; label: string }> = [
  { id: "any", label: "أي نهار" },
  { id: "week", label: "هاد السيمانة" },
  { id: "twoWeeks", label: "15 يوم" },
  { id: "month", label: "هاد الشهر" },
  { id: "nextMonth", label: "الشهر الجاي" },
];

const iso = (d: Date): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

const addDays = (d: Date, n: number): Date => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);

export function presetRange(id: PresetId, now = new Date()): { from: string; to: string } {
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  switch (id) {
    case "week":
      return { from: iso(today), to: iso(addDays(today, 6)) };
    case "twoWeeks":
      return { from: iso(today), to: iso(addDays(today, 14)) };
    case "month":
      return { from: iso(today), to: iso(new Date(today.getFullYear(), today.getMonth() + 1, 0)) };
    case "nextMonth":
      return { from: iso(new Date(today.getFullYear(), today.getMonth() + 1, 1)), to: iso(new Date(today.getFullYear(), today.getMonth() + 2, 0)) };
    default:
      return { from: "", to: "" };
  }
}

/** The preset a range matches today, if any (to highlight it). */
export function activePreset(from: string, to: string, now = new Date()): PresetId | null {
  return PRESETS.find((p) => {
    const r = presetRange(p.id, now);
    return r.from === from && r.to === to;
  })?.id ?? null;
}

/** "26/10 → 31/10", "من 26/10", "حتى 31/10" or "أي نهار", for a short summary of the range. */
export function rangeLabel(from: string, to: string): string {
  const short = (s: string) => (s ? `${s.slice(8, 10)}/${s.slice(5, 7)}` : "");
  if (from && to) return `${short(from)} → ${short(to)}`;
  if (from) return `من ${short(from)}`;
  if (to) return `حتى ${short(to)}`;
  return "أي نهار";
}
