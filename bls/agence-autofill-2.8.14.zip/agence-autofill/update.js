// «New version» banner. The newest extension in the team announces itself: when a PC opens a version higher than
// the one recorded in the team settings (synced ☁), it records it there with what is new. Every PC with an older
// version then shows a banner at the top: ask the admin for the new ZIP. Nothing to do by hand.
// Needs ☁ (the team settings travel with the sync); a PC that isn't connected sees nothing.
globalThis.AAUpdate = (() => {
  const mine = chrome.runtime.getManifest().version;
  const cmp = (a, b) => {
    const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
    return 0;
  };
  let notes = [], later = false, ready = '';

  // The automatic updater already copied a newer version into the folder (autoreload.js): one click restarts.
  function showReady(version) {
    const box = document.querySelector('#update');
    box.hidden = false;
    const head = Object.assign(document.createElement('div'), { className: 'upd-head' });
    const txt = Object.assign(document.createElement('div'), {});
    txt.append(
      Object.assign(document.createElement('b'), { textContent: `Mise à jour v${version} installée` }),
      Object.assign(document.createElement('small'), { textContent: 'Redémarrez l\'extension pour l\'utiliser (2 secondes, rien n\'est perdu).' }));
    head.append(
      Object.assign(document.createElement('span'), { className: 'upd-icon', textContent: '✅' }), txt,
      Object.assign(document.createElement('button'), {
        type: 'button', className: 'upd-later primary', textContent: '↻ Redémarrer',
        onclick: () => chrome.runtime.sendMessage({ type: 'maj-redemarrer' }).catch(() => chrome.runtime.reload()),
      }));
    box.replaceChildren(head);
  }

  function show(update) {
    const box = document.querySelector('#update');
    if (!box) return;
    if (ready && cmp(ready, mine) > 0) return showReady(ready);
    const newer = update && cmp(update.version, mine) > 0;
    box.hidden = !newer || later;
    if (box.hidden) return;
    const list = document.createElement('ul');
    for (const n of update.notes || []) list.append(Object.assign(document.createElement('li'), { textContent: n }));
    const more = Object.assign(document.createElement('details'), {});
    more.append(Object.assign(document.createElement('summary'), { textContent: 'Quoi de neuf ?' }), list);
    const close = Object.assign(document.createElement('button'), {
      type: 'button', className: 'upd-later', textContent: 'Plus tard', title: 'Cacher jusqu\'à la prochaine ouverture du panneau',
      onclick: () => { later = true; box.hidden = true; },
    });
    const head = Object.assign(document.createElement('div'), { className: 'upd-head' });
    head.append(
      Object.assign(document.createElement('span'), { className: 'upd-icon', textContent: '🔔' }),
      Object.assign(document.createElement('div'), {}),
      close);
    head.children[1].append(
      Object.assign(document.createElement('b'), { textContent: `Mise à jour v${update.version} disponible` }),
      Object.assign(document.createElement('small'), { textContent: `Vous avez la v${mine}. Avec la mise à jour automatique elle arrive toute seule en quelques minutes ; sinon : ZIP de l'admin, puis chrome://extensions → ↻.` }));
    box.replaceChildren(head, ...(update.notes?.length ? [more] : []));
  }

  async function check() {
    const { teamSettings = {}, teamSynced, majPrete } = await chrome.storage.local.get(['teamSettings', 'teamSynced', 'majPrete']);
    ready = majPrete || '';
    const update = teamSettings.update;
    // This PC has the newest version: record it for the team (with what is new) — only once the team settings
    // came from the server (☁), so this never overwrites the team's Telegram settings with an empty copy.
    if (teamSynced !== undefined && (!update || cmp(mine, update.version) > 0)) {
      const next = { version: mine, notes, at: Date.now() };
      await chrome.storage.local.set({ teamSettings: { ...teamSettings, update: next } });
      return show(next);
    }
    show(update);
  }

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && (ch.teamSettings || ch.majPrete)) check();
  });

  return { init(whatsNew) { notes = whatsNew || []; check(); } };
})();
