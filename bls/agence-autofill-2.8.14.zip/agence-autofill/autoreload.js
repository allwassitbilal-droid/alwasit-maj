// Automatic update, extension side (service worker; shared by Autofill TLS and Autofill BLS).
// The Windows updater (alwasit-maj on GitHub → maj-autofill.ps1, every 15 min) copies a new version into this
// same folder, manifest.json last. Here we notice that the files on disk are newer than the running version and
// restart the extension (↻) by ourselves — right away when the panel is closed; when it is open, the panel shows
// «Mise à jour installée — Redémarrer» so nobody loses what they were typing.
(() => {
  const mine = chrome.runtime.getManifest().version;
  const local = chrome.storage.local;

  async function check() {
    let disk;
    try {
      disk = (await (await fetch(chrome.runtime.getURL('manifest.json'), { cache: 'no-store' })).json()).version;
    } catch { return; } // files being copied right now: next time
    if (!disk || disk === mine) {
      const { majPrete } = await local.get('majPrete');
      if (majPrete) await local.remove('majPrete');
      return;
    }
    const open = await chrome.runtime.getContexts?.({ contextTypes: ['SIDE_PANEL', 'POPUP', 'TAB'] }).catch(() => []) || [];
    if (open.length) await local.set({ majPrete: disk });
    else chrome.runtime.reload();
  }

  chrome.alarms.create('maj-disque', { delayInMinutes: 1, periodInMinutes: 2 });
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'maj-disque') check(); });
  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg?.type !== 'maj-redemarrer') return false;
    reply({ ok: true });
    setTimeout(() => chrome.runtime.reload(), 100);
    return false;
  });
  check();
})();
