// Reads the 2 MRZ lines at the bottom of a passport (TD3, 2 x 44 chars) from OCR text.
globalThis.MRZ = (() => {
  const val = c => (c === '<' ? 0 : /\d/.test(c) ? +c : c.charCodeAt(0) - 55);
  const check = s => String([...s].reduce((sum, c, i) => sum + val(c) * [7, 3, 1][i % 3], 0) % 10);

  // Usual OCR confusions, depending on whether the position holds digits or letters.
  const toDigit = s => s.replace(/[OQDU]/g, '0').replace(/[IL]/g, '1').replace(/Z/g, '2')
    .replace(/S/g, '5').replace(/G/g, '6').replace(/T/g, '7').replace(/B/g, '8');
  const toAlpha = s => s.replace(/0/g, 'O').replace(/1/g, 'I').replace(/2/g, 'Z')
    .replace(/5/g, 'S').replace(/6/g, 'G').replace(/8/g, 'B');

  const pad = l => (l + '<'.repeat(44)).slice(0, 44);
  const validDate = d => /^\d{6}$/.test(d) && +d.slice(2, 4) >= 1 && +d.slice(2, 4) <= 12 && +d.slice(4) >= 1 && +d.slice(4) <= 31;

  function parseLine2(raw) {
    const l = pad(raw);
    const rawNum = l.slice(0, 9), numCk = toDigit(l[9]);
    // Try the number as read, then "letters then digits" (Moroccan style: AB1234567)
    const variants = [rawNum, toAlpha(rawNum.slice(0, 2)) + toDigit(rawNum.slice(2))];
    const num = variants.find(v => check(v) === numCk) || rawNum;
    // Dates block "YYMMDD c SEX YYMMDD c": normally at position 13, but OCR may add/drop a character.
    const datesAt = i => {
      const birth = toDigit(l.slice(i, i + 6)), exp = toDigit(l.slice(i + 8, i + 14));
      return {
        birth, exp, sex: l[i + 7],
        okB: validDate(birth) && check(birth) === toDigit(l[i + 6]),
        okE: validDate(exp) && check(exp) === toDigit(l[i + 14]),
      };
    };
    let d = datesAt(13);
    if (!(d.okB && d.okE)) {
      for (let i = 10; i <= 18; i++) {
        const t = datesAt(i);
        if (t.okB + t.okE > d.okB + d.okE) d = t;
      }
    }
    const ok = { passeport: check(num) === numCk, naissance: d.okB, expire: d.okE };
    const score = Object.values(ok).filter(Boolean).length + (validDate(d.birth) ? 0.5 : 0) + (validDate(d.exp) ? 0.5 : 0);
    return { num: num.replace(/</g, ''), nat: toAlpha(l.slice(10, 13)), birth: d.birth, exp: d.exp, sex: d.sex, ok, score };
  }

  function parseLine1(raw) {
    const l = pad(raw);
    // SURNAME<<GIVEN<NAMES<<<<<  (anything after the next "<<" is filler, often read as K/L)
    // OCR often reads "<<" as "<K<K": collapse those back.
    const names = toAlpha(l.slice(5)).replace(/(<[KL]){2,}/g, m => '<'.repeat(m.length / 2));
    const [surname, given] = names.split('<<');
    const clean = s => (s || '').replace(/[<KLC]{3,}$/, '').replace(/</g, ' ').replace(/\s+/g, ' ').trim();
    return { country: toAlpha(l.slice(2, 5)), nom: clean(surname), prenom: clean(given) };
  }

  const iso = (yymmdd, century) => `${century}${yymmdd.slice(0, 2)}-${yymmdd.slice(2, 4)}-${yymmdd.slice(4)}`;

  function parse(text) {
    const lines = text.toUpperCase().replace(/[«‹]/g, '<').split('\n')
      .map(l => l.replace(/[^A-Z0-9<]/g, ''))
      .flatMap(l => (l.length >= 80 ? [l.slice(0, 44), l.slice(44)] : [l]))
      .filter(l => l.length >= 30);

    let best = null;
    lines.forEach((l, i) => {
      if (i === 0 && lines.length > 1 && l.startsWith('P')) return;
      const p = parseLine2(l);
      if (!best || p.score > best.p.score) best = { p, i };
    });
    if (!best || best.p.score < 1) return null;

    const { p, i } = best;
    const l1 = lines.slice(0, i).reverse().find(l => /^P/.test(l)) || lines[i - 1] || '';
    const n = parseLine1(l1);
    const yy = new Date().getFullYear() % 100;
    const naissance = validDate(p.birth) ? iso(p.birth, +p.birth.slice(0, 2) > yy ? '19' : '20') : '';
    const expire = validDate(p.exp) ? iso(p.exp, '20') : '';
    // "Délivré" and "Lieu" are not in the MRZ: readPage() gets them from the printed page.
    return {
      prenom: n.prenom, nom: n.nom, naissance, passeport: p.num, expire,
      nationalite: p.nat, sexe: p.sex === '<' ? '' : p.sex, checks: p.ok, lines: [l1, lines[i]],
    };
  }

  // ---- Printed part of the page (above the MRZ): date and place of issue ----
  const MONTHS = { JAN: 1, FEB: 2, FEV: 2, MAR: 3, APR: 4, AVR: 4, MAY: 5, MAI: 5, JUN: 6, JUI: 6, JUL: 7,
    AUG: 8, AOU: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12 };
  const CITIES = ['CASABLANCA', 'RABAT', 'SALE', 'TEMARA', 'KENITRA', 'FES', 'MEKNES', 'MARRAKECH', 'AGADIR',
    'TANGER', 'TETOUAN', 'OUJDA', 'NADOR', 'EL JADIDA', 'SAFI', 'BENI MELLAL', 'KHOURIBGA', 'SETTAT', 'BERRECHID',
    'MOHAMMEDIA', 'LARACHE', 'KSAR EL KEBIR', 'TAZA', 'ERRACHIDIA', 'OUARZAZATE', 'GUELMIM', 'LAAYOUNE', 'DAKHLA',
    'ESSAOUIRA', 'KHEMISSET', 'KHENIFRA', 'BERKANE', 'AL HOCEIMA', 'TIZNIT', 'TAROUDANT', 'INEZGANE', 'SIDI KACEM',
    'SIDI SLIMANE', 'SIDI BENNOUR', 'YOUSSOUFIA', 'FKIH BEN SALAH', 'IFRANE', 'AZROU', 'SEFROU', 'TAOUNATE',
    'CHEFCHAOUEN', 'OUEZZANE', 'GUERCIF', 'TAOURIRT', 'DRIOUCH', 'MIDELT', 'ZAGORA', 'TINGHIR', 'BENSLIMANE',
    'ANFA', 'AIN CHOCK', 'AIN SEBAA', 'HAY HASSANI', 'SIDI BERNOUSSI', 'BEN MSIK', 'MOULAY RACHID', 'NOUACEUR',
    'MEDIOUNA', 'SKHIRATE', 'MARTIL', 'MDIQ', 'FNIDEQ'];
  const LABEL = /LIEU\s*DE\s*D.?LIVR|PLACE\s*OF\s*ISSUE|AUTORIT|AUTHORITY|ISSUING/;
  const NOISE = /\b(LIEU|DE|DELIVRANCE|PLACE|OF|ISSUE|AUTORITE|AUTHORITY|ISSUING|DATE|ROYAUME|MAROC|KINGDOM|MOROCCO|PASSEPORT|PASSPORT)\b/g;
  const isoOf = (d, m, y) => (d >= 1 && d <= 31 && m >= 1 && m <= 12 && y >= 1900 && y <= 2100
    ? `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}` : '');
  const days = (a, b) => (new Date(a) - new Date(b)) / 864e5;

  // Every date written on a line: 14/05/2019, 14.05.2019, 14 05 2019, 14 MAI 2019, 14 MAI/MAY 2019
  function datesIn(line) {
    const fix = s => s.replace(/[OQD]/g, '0').replace(/[Il|]/g, '1');
    const out = [];
    for (const m of line.matchAll(/([0-9OQDIl|]{2})\s?[\/.\-\s]\s?([0-9OQDIl|]{2})\s?[\/.\-\s]\s?([0-9OQDIl|]{4})/g)) {
      const d = isoOf(+fix(m[1]), +fix(m[2]), +fix(m[3]));
      if (d) out.push({ iso: d, at: m.index });
    }
    for (const m of line.matchAll(/(\d{1,2})\s*([A-Z]{3})[A-Z]*(?:\s*\/\s*[A-Z]{3,5})?\s*(\d{4})/g)) {
      const d = MONTHS[m[2]] && isoOf(+m[1], MONTHS[m[2]], +m[3]);
      if (d) out.push({ iso: d, at: m.index });
    }
    return out;
  }

  // text = OCR of the whole page. known = { naissance, expire } already read from the MRZ.
  function readPage(text, known = {}) {
    const lines = text.toUpperCase().normalize('NFD').replace(/[̀-ͯ]/g, '').split('\n')
      .map(l => l.trim()).filter(Boolean);
    const today = new Date().toISOString().slice(0, 10);

    // Date of issue: a date that is not birth/expiry, in the past, and 5 or 10 years before expiry.
    let delivre = '', bestScore = -1, issueLine = -1;
    lines.forEach((l, i) => {
      for (const { iso: d } of datesIn(l)) {
        if (d === known.naissance || d === known.expire || d > today) continue;
        if (known.naissance && d <= known.naissance) continue;
        let score = 1;
        if (known.expire) {
          const gap = days(known.expire, d) / 365.25;
          if (gap < 0.5 || gap > 10.6) continue;
          if (Math.abs(gap - 5) < 0.1 || Math.abs(gap - 10) < 0.1) score += 3;
        }
        if (/DELIVR|ISSUE/.test(l) || /DELIVR|ISSUE/.test(lines[i - 1] || '')) score += 2;
        if (score > bestScore) { bestScore = score; delivre = d; issueLine = i; }
      }
    });

    // Place of issue: text after its label (same line, else next line), else a city next to the issue date.
    const clean = s => s.replace(/[^A-Z\s-]/g, ' ').replace(NOISE, ' ').replace(/\s+/g, ' ').trim();
    let lieu = '';
    for (let i = 0; i < lines.length && !lieu; i++) {
      const m = lines[i].match(LABEL);
      if (!m) continue;
      const after = clean(lines[i].slice(m.index + m[0].length).replace(/^[^/]*\//, ''));
      const next = clean(lines[i + 1] || '');
      lieu = (after.length >= 3 ? after : next.length >= 3 ? next : '');
    }
    const cityIn = l => CITIES.filter(c => new RegExp(`\\b${c}\\b`).test(l)).sort((a, b) => b.length - a.length)[0];
    if (!lieu && issueLine >= 0) {
      for (const i of [issueLine, issueLine + 1, issueLine - 1]) {
        const c = lines[i] && cityIn(lines[i]);
        if (c) { lieu = c; break; }
      }
    }
    return { delivre, lieu: lieu.slice(0, 40) };
  }

  return { parse, check, readPage };
})();
