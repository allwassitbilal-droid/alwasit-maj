// Prepares a booking (selects day and time) and hands the final «تأكيد الموعد» click to the user: it
// highlights the button, beeps, and waits for a trusted click. Agence Autofill: with «Réserver auto»
// (settings.autoConfirm) it clicks the confirm, and a following "are you sure?", itself; a face scan or
// anything else the site asks for is still left to the user.
import { askBackground, type HttpTrouble } from "../shared/messages";
import type { Settings } from "../shared/settings";
import { apiDay, hourMins } from "./apidata";
import { orderByDate, pickSlot } from "../shared/slots";
import {
  DIALOG_SEL,
  ERR_RE,
  FOLLOWUP_CONFIRM_RE,
  OK_RE,
  confirmButton,
  dayLabel,
  dayTime,
  faceStep,
  isConfirmButton,
  timeSlots,
  toastText,
} from "./dom";
import { sleep, textOf, waitFor } from "./util";

const MAX_SLOT_TRIES = 3;
const USER_CLICK_TIMEOUT_MS = 90_000;
const OUTCOME_TIMEOUT_MS = 6_000;
const FOLLOWUP_EXTRA_MS = 60_000;
const BEEP_EVERY_MS = 6_000;
/** A busy BLS asking to wait longer than this at confirm time: the hour is gone anyway, try another. */
const MAX_SERVER_WAIT_SEC = 15;

export interface BookingContext {
  settings: Settings;
  notify(text: string): void;
  status(text: string): void;
  beep(): void;
}

export interface BookingResult {
  ok: boolean;
  msg: string;
  /** The user didn't click the confirm button in time: worth watching again. */
  missed?: boolean;
  /** Agence Autofill: what was booked (day as YYYY-MM-DD), and whether the site went on to a face scan. */
  booked?: { day: string; time: string; face: boolean };
}

const isoDay = (t: number): string => {
  const d = new Date(t);
  return t ? `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}` : "";
};

interface ConfirmClick {
  before: Set<Element>;
  dialog: Element | null;
}

const PULSE_STYLE_ID = "bls-pulse-style";

function highlight(btn: HTMLElement): void {
  if (!document.getElementById(PULSE_STYLE_ID)) {
    const st = document.createElement("style");
    st.id = PULSE_STYLE_ID;
    st.textContent =
      "@keyframes blsPulse{0%{box-shadow:0 0 0 0 rgba(220,38,38,.85)}100%{box-shadow:0 0 0 20px rgba(220,38,38,0)}}" +
      ".bls-highlight{outline:4px solid #dc2626!important;animation:blsPulse .8s infinite}";
    document.head.appendChild(st);
  }
  btn.classList.add("bls-highlight");
  try {
    btn.scrollIntoView({ block: "center" });
    btn.focus({ preventScroll: true });
  } catch {
    // element detached mid-flight
  }
}

const unhighlight = (btn: HTMLElement) => btn.classList.remove("bls-highlight");

/** Resolves on the user's own (isTrusted) click on the confirm button, re-beeping until then. */
function waitUserConfirm(timeoutMs: number, beep: () => void): Promise<ConfirmClick | null> {
  return new Promise((resolve) => {
    const finish = (v: ConfirmClick | null) => {
      document.removeEventListener("click", onClick, true);
      clearInterval(beeper);
      clearTimeout(timer);
      resolve(v);
    };
    const onClick = (ev: MouseEvent) => {
      if (!ev.isTrusted) return;
      const btn = (ev.target as Element | null)?.closest?.("button");
      if (isConfirmButton(btn)) {
        finish({ before: new Set(document.querySelectorAll(DIALOG_SEL)), dialog: btn.closest('[role="dialog"]') });
      }
    };
    document.addEventListener("click", onClick, true);
    const beeper = setInterval(beep, BEEP_EVERY_MS);
    const timer = setTimeout(() => finish(null), timeoutMs);
  });
}

/** After the user confirms, read the real outcome from dialogs/toasts instead of assuming success. */
async function waitOutcome(click: ConfirmClick, notify: (t: string) => void, auto = false): Promise<{ ok: true; face?: boolean } | { ok: false; err: string }> {
  let deadline = Date.now() + OUTCOME_TIMEOUT_MS;
  let followup: HTMLElement | null = null;
  while (Date.now() < deadline) {
    if (faceStep()) return { ok: true, face: true };
    if (click.dialog && !document.contains(click.dialog)) return { ok: true };

    const nd = [...document.querySelectorAll<HTMLElement>(DIALOG_SEL)].find((x) => !click.before.has(x) && x !== click.dialog);
    if (nd) {
      const t = nd.innerText.replace(/\s+/g, " ");
      if (OK_RE.test(t) && !ERR_RE.test(t)) return { ok: true };
      if (ERR_RE.test(t)) return { ok: false, err: t.slice(0, 120) };
      // A second "are you sure?" dialog: clicked with «Réserver auto», else pointed out to the user.
      const b = [...nd.querySelectorAll<HTMLButtonElement>("button")].find((x) => !x.disabled && FOLLOWUP_CONFIRM_RE.test(x.textContent ?? ""));
      if (b && b !== followup) {
        followup = b;
        if (auto) {
          b.click();
          deadline = Date.now() + OUTCOME_TIMEOUT_MS;
        } else {
          highlight(b);
          notify("👉 الموقع طلب تأكيد ثاني: اضغط عليه");
          deadline = Date.now() + FOLLOWUP_EXTRA_MS;
        }
      }
    }
    const tt = toastText();
    if (tt && ERR_RE.test(tt)) return { ok: false, err: tt };
    if (tt && OK_RE.test(tt)) return { ok: true };
    await sleep(80);
  }
  return { ok: false, err: toastText() || "الديالوج بقى مفتوح بعد التأكيد (الحجز ما تأكدش)" };
}

export async function prepareBooking(days: HTMLButtonElement[], ctx: BookingContext): Promise<BookingResult> {
  const { settings } = ctx;
  let lastErr = "";

  for (const day of orderByDate(days, dayTime, settings.dayPick)) {
    const label = dayLabel(day);
    const dayIso = isoDay(dayTime(day));
    const dayAt = Date.now();
    if (day.getAttribute("aria-selected") !== "true") day.click();
    // BLS's own answer for this day (no extra request) can tell sooner than the page that it has no free hour.
    const ready = await waitFor(() => timeSlots().length > 0 || (dayIso && apiDay(dayIso, dayAt)?.hours.length === 0) || false, 8000, 25);
    if (!ready || !timeSlots().length) {
      if (dayIso && apiDay(dayIso, dayAt)) {
        lastErr = `${label}: ما بقات حتى ساعة خاوية`;
        ctx.status(`⏭️ ${label}: BLS قال ما بقات حتى ساعة خاوية، كندوز للنهار الجاي`);
      }
      continue;
    }

    const tried = new Set<string>();
    let serverRetried = false;
    for (let attempt = 0; attempt < MAX_SLOT_TRIES; attempt++) {
      const gap = attempt === 0 ? settings.slotDelayMs - (Date.now() - dayAt) : 150;
      if (gap > 0) await sleep(gap);

      // Only the hours BLS says still have places (when its answer is there), in the chosen order.
      const free = dayIso ? apiDay(dayIso, dayAt) : null;
      const freeMins = free && new Set(free.hours.map((h) => hourMins(h.start)));
      const open = timeSlots().filter((s) => !tried.has(s.text));
      const slot = pickSlot(freeMins ? open.filter((s) => freeMins.has(s.mins)) : open, settings.slotPick) ?? pickSlot(open, settings.slotPick);
      if (!slot) break;
      tried.add(slot.text);
      slot.btn.click();

      const confirm = await waitFor(confirmButton, 5000, 20);
      if (!confirm) {
        lastErr = "زر التأكيد ما تفعلش";
        continue;
      }

      let click: ConfirmClick | null;
      const confirmAt = Date.now();
      if (settings.autoConfirm) {
        click = { before: new Set(document.querySelectorAll(DIALOG_SEL)), dialog: confirm.closest('[role="dialog"]') };
        ctx.status(`🤖 كنأكد الحجز بوحدي: ${label} ${slot.text}`);
        confirm.click();
      } else {
        highlight(confirm);
        ctx.notify(`👉 اضغط دابا على «${textOf(confirm)}»: ${label} ${slot.text}`);
        click = await waitUserConfirm(USER_CLICK_TIMEOUT_MS, ctx.beep);
        unhighlight(confirm);
        if (!click) return { ok: false, missed: true, msg: "ما ضغطتيش على زر التأكيد فالوقت" };
      }

      const out = await waitOutcome(click, ctx.notify, settings.autoConfirm);
      if (out.ok) {
        return {
          ok: true,
          booked: { day: dayIso, time: slot.text, face: !!out.face },
          msg: out.face
            ? `✅ الموقع قبل التأكيد (${label} ${slot.text}) وطلب «مسح الوجه». كمل المسح بنفسك`
            : `✅ تأكد الحجز: ${label} ${slot.text}`,
        };
      }
      lastErr = `${slot.text}: ${out.err}`;
      // BLS was busy (503 / 429): the confirmation was not taken, so the same hour is tried once more after its
      // wait. 500 / 502 / 504 may have gone through on BLS's side: never resent, the user checks the appointments.
      const busy = await askBackground<HttpTrouble | null>({ type: "httpTrouble" });
      if (busy && busy.at >= confirmAt && !busy.mainFrame) {
        if (busy.status === 503 || busy.status === 429) {
          const waitSec = Math.max(2, busy.retryAfterSec ?? 0);
          if (!serverRetried && waitSec <= MAX_SERVER_WAIT_SEC) {
            serverRetried = true;
            tried.delete(slot.text);
            attempt--;
            ctx.status(`⏳ BLS مشغول (${busy.status}): كنعاود نفس الساعة ${slot.text} من بعد ${waitSec} ثانية`);
            await sleep(waitSec * 1000);
            continue;
          }
        } else {
          return {
            ok: false,
            msg: `⚠️ BLS رجع خطأ ${busy.status} فالتأكيد ديال ${label} ${slot.text}: يمكن تحجز ويمكن لا. شوف «Gérer les rendez-vous» قبل ما تعاود`,
          };
        }
      }
      ctx.status(`الموقع رفض (${out.err}) — كنختار ساعة أخرى...`);
    }
  }
  return {
    ok: false,
    msg: lastErr ? `⚠️ الحجز ما تأكدش: ${lastErr}. شوف الصفحة وكمل بيدك` : "لقيت أيام متاحة ولكن بلا ساعات. كمل بيدك",
  };
}
