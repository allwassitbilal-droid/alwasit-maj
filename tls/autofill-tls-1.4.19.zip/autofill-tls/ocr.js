// Passport OCR (Tesseract, files in lib/, no internet): reads the 2 MRZ lines, then the printed date and place of issue.
// Used by the panel (✎ step 1) and by the scan page.
(() => {
  const url = p => (globalThis.chrome?.runtime?.getURL ? chrome.runtime.getURL(p) : p);
  const el = (tag, props = {}) => Object.assign(document.createElement(tag), props);
// One OCR worker, created on first use, with files bundled in lib/ (no internet needed).
let onProgress = () => {}, workerPromise = null;
function getWorker() {
  workerPromise ||= (async () => {
    const w = await Tesseract.createWorker('eng', 1, {
      workerPath: url('lib/worker.min.js'),
      corePath: url('lib/tesseract-core-simd-lstm.wasm.js'),
      langPath: url('lib'),
      workerBlobURL: false,
      cacheMethod: 'none',
      logger: m => onProgress(m),
    });
    return w;
  })();
  return workerPromise;
}

// Grayscale + resize so the MRZ characters are big enough for OCR. `part` = bottom fraction to keep.
async function prepare(file, part = 1, rotate = 0) {
  const img = await createImageBitmap(file);
  const W = img.width, H = img.height;
  const sy = H * (1 - part), sh = H * part;
  const scale = Math.min(2400 / W, 3);
  const c = el('canvas', { width: Math.round(W * scale), height: Math.round(sh * scale) });
  const g = c.getContext('2d');
  if (rotate) { g.translate(c.width, c.height); g.rotate(Math.PI); }
  g.filter = 'grayscale(1) contrast(1.4)';
  g.drawImage(img, 0, rotate ? 0 : sy, W, sh, 0, 0, c.width, c.height);
  return c;
}

async function readPassport(file, setStatus) {
  const w = await getWorker();
  // Fast try on the bottom of the photo, then the whole photo, then upside down.
  const tries = [
    ['bas de la photo', () => prepare(file, 0.4), '6'],
    ['photo entière', () => prepare(file, 1), '3'],
    ['photo retournée', () => prepare(file, 1, 180), '3'],
  ];
  let best = null;
  await w.setParameters({ tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<' });
  for (const [label, make, psm] of tries) {
    setStatus(`Lecture (${label})…`);
    await w.setParameters({ tessedit_pageseg_mode: psm });
    const { data } = await w.recognize(await make());
    const r = MRZ.parse(data.text);
    const score = r ? Object.values(r.checks).filter(Boolean).length : -1;
    if (r && (!best || score > best.score)) best = { r, score, upsideDown: label === 'photo retournée' };
    if (score === 3) break;
  }
  if (!best) return null;
  // Second pass on the printed text (all characters) for "Date de délivrance" and "Lieu de délivrance".
  setStatus('Lecture date et lieu de délivrance…');
  await w.setParameters({ tessedit_char_whitelist: '', tessedit_pageseg_mode: '11' });
  const { data } = await w.recognize(await prepare(file, 1, best.upsideDown ? 180 : 0));
  Object.assign(best.r, MRZ.readPage(data.text, best.r));
  return best.r;
}

  /** file → { prenom, nom, naissance, passeport, expire, delivre, lieu, nationalite, sexe, checks } or null. */
  globalThis.AAOcr = {
    readPassport: (file, setStatus = () => {}, progress = () => {}) => { onProgress = progress; return readPassport(file, setStatus); },
  };
})();
