// Payment and WhatsApp for one client file (shared by Autofill TLS and Autofill BLS; the phone page has the same rules).
//   Payment: c.prix (price, DH) and c.paye (paid so far, DH) → chip «💰 Reste 500 DH» / «✓ Payé» on the ticket.
//   WhatsApp: ready messages (what is missing, the appointment, file complete, what is left to pay) opened in
//   WhatsApp Web / the app with the client's mobile; the message can still be changed before sending.
globalThis.AAExtras = (() => {
  const APP = /TLS/i.test(chrome.runtime.getManifest().name) ? 'tls' : 'bls';
  const SIGN = '\n— الوسيط';
  const money = n => `${Number(n).toLocaleString('fr-FR')} DH`;
  const num = v => {
    const n = parseFloat(String(v ?? '').replace(/\s/g, '').replace(',', '.'));
    return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) / 100 : undefined;
  };
  const frDate = iso => (iso ? iso.split('-').reverse().join('/') : '');
  const el = (tag, props = {}, ...kids) => {
    const e = Object.assign(document.createElement(tag), props);
    e.append(...kids.filter(k => k != null && k !== false));
    return e;
  };

  /** { prix, paye, reste } or null when no price was typed. */
  function pay(c) {
    const prix = num(c.prix);
    if (prix === undefined) return null;
    const paye = num(c.paye) || 0;
    return { prix, paye, reste: Math.max(0, Math.round((prix - paye) * 100) / 100) };
  }
  function payChip(c) {
    const p = pay(c);
    if (!p) return null;
    return p.reste > 0
      ? el('span', { className: 'chip pay due', textContent: `💰 Reste ${money(p.reste)}`, title: `Prix ${money(p.prix)} · payé ${money(p.paye)}` })
      : el('span', { className: 'chip pay ok', textContent: '✓ Payé', title: `Prix ${money(p.prix)}, tout est payé` });
  }

  // ---- ✎ form: «💰 Paiement» ----
  function fillPay(form, c) {
    form.elements.prix.value = c.prix ?? '';
    form.elements.paye.value = c.paye ?? '';
    payHint(form);
  }
  function readPay(form) {
    return { prix: num(form.elements.prix.value), paye: num(form.elements.paye.value) };
  }
  function payHint(form) {
    const box = form.querySelector('#pay-hint');
    if (!box) return;
    const p = pay(readPay(form));
    box.className = 'hint' + (p ? (p.reste > 0 ? ' due' : ' ok') : '');
    box.textContent = !p ? 'Tapez le prix du dossier pour suivre ce qui reste à payer.'
      : p.reste > 0 ? `Reste à payer : ${money(p.reste)}` : '✓ Tout est payé';
  }
  function wirePay(form) {
    form.elements.prix.addEventListener('input', () => payHint(form));
    form.elements.paye.addEventListener('input', () => payHint(form));
    form.querySelector('#pay-add').onclick = () => {
      const v = num(form.elements.payAdd.value);
      if (!v) return form.elements.payAdd.focus();
      form.elements.paye.value = Math.round(((num(form.elements.paye.value) || 0) + v) * 100) / 100;
      form.elements.payAdd.value = '';
      payHint(form);
    };
    form.elements.payAdd.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); form.querySelector('#pay-add').click(); } });
    form.querySelector('#pay-all').onclick = () => {
      const prix = num(form.elements.prix.value);
      if (prix === undefined) return form.elements.prix.focus();
      form.elements.paye.value = prix;
      payHint(form);
    };
  }

  // ---- WhatsApp ----
  /** Moroccan mobiles: 06…/07… → 2126…/2127…; other numbers as typed (with the country code). */
  function waNumber(m) {
    let d = String(m || '').replace(/[^\d+]/g, '');
    if (d.startsWith('+')) d = d.slice(1);
    else if (d.startsWith('00')) d = d.slice(2);
    else if (/^0[5-7]\d{8}$/.test(d)) d = '212' + d.slice(1);
    else if (/^[67]\d{8}$/.test(d)) d = '212' + d;
    return /^\d{9,15}$/.test(d) ? d : '';
  }
  /** The messages that make sense for this client now: [{ label, text }]. */
  function messages(c, app = APP) {
    const hi = `السلام عليكم ${c.prenom || ''}`.trim() + '،\n';
    const out = [];
    if (app === 'tls') {
      if (c.etape === 'manque') out.push({ label: '⚠ Il manque', text: `${hi}باش نكملو الدوسي ديال الفيزا ديال فرنسا، خاصك تجيب: ${c.manque || '…'}.\nشكرا.` });
      if (c.rdvDate) out.push({ label: '🗓 RDV', text: `${hi}الموعد ديالك فـ TLScontact${c.rdvCentre ? ' ' + c.rdvCentre : ''} نهار ${frDate(c.rdvDate)}${c.rdvHeure ? ' مع ' + c.rdvHeure : ''}.\nجيب معاك الباسبور والوثائق الأصلية. بالتوفيق!` });
      if (c.etape === 'complet') out.push({ label: '✅ Complet', text: `${hi}الدوسي ديالك كامل ✅. غادي نتواصلو معاك ملي يكون الموعد.` });
    } else {
      const r = c.reserve;
      if (r?.day) out.push({ label: '🗓 RDV', text: `${hi}الموعد ديالك فـ BLS (فيزا إسبانيا) نهار ${frDate(r.day)}${r.time ? ' مع ' + r.time : ''}.\nجيب معاك الباسبور والوثائق الأصلية. بالتوفيق!` });
      if (r?.face) out.push({ label: '🤳 Selfie', text: `${hi}خاصنا نديرو السيلفي ديال BLS قبل الموعد. عيط لينا عافاك باش نديروه.` });
    }
    const p = pay(c);
    if (p?.reste > 0) out.push({ label: '💰 Reste à payer', text: `${hi}باقي عليك ${money(p.reste)} ديال الدوسي.\nشكرا.` });
    out.push({ label: '✍ Message libre', text: hi });
    return out.map(m => ({ ...m, text: m.text + SIGN }));
  }
  const waUrl = (c, text) => `https://wa.me/${waNumber(c.mobile)}?text=${encodeURIComponent(text)}`;

  /** The «💬 WhatsApp» card of the ✎ form, for the client as it is saved. */
  function renderWa(box, c) {
    if (!box) return;
    if (!c?.id) { box.hidden = true; return; }
    box.hidden = false;
    const n = waNumber(c.mobile);
    const btns = messages(c).map(m => el('button', {
      type: 'button', className: 'small wa', textContent: m.label, title: m.text, disabled: !n,
      onclick: () => chrome.tabs.create({ url: waUrl(c, m.text) }),
    }));
    box.replaceChildren(...[
      el('div', { className: 'sec-title' }, '💬 WhatsApp ', el('small', { textContent: n ? `+${n}` : '' })),
      n ? null : el('div', { className: 'hint', textContent: 'Ajoutez le mobile du client (06… ou 07…) et enregistrez pour lui écrire.' }),
      el('div', { className: 'wa-row' }, ...btns),
      n ? el('div', { className: 'hint', textContent: 'Le message s\'ouvre dans WhatsApp, vous pouvez le changer avant d\'envoyer.' }) : null,
    ].filter(Boolean));
  }

  return { pay, payChip, fillPay, readPay, wirePay, messages, waNumber, waUrl, renderWa, money };
})();
