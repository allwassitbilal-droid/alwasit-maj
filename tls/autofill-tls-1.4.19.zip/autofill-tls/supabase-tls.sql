-- Autofill TLS : base partagée de l'équipe, À PART de celle d'Autofill BLS.
-- Dans le MÊME projet Supabase que BLS (mêmes comptes de l'équipe) : SQL Editor → New query → coller tout → Run (une seule fois).
-- Crée le tableau "clients_tls" et l'espace privé de fichiers "fichiers-tls". Ne touche pas aux données BLS.

create table if not exists public.clients_tls (
  id text primary key,
  data jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by text
);

revoke all on public.clients_tls from anon;
grant select, insert, update, delete on public.clients_tls to authenticated;
alter table public.clients_tls enable row level security;

drop policy if exists "equipe lit tls" on public.clients_tls;
drop policy if exists "equipe ajoute tls" on public.clients_tls;
drop policy if exists "equipe modifie tls" on public.clients_tls;
drop policy if exists "equipe supprime tls" on public.clients_tls;
create policy "equipe lit tls" on public.clients_tls for select to authenticated using (true);
create policy "equipe ajoute tls" on public.clients_tls for insert to authenticated with check (true);
create policy "equipe modifie tls" on public.clients_tls for update to authenticated using (true) with check (true);
create policy "equipe supprime tls" on public.clients_tls for delete to authenticated using (true);

alter publication supabase_realtime add table public.clients_tls;

-- Fichiers (formulaire, photo, passeport) des clients TLS : privé, 10 Mo max par fichier.
insert into storage.buckets (id, name, public, file_size_limit)
values ('fichiers-tls', 'fichiers-tls', false, 10485760)
on conflict (id) do nothing;

drop policy if exists "equipe lit fichiers tls" on storage.objects;
drop policy if exists "equipe ajoute fichiers tls" on storage.objects;
drop policy if exists "equipe modifie fichiers tls" on storage.objects;
drop policy if exists "equipe supprime fichiers tls" on storage.objects;
create policy "equipe lit fichiers tls" on storage.objects for select to authenticated using (bucket_id = 'fichiers-tls');
create policy "equipe ajoute fichiers tls" on storage.objects for insert to authenticated with check (bucket_id = 'fichiers-tls');
create policy "equipe modifie fichiers tls" on storage.objects for update to authenticated using (bucket_id = 'fichiers-tls') with check (bucket_id = 'fichiers-tls');
create policy "equipe supprime fichiers tls" on storage.objects for delete to authenticated using (bucket_id = 'fichiers-tls');
