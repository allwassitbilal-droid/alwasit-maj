// Agence Autofill «Créer le compte BLS»: with the client's real Gmail and passport (panel ✎), on BLS:
//  1. home / login page → the site's sign-up link;
//  2. sign-up wizard → each step filled from the panel (same filling as the 📝 button);
//  3. email code → the user is told to type the code sent to the client's Gmail (the extension never reads mail);
//  4. first login (password received by email, put by the user in «Mot de passe BLS") → the site's own
//     first-login page gets a new strong password, saved on the client before it is sent, so it can't be lost.
// While it runs, the saved login doesn't try the Gmail code on the BLS login form.
import { askBackground, sendToBackground, type SignupState } from "../shared/messages";
import { contextAlive, onSignupPage, rateGuard, sleep, textOf, waitFor } from "./util";

const CHECK_MS = 1500;
const SIGNUP_LINK_RE = /s.inscrire|cr[ée]er (un )?compte|inscription|sign ?up|register|create (an )?account|إنشاء حساب|التسجيل|registrarse|crear (una )?cuenta/i;
const OTP_TEXT_RE = /code|otp|v[ée]rification|التحقق|رمز|verificaci[óo]n/i;
const PASSWORD_PAGE_RE = /reset-password|change-password|first-login/i;
const PW_ERR_RE = /incorrect|invalid|erreur|error|failed|[ée]chec|خطأ|غير صحيح|no coincide|ne correspond/i;

let state: SignupState = { on: false };
let known = false;
let markKnown: () => void = () => {};
/** Resolves once the first answer about a running signup is in (the login waits for it). */
export const signupKnown: Promise<void> = new Promise((r) => (markKnown = r));

/** True while a signup runs and the client has no BLS password yet: the login form must not get the Gmail code. */
export const signupBlocksLogin = (): boolean => !known || (state.on && !state.hasPassword);

async function refresh(): Promise<void> {
  state = (await askBackground<SignupState>({ type: "signupState" })) ?? { on: false };
  if (!known) {
    known = true;
    markKnown();
  }
}

/** The site's «S'inscrire» link or button. */
function signupLink(): HTMLElement | undefined {
  const all = [...document.querySelectorAll<HTMLElement>('a, button, [role="button"]')];
  return (
    all.find((e) => e instanceof HTMLAnchorElement && /signup|register/i.test(e.getAttribute("href") ?? "")) ??
    all.find((e) => SIGNUP_LINK_RE.test(textOf(e).replace(/\s+/g, " ")) && textOf(e).length < 40)
  );
}

/** A one-time code box (6 digits, or one box per digit). */
const otpInput = (): HTMLInputElement | undefined =>
  [...document.querySelectorAll<HTMLInputElement>("input")].find(
    (i) =>
      i.autocomplete === "one-time-code" ||
      ((i.maxLength === 6 || i.maxLength === 1) && (i.inputMode === "numeric" || i.type === "tel" || i.type === "text") && OTP_TEXT_RE.test(document.body.innerText)),
  );

/** Strong password the site accepts (upper, lower, digit, symbol; 12 characters). */
export function newPassword(): string {
  const sets = ["ABCDEFGHJKLMNPQRSTUVWXYZ", "abcdefghijkmnpqrstuvwxyz", "23456789", "@#$!%*?&"];
  const pick = (s: string) => s[crypto.getRandomValues(new Uint32Array(1))[0]! % s.length]!;
  const chars = [...sets.map(pick), ...Array.from({ length: 8 }, () => pick(sets.join("")))];
  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.getRandomValues(new Uint32Array(1))[0]! % (i + 1);
    [chars[i], chars[j]] = [chars[j]!, chars[i]!];
  }
  return chars.join("");
}

function setValue(el: HTMLInputElement, v: string): void {
  Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set?.call(el, v);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

const toastText = (): string =>
  [...document.querySelectorAll<HTMLElement>('[data-sonner-toast], [role="alert"]')].map((x) => x.innerText.replace(/\s+/g, " ")).join(" | ");

/** The site's first-login page: current (the emailed password), new, confirmation. */
async function changeFirstPassword(say: (t: string) => void): Promise<void> {
  const fields = [...document.querySelectorAll<HTMLInputElement>('input[type="password"]')];
  if (fields.length !== 3 || !state.password || !rateGuard("aaSignupPw", 1, 10 * 60_000)) return;
  const [current, next, confirm] = fields as [HTMLInputElement, HTMLInputElement, HTMLInputElement];
  const pw = newPassword();
  // Saved on the client first (the old one kept), so a lost answer can't lose the password.
  const saved = await askBackground<{ ok: boolean }>({ type: "signupPassword", password: pw });
  if (!saved?.ok) return say("⚠️ ما قدرتش نسجل الـ mot de passe الجديد فالبانو: بدلو بيدك");
  setValue(current, state.password);
  setValue(next, pw);
  setValue(confirm, pw);
  await sleep(400);
  const btn = next.closest("form")?.querySelector<HTMLButtonElement>('button[type="submit"]');
  if (!btn || btn.disabled) {
    sendToBackground({ type: "signupPassword", failed: true });
    return say("⚠️ ما لقيتش البوطونة ديال تبديل الـ mot de passe: كمل بيدك");
  }
  const where = location.pathname;
  btn.click();
  const done = await waitFor(() => location.pathname !== where || (PW_ERR_RE.test(toastText()) ? "err" : false), 15_000, 250);
  if (done === "err" || !done) {
    sendToBackground({ type: "signupPassword", failed: true });
    return say(`⚠️ BLS ما قبلش الـ mot de passe الجديد${toastText() ? `: ${toastText().slice(0, 120)}` : ""}. شوف الصفحة`);
  }
  sendToBackground({ type: "signupPassword" });
  say("✅ تبدل الـ mot de passe وتسجل فالبانو (✎ → Mot de passe BLS). الكونط واجد: كمل «Formulaire de demande» بـ 📝");
}

/**
 * Runs the signup steps on whatever BLS page shows. fillPage: the page script's form filling (📝).
 * say: a line in the bar + a notification.
 */
export function startSignupHelper(fillPage: () => Promise<unknown>, say: (text: string) => void): void {
  let filledSig = "";
  let toldOtp = false;
  let toldPassword = false;
  let clickedLink = false; // once per page: the click leads to another page
  let busy = false;

  const tick = async () => {
    if (busy || !contextAlive()) return;
    busy = true;
    try {
      await refresh();
      if (!state.on) return;
      const path = location.pathname;

      if (PASSWORD_PAGE_RE.test(path)) return void (await changeFirstPassword(say));

      if (onSignupPage()) {
        const otp = otpInput();
        if (otp) {
          if (!toldOtp) {
            toldOtp = true;
            sendToBackground({ type: "signupStage", stage: "otp" });
            say(`📧 BLS صيفط كود لـ ${state.gmail}: حل الـ Gmail ديال الكليان وكتب الكود هنا`);
          }
          return;
        }
        // Each wizard step once: its fields' set changes from one step to the next.
        const sig = [...document.querySelectorAll("input, select, button[aria-haspopup]")].map((e) => (e as HTMLInputElement).name || e.id || e.tagName).join(",");
        if (sig && sig !== filledSig) {
          filledSig = sig;
          await sleep(600);
          await fillPage();
        }
        return;
      }

      // Signed out, on the home or login page: the account doesn't exist yet → sign up.
      const loginForm = document.querySelector('input[type="password"]');
      if (state.stage === "form" && !state.hasPassword) {
        const link = signupLink();
        if (link && !clickedLink && rateGuard("aaSignupLink", 3, 10 * 60_000)) {
          clickedLink = true;
          await sleep(800);
          link.click();
        }
        return;
      }
      // Account made, password not in the panel yet: the user puts the emailed one in ✎.
      if (loginForm && !state.hasPassword && !toldPassword) {
        toldPassword = true;
        sendToBackground({ type: "signupStage", stage: "password" });
        say("🔐 BLS صيفط mot de passe لـ Gmail ديال الكليان: حطو ف البانو (✎ → Mot de passe BLS)، والدخول كيكون بوحدو");
      }
    } finally {
      busy = false;
    }
  };
  void tick();
  setInterval(() => void tick(), CHECK_MS);
}
