// Every piece of BLS UI text the extension matches, in all four site languages (ar/en/fr/es).
// Source: the site's own translation files, /locales/{lang}/{common,appointments,booking,liveness}.json
// (checked on morocco.blsinternational.com, 2026-10-25). Update here if BLS rewords its UI.

/** appointments.json › moreActions */
export const MORE_ACTIONS_RE = /المزيد من الإجراءات|more actions|plus d.actions|más acciones/i;

/** booking.json › constants.resumeSlot */
export const PROCEED_RE = /المضي قد|continue to slot selection|continuer vers la s[ée]lection du cr[ée]neau|continuar a la selecci[óo]n de turno/i;

/** common.json › manageAppointments (the sidebar link is also matched by its href) */
export const MANAGE_TEXT_RE = /^(إدارة المواعيد|manage appointments|g[ée]rer les rendez-vous|gestionar citas)$/i;

/** appointments page empty state: no appointment yet on this account (fr/en from the site, ar/es best guess). */
export const NO_APPOINTMENT_RE = /aucun rendez-vous|no appointments|لا توجد مواعيد|no (tienes|hay) citas/i;

/** booking.json › modals.bookNew.title — the button that starts a new booking (fr/en from the site, ar/es best guess). */
export const BOOK_NEW_RE = /prendre un nouveau rendez-vous|book (a )?new appointment|حجز موعد جديد|reservar (una )?nueva cita/i;

/** booking.json › applicants.readyToBook — an applicant on the «Prendre rendez-vous» list can be booked. */
export const READY_RE = /pr[êe]t à r[ée]server|ready to book|جاهز للحجز|listo para reservar/i;

/** The «Prendre rendez-vous» button above the applicants list (the whole text, so other buttons don't match). */
export const BOOK_BTN_RE = /^(prendre (un nouveau )?rendez-vous|book (new )?appointments?|حجز (موعد|المواعيد)( جديد)?|reservar (nueva )?cita)$/i;

/** booking.json › modals.bookNew.cannotBookWhileActive (fr/en from the site, ar/es best guess). */
export const ACTIVE_APPT_RE = /d[ée]j[àa] un rendez-vous actif|already have an active appointment|cannot book a new appointment while|موعد نشط|cita activa/i;

/** The «D'accord» button that closes that notice. */
export const OK_BTN_RE = /^(d.accord|ok|okay|حسنا|موافق|de acuerdo|aceptar)$/i;

/** booking.json › slot.selectAppointmentDate */
export const DATE_PAGE_RE = /اختر تاريخ الموعد|select appointment date|s[ée]lectionner une date de rendez-vous|seleccionar fecha de cita/i;

/** booking.json › slot.nextMonthAriaLabel / previousMonthAriaLabel */
export const NEXT_MONTH_RE = /الشهر التالي|next month|mois suivant|mes siguiente/i;
export const PREV_MONTH_RE = /الشهر السابق|previous month|mois pr[ée]c[ée]dent|mes anterior/i;

/** booking.json › slot.noSlotsAvailable / noSlotsNow / noDatesInMonth */
export const EMPTY_RE =
  /لا توجد مواعيد متاحة|no slots available|no appointment dates in this month|aucun cr[ée]neau disponible|aucune date disponible|no hay turnos disponibles|no hay fechas disponibles/i;

/** booking.json › slot.confirmSlot / confirmSlots (the final button the user clicks) */
export const CONFIRM_BTN_RE = /تأكيد الموعد|confirm slots?\b|confirmer les? cr[ée]neaux?|confirmar turnos?/i;

/** booking.json › slot.slotConfirmed / familySlotsConfirmed / takingYouTo */
export const OK_RE =
  /تم (الحجز|تأكيد)|ننقلك إلى التحقق|slots? confirmed|taking you to applicant verification|cr[ée]neaux? confirm[ée]s?|redirection vers la v[ée]rification|turnos? confirmados?|redirigiendo a la verificaci[óo]n|success|booked/i;

/** booking.json › slot.confirmFailed / noSlotsThisDate, plus generic failures */
export const ERR_RE =
  /لا توجد|غير متاح|غير متوفر|فشل|خطأ|failed|error|unavailable|no (time )?slots?|has no available|[ée]chec|aucun|erreur|error al|no hay/i;

/** liveness.json › landing.title — reaching identity verification means the slot was accepted. */
export const FACE_RE =
  /التحقق من الحيوية|مسح الوجه|liveness|face scan|take photo|switch camera|v[ée]rification de pr[ée]sence|verificaci[óo]n de identidad/i;

/** A follow-up "are you sure?" button inside a new dialog. */
export const FOLLOWUP_CONFIRM_RE = /تأكيد|confirm|نعم|yes|oui|s[íi]\b|confirmer|confirmar/i;
