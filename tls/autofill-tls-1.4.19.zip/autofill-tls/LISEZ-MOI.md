# Autofill TLS

إضافة Chrome ديال الوكالة للدوسيات ديال **TLScontact France**. بحال Autofill BLS، ولكن بلائحة زبناء بوحدها.

## التركيب
1. `chrome://extensions` ← **Mode développeur** ← **Charger l'extension non empaquetée** ← ختار هاد الدوسي.
2. حل اللوحة بـ **Alt+T** (ولا الأيقونة).

## المشاركة مع الخدامة (مرة وحدة)
1. فـ Supabase (نفس المشروع ديال BLS): **SQL Editor** ← **New query** ← لصق **supabase-tls.sql** كامل ← **Run**.
2. فاللوحة **☁** ← نفس الإيميل والمودپاس ديال BLS.
الزبناء ديال TLS كايتخزنو فـ `clients_tls`، بعاد على ديال BLS.

## الجديد فـ TLS
- **🗓 Compte TLS créé le:** الكونط ديال TLS كايدوم 3 شهور. قبل بسيمانة كايبان **⏳** فاللائحة، ونوتيفيكاسيون Windows، وميساج Telegram. ملي يسالي **⛔**. زر **Aujourd'hui** ملي تصاوب كونط جديد.
- **📋 Étape:** 🆕 Nouveau · 📄 Documents en cours · ⚠️ Il manque (مع "Ce qui manque") · ✅ Complet · 🗓 RDV pris (date, heure, centre).
- **📝 Notes** لكل دوسي (كاتبان 📝 فاللائحة، والبحث كايلقى فيها).
- **📦 Archive:** ملي تاخد RDV ← ✎ ← **Archiver**. الدوسي كايمشي لـ **📦 Archive** (الفاميلة كاملة). **↩ Sortir de l'archive** باش يرجع.
- **⚙ → Telegram:** Token + Chat ID (Trouver / Tester)، و **Vérifier maintenant**.

## ➕ Nouveau client (v1.2)
**➕ Nouveau client** (لتحت ولا +) كايحل الزبون خطوة بخطوة، بنفس الترتيب ديال الفورمولير France-Visas:
1. **Passeport:** أول حاجة السكان ديال الباسبور (كليك، سحب، ولا Ctrl+V). كايعمر الاسم، الولادة، الباسبور، التواريخ، الجنسية والجنس. ولا **📄 من الـ PDF France-Visas**.
2. **Identité** · 3. **Adresse** (العنوان والخدمة) · 4. **Voyage** · 5. **Séjour** (الأوطيل والتمويل) · 6. **Dossier** (Gmail، الكونط TLS، المرحلة، الدوسي، الفاميلة، الملفات).
**Suivant →** / **← Précédent**، و **Enregistrer** فالخطوة 6. تصويرة الباسبور كاتتحفظ فـ 📎 🛂 Passeport.
فـ ✎ (زبون كاين) كايبان كلشي، والأرقام 1-6 لفوق كايديوك للجزء ديالهم.

## 🇫🇷 Formulaire France-Visas (v1.1)
- **📄 PDF France-Visas** (لتحت): ختار PDF واحد ولا بزاف. كل PDF كايتقرا بوحدو (بلا أنترنت) وكايعمر الزبون: الاسم، الباسبور، التاريخ، الهاتف، و 35 خانة ديال الفورمولير (الولادة، الجنسية، الحالة العائلية، CIN، العنوان، الخدمة، السفر، الأوطيل، التمويل، المرجع FRA…).
- إلا الزبون كاين ديجا (نفس الباسبور ولا نفس المرجع FRA…) كايتحدّث، وإلا كايتصاوب جديد فالدوسي المحلول.
- الـ PDF كايتحفظ فـ 📎 📄 Formulaire ديال الزبون (إلا كنتي متصل ☁).
- فـ ✎ كاين قسم **🇫🇷 Formulaire France-Visas** مقسم بالمجموعات، وزر **Remplir depuis le PDF** للزبون المحلول.
- ⧉ كايبين حتى خانات France-Visas باش تحطهم بضغطة، والتعمار الأوتوماتيكي كايعرف: الولادة، الجنسية، الجنس، الحالة العائلية، CIN، العنوان، الخدمة، تواريخ السفر.
- Export CSV فيه حتى خانات France-Visas.

## باقي بحال BLS
الدوسيات (بومبون 3D)، N° dossier، ⭐ Prêts، الفاميلات، 📷 Scanner passeport، ⤓ Capturer، Import/Export CSV، 📎 Fichiers.

## مازال (مرحلة 2)
التعمار الخاص بـ TLS والمراقبة ديال المواعيد: خاصني تصاور ولا HTML ديال الصفحات ديال TLS.
