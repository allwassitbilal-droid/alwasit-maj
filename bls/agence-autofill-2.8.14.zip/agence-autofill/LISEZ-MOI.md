# Autofill BLS

## Installation (Chrome / Edge)
1. Ftah `chrome://extensions` (Edge: `edge://extensions`)
2. Chegel **Mode développeur** (lfou9 3la limen)
3. Click **Charger l'extension non empaquetée** → khtar had dossier `agence-autofill`
4. Épingli l'icône (📌) bach tbanlek dima

## Partage m3a l'équipe (☁)
Chouf **PARTAGE-EQUIPE.md**: kifach tsawb la base Supabase w tzid les employés. Mn b3d kol tabdil kayban 3nd kolchi f ثانية.

## Isti3mal
**Panneau jdid (v1.2):** click 3la l'icône (ola Alt+Q) → kat7el lista f jnb limen dial Chrome w katb9a m7loula.
- **Case + valeur:** click 3la case f formulaire (ex: Prénom) → click 3la l9ima f panneau (FIRDAOUS) → katdkhol f blastha. Bla Ctrl+C / Ctrl+V.
- Ila l page m7miya (extensions ma y9drouch ykteb fiha), l9ima katcopia → click f case w dir Ctrl+V.
- **Dossiers:** f lfou9 kaynin les dossiers (📁 Omra, 📁 Schengen…). Click 3la dossier → katban ghir l7isabat dialo.
  **+ Dossier** = dossier jdid · **✎** = beddel smiya · **🗑** (2 clicks) = 7yed dossier (l7isabat kayb9aw f "Sans dossier").
  Compte jdid (+, scan, import CSV) kaydkhol f dossier m7loul. Bach tbeddel dossier dial compte: ✎ → champ "Dossier".
- Mn b3d l'installation ola update: **actualisi (F5)** pages li kanou m7loulin.

- **Alt+Q** (ola click 3la l'icône) → katban la liste dial ga3 l7isabat (20, 50, 100… bla limite).
- **Click 3la smiya** → kay3mer l formulaire direct. (Ola kteb smiya f search → **Entrée**.)
- **⚙** → khtar chmen champs bghiti yt3amrou (kayt3ewd l ga3 l7isabat).
- **✎** → modifier compte. F lta7t kayn **Champs en plus**: kteb ay champ bghiti, sater b sater:
  ```
  Email = client@gmail.com
  Nationalité = Marocaine
  Lieu de naissance = Fès
  ```
  L'ism 3la limen dial `=` khasso ykoun kif smiyat l champ f site.
- **⧉** → boutons copier l kol champ (copier-coller).
- **+** → compte jdid.
- **📷 Scanner passeport** → kat7el page jdida. Dir tswira (wla bzaf d tswar f merra) dial page dial passeport:
  click / glisser / Ctrl+V. Kayqra l7rouf li lte7t (P<MAR…) w kay3mer: Prénom, Nom, Naissance, N° passeport, Expire,
  w Délivré (m7soub: expire − 5 ans). ✓ = mzyan, ✗ = chouf w sle7. Lieu délivrance w Mobile kteb-hom nta. Men b3d **Enregistrer**.
  Tswira khassha tkoun wadi7a w lktaba lte7tania bayna. Kaykhdem bla internet.
- **Capturer la page** → ila l formulaire 3amer, kayqrah w kaydir compte jdid.
- **Importer CSV** → men Excel (Enregistrer sous → CSV). Colonnes: Prénom; Nom; Naissance; N° passeport; Délivré; Expire; Lieu délivrance; Mobile; Champs en plus; Dossier. Dates: jj/mm/aaaa.
- **Exporter CSV** → backup dial ga3 l7isabat (dirha b chi merra: ila t7ydat l'extension kayt7yd ga3 data).

## Ma3loumat
- Data katkhtazen ghir f l'ordinateur (chrome.storage.local), ma katsift l 7ta serveur.
- Les règles dial les champs kaynin f `rules.js`. `test-form.html` = formulaire d test.
