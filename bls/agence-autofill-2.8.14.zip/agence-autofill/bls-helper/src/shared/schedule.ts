// Peak-time scheduling. Pure functions: everything takes "now" explicitly so it is testable.
import type { PeakSettings, Settings } from "./settings";

const DAY_MIN = 1440;

export type Phase =
  | { phase: "off" }
  | { phase: "normal"; peak: number; inMin: number }
  | { phase: "pre"; peak: number; inMin: number }
  | { phase: "peak"; peak: number; leftMin: number };

/** "09:00, 15:30" -> [540, 930] (minutes since midnight, sorted, invalid entries dropped). */
export function parseTimes(input: string): number[] {
  return input
    .split(/[,،;\s]+/)
    .map((x) => /^(\d{1,2}):(\d{2})$/.exec(x.trim()))
    .filter((m): m is RegExpExecArray => !!m && Number(m[1]) < 24 && Number(m[2]) < 60)
    .map((m) => Number(m[1]) * 60 + Number(m[2]))
    .sort((a, b) => a - b);
}

export function computePhase(peak: PeakSettings, now: Date): Phase {
  if (!peak.enabled) return { phase: "off" };
  const times = parseTimes(peak.times);
  if (!times.length) return { phase: "off" };

  const nowMin = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;
  const lead = Math.max(0, peak.leadMin);
  const dur = Math.max(1, peak.durationMin);
  let next = Infinity;

  // Check yesterday/today/tomorrow so windows that cross midnight work.
  for (const base of [-DAY_MIN, 0, DAY_MIN]) {
    for (const t0 of times) {
      const t = t0 + base;
      if (nowMin >= t - lead && nowMin < t) return { phase: "pre", peak: t0, inMin: t - nowMin };
      if (nowMin >= t && nowMin < t + dur) return { phase: "peak", peak: t0, leftMin: t + dur - nowMin };
      if (t - lead > nowMin && t < next) next = t;
    }
  }
  return { phase: "normal", peak: ((next % DAY_MIN) + DAY_MIN) % DAY_MIN, inMin: next - nowMin };
}

export const isHot = (p: Phase): boolean => p.phase === "pre" || p.phase === "peak";

export function effectiveIntervalSec(s: Settings, p: Phase): number {
  return isHot(p) ? s.peak.intervalSec : s.intervalSec;
}

export function formatClock(min: number): string {
  return `${String(Math.floor(min / 60)).padStart(2, "0")}:${String(min % 60).padStart(2, "0")}`;
}

/**
 * How far (ms) a wait overran its schedule, or 0 when the overrun is within normal jitter.
 * A large overrun means Chrome is throttling the tab's timers (hidden tab: about one wake per minute).
 */
export function timerLagMs(plannedMs: number, actualMs: number): number {
  const over = actualMs - plannedMs;
  return over > Math.max(5000, plannedMs * 0.5) ? over : 0;
}

/** Seconds left until an epoch-ms instant, never negative. */
export const secondsUntil = (at: number, now = Date.now()): number => Math.max(0, Math.ceil((at - now) / 1000));

export function phaseLabel(p: Phase): string {
  switch (p.phase) {
    case "pre":
      return `⏳ الذروة ${formatClock(p.peak)} بعد ${formatDuration(p.inMin)}`;
    case "peak":
      return `🔥 ذروة ${formatClock(p.peak)} — باقي ${formatDuration(p.leftMin)}`;
    case "normal":
      return `الذروة الجاية ${formatClock(p.peak)} (بعد ${formatDuration(p.inMin)})`;
    default:
      return "";
  }
}

export function formatDuration(min: number): string {
  const m = Math.max(0, Math.round(min));
  return m >= 60 ? `${Math.floor(m / 60)}س ${m % 60}د` : `${m}د`;
}
