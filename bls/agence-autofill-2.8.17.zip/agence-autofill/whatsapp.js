// 📲 WhatsApp to the team's staff (side panel). WhatsApp can't be sent silently for free, so each button
// opens WhatsApp (wa.me) on the person's number with the message already written: one click on «Envoyer».
// - «📲» (top bar): the appointments of today, tomorrow and the next ones.
// - A new appointment (✎ saved, letter imported, or booked by the extension): a strip «RDV جديد» with one
//   button per person, until it's sent or dismissed (waPending, this PC only).
// The numbers are the team's (teamSettings.whatsapp = [{ nom, tel }], shared ☁), set in ⚙.
(() => {
  const local = chrome.storage.local;
  const q = s => document.querySelector(s);
  const mk = (tag, props = {}, ...kids) => { const e = Object.assign(document.createElement(tag), props); e.append(...kids.filter(Boolean)); return e; };
  const say = (m, bad) => (globalThis.toast ? globalThis.toast(m, bad) : console.log(m));
  const fr = iso => (iso ? iso.split('-').reverse().join('/') : '');
  const ymd = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const JOURS = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
  const jour = iso => JOURS[new Date(iso + 'T12:00:00').getDay()];
  const name = c => `${c.prenom || ''} ${c.nom || ''}`.trim() || '(sans nom)';
  const who = c => `${c.num != null && c.num !== '' ? 'N°' + c.num + ' ' : ''}${name(c)}`;

  /** 06 12 34 56 78 / +212 6… / 00212 6… → 2126…; '' when it doesn't look like a number. */
  function intl(tel) {
    let d = String(tel || '').replace(/\D/g, '');
    if (d.startsWith('00')) d = d.slice(2);
    if (/^0[5-7]\d{8}$/.test(d)) d = '212' + d.slice(1);
    return d.length >= 10 && d.length <= 15 ? d : '';
  }
  const parseNumbers = text => String(text || '').split('\n').map(l => l.trim()).filter(Boolean).map(l => {
    const m = l.match(/^(.*?)[\s:=-]*([+\d][\d\s.()+-]{7,})$/);
    return m ? { nom: m[1].replace(/[:=-]\s*$/, '').trim() || 'Équipe', tel: m[2].trim() } : null;
  }).filter(p => p && intl(p.tel));

  const team = async () => (await local.get('teamSettings')).teamSettings || {};
  const numbers = async () => ((await team()).whatsapp || []).filter(p => intl(p.tel));
  const open = (tel, text) => chrome.tabs.create({ url: `https://wa.me/${intl(tel)}?text=${encodeURIComponent(text)}` });

  // ---- message texts ----
  const familyOf = (clients, c) => (c.famille ? clients.filter(x => x.famille === c.famille) : [c]);
  function newText(clients, c, r) {
    const fam = familyOf(clients, c);
    const where = [r.centre, r.ref && 'Réf ' + r.ref].filter(Boolean).join(' · ');
    return [
      '🗓 RDV BLS جديد 🇪🇸',
      `👤 ${fam.length > 1 ? `عائلة (${fam.length}) : ${fam.map(who).join('، ')}` : who(c)}`,
      `📅 ${jour(r.day)} ${fr(r.day)}${r.time ? ' à ' + r.time : ''}`,
      where && `📍 ${where}`,
    ].filter(Boolean).join('\n');
  }

  function summaryText(clients) {
    const today = ymd(), tomorrow = ymd(new Date(Date.now() + 864e5));
    const seen = new Set();
    const rows = clients.filter(c => !c.archive && c.reserve?.day && c.reserve.day >= today)
      .filter(c => { const k = c.famille || c.id; if (seen.has(k)) return false; seen.add(k); return true; })
      .map(c => ({ c, r: c.reserve, n: familyOf(clients, c).length }))
      .sort((a, b) => (a.r.day + (a.r.time || '')).localeCompare(b.r.day + (b.r.time || '')));
    const line = ({ c, r, n }, withDay) => `• ${withDay ? fr(r.day).slice(0, 5) + ' ' : ''}${r.time || ''} ${who(c)}${n > 1 ? ` (+${n - 1})` : ''}${r.centre ? ' — ' + r.centre : ''}`.replace('•  ', '• ');
    const part = (title, list, withDay) => (list.length ? `${title}\n${list.map(x => line(x, withDay)).join('\n')}` : '');
    const later = rows.filter(x => x.r.day > tomorrow);
    const body = [
      part(`⏰ اليوم ${fr(today).slice(0, 5)}`, rows.filter(x => x.r.day === today)),
      part(`🗓 غدا ${fr(tomorrow).slice(0, 5)}`, rows.filter(x => x.r.day === tomorrow)),
      part('➡️ المواعيد الجايين', later.slice(0, 10), true) + (later.length > 10 ? `\n… و ${later.length - 10} آخرين` : ''),
    ].filter(Boolean).join('\n\n');
    return `📋 مواعيد BLS 🇪🇸 — ${jour(today)} ${fr(today)}\n\n${body || 'ما كاين حتى موعد جاي.'}`;
  }

  // ---- the box with one button per person ----
  function buttons(people, text, onSent) {
    const sent = new Set();
    const row = mk('div', { className: 'wa-btns' });
    const done = () => { if (sent.size >= people.length) onSent?.(); };
    for (const p of people) {
      row.append(mk('button', {
        type: 'button', className: 'wa', textContent: `📲 ${p.nom}`, title: p.tel,
        onclick: e => { open(p.tel, text); sent.add(p.tel); e.target.classList.add('sent'); e.target.textContent = `✓ ${p.nom}`; done(); },
      }));
    }
    if (people.length > 1) {
      row.append(mk('button', {
        type: 'button', className: 'wa', textContent: '📲 الكل',
        onclick: () => { people.forEach(p => { open(p.tel, text); sent.add(p.tel); }); row.querySelectorAll('.wa').forEach(b => b.classList.add('sent')); done(); },
      }));
    }
    return row;
  }

  async function needNumbers() {
    const people = await numbers();
    if (!people.length) {
      say('📲 زيد النمر ديال الخدامين فـ ⚙ (WhatsApp de l\'équipe)', true);
      q('#settings').hidden = false;
      q('#wa-nums')?.focus();
    }
    return people;
  }

  // «📲» in the top bar: today, tomorrow and the next appointments
  async function showSummary() {
    const box = q('#wa-box');
    if (!box.hidden) { box.hidden = true; return; }
    const people = await needNumbers();
    if (!people.length) return;
    const { clients = [] } = await local.get('clients');
    const text = summaryText(clients);
    box.replaceChildren(
      mk('div', { className: 'wa-head' }, mk('strong', { textContent: '📲 صيفط المواعيد فـ WhatsApp' }),
        mk('button', { type: 'button', className: 'icon', textContent: '✕', onclick: () => { box.hidden = true; } })),
      mk('pre', { className: 'wa-text', textContent: text }),
      buttons(people, text, () => setTimeout(() => { box.hidden = true; }, 1500)));
    box.hidden = false;
  }

  // ---- new appointments waiting to be sent ----
  async function addPending(id) {
    const { waPending = [] } = await local.get('waPending');
    await local.set({ waPending: [...waPending.filter(p => p.id !== id), { id, at: Date.now() }].slice(-15) });
  }
  async function dropPending(id) {
    const { waPending = [] } = await local.get('waPending');
    await local.set({ waPending: waPending.filter(p => p.id !== id) });
  }

  async function renderPending() {
    const box = q('#wa-new');
    if (!box) return;
    const { waPending = [], clients = [] } = await local.get(['waPending', 'clients']);
    const people = await numbers();
    const items = waPending.map(p => ({ p, c: clients.find(c => c.id === p.id) })).filter(x => x.c?.reserve?.day && Date.now() - x.p.at < 3 * 864e5);
    box.hidden = !items.length;
    box.replaceChildren(...items.map(({ c }) => {
      const r = c.reserve;
      const text = newText(clients, c, r);
      return mk('div', { className: 'wa-item' },
        mk('div', { className: 'wa-head' },
          mk('span', { textContent: `🗓 RDV جديد : ${name(c)} — ${fr(r.day).slice(0, 5)} ${r.time || ''}` }),
          mk('button', { type: 'button', className: 'icon', textContent: '✕', title: 'Ne pas envoyer', onclick: () => dropPending(c.id) })),
        people.length ? buttons(people, text, () => setTimeout(() => dropPending(c.id), 1200))
          : mk('button', { type: 'button', className: 'wa', textContent: '📲 زيد النمر ديال الخدامين (⚙)', onclick: needNumbers }));
    }));
  }

  // ---- ⚙: the staff numbers ----
  async function renderConfig() {
    const box = q('#settings');
    if (!box || q('#wa-cfg')) return;
    const area = mk('textarea', { id: 'wa-nums', rows: 3, placeholder: 'Ahmed: 06 12 34 56 78\nHmouri: 07 00 00 00 00' });
    const msg = mk('div', { className: 'hint' });
    const people = await numbers();
    area.value = people.map(p => `${p.nom}: ${p.tel}`).join('\n');
    box.append(mk('div', { id: 'wa-cfg', className: 'tg' },
      mk('div', { className: 'hint', textContent: '📲 WhatsApp de l\'équipe (un par ligne : Nom: numéro) — pour envoyer les RDV' }),
      area,
      mk('button', {
        type: 'button', className: 'wide-btn', textContent: 'Enregistrer les numéros',
        onclick: async () => {
          const list = parseNumbers(area.value);
          const bad = area.value.split('\n').filter(l => l.trim()).length - list.length;
          const t = await team();
          await local.set({ teamSettings: { ...t, whatsapp: list } });
          area.value = list.map(p => `${p.nom}: ${p.tel}`).join('\n');
          msg.textContent = `✓ ${list.length} numéro(s) enregistré(s) pour toute l'équipe` + (bad > 0 ? ` — ${bad} ligne(s) ignorée(s)` : '');
          renderPending();
        },
      }),
      msg));
  }

  function init() {
    q('#waBtn')?.addEventListener('click', showSummary);
    renderConfig();
    renderPending();
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === 'local' && (ch.waPending || ch.clients || ch.teamSettings)) renderPending();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  globalThis.AAWhatsApp = { addPending, summaryText, newText, intl, parseNumbers };
})();
