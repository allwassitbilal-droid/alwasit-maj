// BLS Morocco, background side (service worker). The page side is BLS Helper's content script
// (bls/content.js, built from bls-helper/): auto-login, navigation to the dates, slot watcher,
// applicant and signup forms. Here: the panel's «BLS» button, the account switch between clients,
// alerts (notification, sound, Telegram), and the one-watching-tab rule. Message names are BLS Helper's.
(() => {
  const BLS_HOME = 'https://morocco.blsinternational.com/';
  const BLS_TABS = 'https://*.blsinternational.com/*';
  const BLS_URL_RE = /^https:\/\/[^/]*\.blsinternational\.com\//;
  const ACTIVE_KEY = 'blsActive';
  const LEADER_KEY = 'watchLeader';
  const AUTOSTART_KEY = 'autoStartTab';
  const AUTOSTART_WINDOW_MS = 10 * 60_000;
  const HISTORY_KEY = 'blsHistory';
  const NOTIF_PREFIX = 'bls:';
  const local = chrome.storage.local;

  // This PC's BLS settings, with the team's (synced) Telegram and peak hours on top.
  const settings = async () => {
    const { blsSettings = {}, teamSettings = {} } = await local.get(['blsSettings', 'teamSettings']);
    return { ...blsSettings, ...(teamSettings.telegram && { telegram: teamSettings.telegram }), ...(teamSettings.peak && { peak: teamSettings.peak }) };
  };
  const clientById = async id => ((await local.get('clients')).clients || []).find(c => c.id === id);

  // ---- alerts ----
  async function beep() {
    try {
      if (!(await chrome.offscreen.hasDocument())) {
        await chrome.offscreen.createDocument({
          url: 'bls/offscreen.html', reasons: ['AUDIO_PLAYBACK'],
          justification: 'Play an alert sound when an appointment is available',
        });
        await new Promise(r => setTimeout(r, 200));
      }
      await chrome.runtime.sendMessage({ type: 'offscreen-beep' });
    } catch { /* no sound: the notification still shows */ }
  }

  async function telegram(token, method, body) {
    const init = { signal: AbortSignal.timeout(10_000) };
    if (body) Object.assign(init, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    return (await fetch(`https://api.telegram.org/bot${encodeURIComponent(token)}/${method}`, init)).json();
  }

  async function sendTelegram(tg, text) {
    if (!tg?.botToken || !tg?.chatId) return { ok: false, error: 'خاص التوكن و chat id' };
    try {
      const r = await telegram(tg.botToken, 'sendMessage', { chat_id: tg.chatId, text: `🗓 Autofill BLS\n${text}` });
      return r.ok ? { ok: true } : { ok: false, error: r.description || 'Telegram رفض الرسالة' };
    } catch (e) { return { ok: false, error: e.message }; }
  }

  async function findChatId(token) {
    if (!token) return { ok: false, error: 'دخل التوكن ديال البوت أولا' };
    try {
      const r = await telegram(token, 'getUpdates');
      if (!r.ok) return { ok: false, error: r.description || 'التوكن غلط' };
      const chat = [...(r.result || [])].reverse().find(u => u.message)?.message?.chat;
      if (!chat) return { ok: false, error: 'صيفط أي رسالة للبوت ديالك فـ Telegram وعاود' };
      return { ok: true, chatId: String(chat.id), name: chat.first_name || chat.title || chat.username || '' };
    } catch (e) { return { ok: false, error: e.message }; }
  }

  // «[Fatima BENNANI] …»: alerts say who the slot is for.
  async function notify(raw, tabId) {
    beep();
    const { [ACTIVE_KEY]: id } = await local.get(ACTIVE_KEY);
    const c = id && await clientById(id);
    const who = c ? `${c.prenom || ''} ${c.nom || ''}`.trim() : '';
    const text = (who ? `[${who}] ` : '') + (raw || 'كاين تاريخ متاح، سير دابا للصفحة');
    addLog('🔔 ' + text, 'ok');
    chrome.notifications.create(`${NOTIF_PREFIX}${tabId ?? ''}:${Date.now()}`, {
      type: 'basic', iconUrl: 'bls/icon.png', title: 'Autofill BLS', message: text, priority: 2, requireInteraction: true,
    });
    const s = await settings();
    if (s.telegram?.enabled) sendTelegram(s.telegram, text);
  }

  chrome.notifications.onClicked.addListener(async id => {
    if (!id.startsWith(NOTIF_PREFIX)) return;
    chrome.notifications.clear(id);
    const fromId = parseInt(id.slice(NOTIF_PREFIX.length), 10);
    let tab = Number.isNaN(fromId) ? undefined : await chrome.tabs.get(fromId).catch(() => undefined);
    tab ||= (await chrome.tabs.query({ url: BLS_TABS }))[0];
    if (!tab?.id) return;
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  });

  // ---- one watching tab (leader), kept in session storage: the worker can stop anytime ----
  let leaderOp = Promise.resolve();
  const serialized = fn => { const op = leaderOp.then(fn); leaderOp = op.catch(() => {}); return op; };

  async function liveLeader() {
    const id = (await chrome.storage.session.get(LEADER_KEY))[LEADER_KEY];
    if (typeof id !== 'number') return undefined;
    const tab = await chrome.tabs.get(id).catch(() => undefined);
    return tab?.url && BLS_URL_RE.test(tab.url) ? id : undefined;
  }

  const claim = (tabId, takeover) => serialized(async () => {
    const current = await liveLeader();
    if (current !== undefined && current !== tabId) {
      if (!takeover) return { ok: false };
      await chrome.tabs.sendMessage(current, { type: 'yield' }).catch(() => {});
    }
    await chrome.storage.session.set({ [LEADER_KEY]: tabId });
    return { ok: true };
  });

  const release = tabId => serialized(async () => {
    const id = (await chrome.storage.session.get(LEADER_KEY))[LEADER_KEY];
    if (id === tabId) await chrome.storage.session.remove(LEADER_KEY);
  });
  chrome.tabs.onRemoved.addListener(tabId => release(tabId));

  // ---- «BLS» button: this client becomes the one signed in, filled for and searched for ----
  // Another BLS account than the one signed in: sign out (BLS site data cleared) before going there.
  async function signOutBls() {
    const tabs = (await chrome.tabs.query({ url: BLS_TABS })).filter(t => t.id !== undefined && t.url);
    await Promise.all(tabs.map(t => chrome.tabs.sendMessage(t.id, { type: 'stop' }).catch(() => {})));
    const origins = [...new Set([BLS_HOME, ...tabs.map(t => t.url)].map(u => new URL(u).origin))];
    await chrome.browsingData.remove({ origins }, { cookies: true, localStorage: true, indexedDB: true, cacheStorage: true, serviceWorkers: true });
    return tabs;
  }

  async function openBls(clientId, windowId) {
    if (clientId) {
      const { [ACTIVE_KEY]: before } = await local.get(ACTIVE_KEY);
      const [was, now] = [await clientById(before), await clientById(clientId)];
      await local.set({ [ACTIVE_KEY]: clientId });
      if ((was?.gmail || '').trim().toLowerCase() !== (now?.gmail || '').trim().toLowerCase()) {
        for (const t of await signOutBls()) await chrome.tabs.reload(t.id);
      }
    }
    const { blsSettings: own = {} } = await local.get('blsSettings');
    if (own.enabled === false) await local.set({ blsSettings: { ...own, enabled: true } });
    const target = windowId ?? (await chrome.windows.getLastFocused({ windowTypes: ['normal'] }).catch(() => undefined))?.id;
    const [existing] = await chrome.tabs.query({ url: BLS_TABS });
    let tabId;
    if (existing?.id !== undefined) {
      tabId = existing.id;
      if (target !== undefined && existing.windowId !== target) await chrome.tabs.move(tabId, { windowId: target, index: -1 });
      await chrome.tabs.update(tabId, { active: true });
    } else {
      tabId = (await chrome.tabs.create({ url: BLS_HOME, active: true, ...(target !== undefined ? { windowId: target } : {}) })).id;
    }
    await chrome.storage.session.set({ [AUTOSTART_KEY]: { tabId, until: Date.now() + AUTOSTART_WINDOW_MS } });
    // An already loaded page won't ask: tell it (a page still loading asks by itself).
    await chrome.tabs.sendMessage(tabId, { type: 'autoStart' }).catch(() => {});
  }

  // ---- «Créer le compte BLS» (✎): this client's real Gmail and passport, filled on the BLS signup by the page script ----
  // blsSignup = { clientId, at } while it runs; the client's blsCompte.stage tells the panel where it stands.
  const SIGNUP_KEY = 'blsSignup';
  async function setClient(id, patch) {
    const { clients = [] } = await local.get('clients');
    const c = clients.find(x => x.id === id);
    if (!c) return null;
    Object.assign(c, typeof patch === 'function' ? patch(c) : patch);
    await local.set({ clients });
    return c;
  }

  async function startSignup(clientId, windowId) {
    const c = await clientById(clientId);
    if (!c) return { ok: false, error: 'Client introuvable' };
    await local.set({ [ACTIVE_KEY]: clientId, [SIGNUP_KEY]: { clientId, at: Date.now() } });
    await setClient(clientId, { blsCompte: { stage: 'form', at: Date.now() } });
    const tabs = await signOutBls(); // a new account: whoever was signed in leaves first
    const target = windowId ?? (await chrome.windows.getLastFocused({ windowTypes: ['normal'] }).catch(() => undefined))?.id;
    if (tabs[0]?.id !== undefined) {
      await chrome.tabs.update(tabs[0].id, { url: BLS_HOME, active: true });
    } else {
      await chrome.tabs.create({ url: BLS_HOME, active: true, ...(target !== undefined ? { windowId: target } : {}) });
    }
    addLog(`🆕 Création du compte BLS : ${fullName(c)}`, 'info');
    return { ok: true };
  }

  async function signupState(tabId) {
    const { [SIGNUP_KEY]: s, [ACTIVE_KEY]: active, clients = [] } = await local.get([SIGNUP_KEY, ACTIVE_KEY, 'clients']);
    if (!s || s.clientId !== active || Date.now() - s.at > 3 * 3600_000) return { on: false };
    const c = clients.find(x => x.id === s.clientId);
    return c ? { on: true, clientId: c.id, gmail: c.gmail || '', hasPassword: !!c.blsmdp, password: c.blsmdp || '', stage: c.blsCompte?.stage || 'form' } : { on: false };
  }

  async function signupStage(stage) {
    const { [SIGNUP_KEY]: s } = await local.get(SIGNUP_KEY);
    if (!s) return;
    const c = await setClient(s.clientId, { blsCompte: { stage, at: Date.now() } });
    if (c) addLog(`🆕 ${fullName(c)} : ${stage}`, 'info');
  }

  /**
   * The first-login password page: the new password is saved on the client BEFORE the site gets it (the old one
   * kept as blsmdpAncien), so it can't be lost; «failed» puts the old one back.
   */
  async function signupPassword({ password, failed }) {
    const { [SIGNUP_KEY]: s } = await local.get(SIGNUP_KEY);
    if (!s) return { ok: false };
    if (failed) {
      await setClient(s.clientId, c => (c.blsmdpAncien ? { blsmdp: c.blsmdpAncien, blsmdpAncien: undefined } : {}));
      return { ok: true };
    }
    if (password) {
      await setClient(s.clientId, c => ({ blsmdpAncien: c.blsmdp, blsmdp: password }));
      return { ok: true };
    }
    // Confirmed by the site: the account is ready, the signup ends here.
    const c = await setClient(s.clientId, { blsmdpAncien: undefined, blsCompte: { stage: 'created', at: Date.now() } });
    await local.remove(SIGNUP_KEY);
    if (c) {
      const text = `✅ Compte BLS créé : ${fullName(c)} (mot de passe enregistré dans ✎)`;
      addLog(text, 'ok');
      const st = await settings();
      if (st.telegram?.enabled) sendTelegram(st.telegram, text);
    }
    return { ok: true };
  }

  // ---- after a booking: the client is marked «Réservé»; with «File ⭐» the next ready client goes on ----
  const QUEUE_DELAY_MS = 5000;
  const fullName = c => `${c.prenom || ''} ${c.nom || ''}`.trim() || '?';
  const canLogin = c => !!c.gmail && !!(c.blsmdp || c.code);

  // A family is booked once, from its Principal's account (BLS asks the number of persons):
  // one queue entry per family, and the booking marks every member.
  const familyOf = (clients, c) => (c.famille ? clients.filter(x => x.famille === c.famille) : [c]);
  /** Who signs in for this client's family: the Principal, else the first member with a login. */
  const headOf = (clients, c) => {
    const fam = familyOf(clients, c);
    return fam.find(x => x.lien === 'principal' && canLogin(x)) || fam.find(canLogin);
  };

  /** Ready (⭐), not booked, one per family (its head), in the order they were starred. */
  const queueOf = (clients, bookedFamily) => {
    const seen = new Set(), out = [];
    for (const c of [...clients].sort((a, b) => (a.pretAt || 0) - (b.pretAt || 0))) {
      if (!c.pret || c.reserve || bookedFamily.includes(c)) continue;
      const head = headOf(clients, c);
      if (!head || seen.has(c.famille || c.id)) continue;
      seen.add(c.famille || c.id);
      out.push(head);
    }
    return out;
  };

  async function onBooked({ day, time, face }) {
    const { [ACTIVE_KEY]: id, clients = [] } = await local.get([ACTIVE_KEY, 'clients']);
    const c = clients.find(x => x.id === id);
    if (!c) return;
    const family = familyOf(clients, c);
    // face: the site went on to a face scan (selfie), shown purple in the list until the letter is downloaded.
    const reserve = { day, time, at: Date.now(), ...(face && { face: true }) };
    for (const m of family) { Object.assign(m, { reserve, pret: false }); delete m.lettre; }
    addLog(`✅ RDV ${day} ${time} · ${fullName(c)}${face ? ' · selfie' : ''}`, 'ok');
    await local.set({ clients }); // shared with the team by the sync
    // «🗓 RDV جديد» strip in the panel: 📲 WhatsApp to the staff (whatsapp.js)
    const { waPending = [] } = await local.get('waPending');
    await local.set({ waPending: [...waPending.filter(p => p.id !== c.id), { id: c.id, at: Date.now() }].slice(-15) });
    const s = await settings();
    if (!s.queue) return;
    // A face scan (or anything after it) needs this client's session: don't switch account under it.
    if (face) return notify(`⏸ الطابور واقف: كمل مسح الوجه ديال ${fullName(c)}، ومن بعد برك BLS على الكليان الجاي`);
    const who = family.length > 1 ? `عائلة ${c.nom || fullName(c)} (${family.length})` : fullName(c);
    const [next] = queueOf(clients, family);
    if (!next) return notify(`✅ ${who} تريزيرفات. الطابور سالا: ما بقا حتى كليان واجد ⭐`);
    const nextFam = familyOf(clients, next).length;
    notify(`✅ ${who} تريزيرفات. ➡️ الجاي: ${nextFam > 1 ? `عائلة ${next.nom || fullName(next)} (${nextFam})` : fullName(next)}`);
    setTimeout(() => openBls(next.id).catch(() => {}), QUEUE_DELAY_MS);
  }

  // ---- Passports: Telegram warning when one expires within 6 months, and when it has expired ----
  // Each warning goes once per client and passport (c.expAlert = "stage:expiry", synced to the team, so
  // other PCs don't send it again; a renewed passport starts over).
  const WARN_DAYS = 183;
  const frDate = iso => iso.split('-').reverse().join('/');

  function passportStage(c, now = Date.now()) {
    if (!c.expire) return '';
    const left = (new Date(c.expire + 'T12:00:00') - now) / 864e5;
    return left < 0 ? 'expired' : left < WARN_DAYS ? 'soon' : '';
  }

  /** Clients to warn about now, and the Telegram text; null when there is nothing new. */
  function passportReport(clients, now = Date.now()) {
    const due = clients.filter(c => { const st = passportStage(c, now); return st && c.expAlert !== `${st}:${c.expire}`; });
    if (!due.length) return null;
    const line = c => {
      const days = Math.ceil((new Date(c.expire + 'T12:00:00') - now) / 864e5);
      return `• ${fullName(c)}${c.passeport ? ` (${c.passeport})` : ''}: ${frDate(c.expire)}` + (days >= 0 ? ` — باقي ${days} يوم` : '');
    };
    const soon = due.filter(c => passportStage(c, now) === 'soon'), gone = due.filter(c => passportStage(c, now) === 'expired');
    const text = [
      soon.length && `⚠️ باسبورات غادي يساليو قبل 6 شهور:\n${soon.map(line).join('\n')}`,
      gone.length && `⛔ باسبورات ساليين:\n${gone.map(line).join('\n')}`,
    ].filter(Boolean).join('\n\n');
    return { due, text };
  }

  let checking = null;
  /** now = the «Vérifier» button: no random wait, and warn again even about passports already sent. */
  function checkPassports(now = false) {
    checking ||= checkPassportsOnce(now).finally(() => { checking = null; });
    return checking;
  }

  // Needs only the bot token and chat id: the «Telegram» switch is about the appointment alerts.
  async function checkPassportsOnce(now) {
    const s = await settings();
    if (!s.telegram?.botToken || !s.telegram.chatId) return { ok: false, error: 'Telegram pas configuré : token et chat id (Paramètres BLS)' };
    // Several PCs run this: a random wait lets the first one's marks arrive by sync before the others look.
    if (!now) await new Promise(r => setTimeout(r, Math.random() * 20_000));
    const { clients = [] } = await local.get('clients');
    const report = passportReport(now ? clients.map(c => ({ ...c, expAlert: undefined })) : clients);
    if (!report) return { ok: true, sent: 0 };
    const r = await sendTelegram(s.telegram, report.text);
    if (!r.ok) return { ok: false, error: 'Telegram : ' + r.error };
    const { clients: fresh = [] } = await local.get('clients');
    for (const c of fresh) {
      if (report.due.some(d => d.id === c.id)) c.expAlert = `${passportStage(c)}:${c.expire}`;
    }
    await local.set({ clients: fresh });
    return { ok: true, sent: report.due.length };
  }

  chrome.alarms.create('aa-passports', { delayInMinutes: 1, periodInMinutes: 6 * 60 });
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'aa-passports') checkPassports(); });
  // Telegram just set up (or changed): check now rather than in up to 6 hours.
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && ch.teamSettings && ch.teamSettings.newValue?.telegram?.chatId) checkPassports();
  });
  globalThis.AAPassports = { passportStage, passportReport };

  // ---- New clients: one Telegram per batch, from the PC that created them (c.ajout, rules.js) ----
  const NEW_MAX_AGE_MS = 24 * 3600_000; // older ones (Telegram set up later) are just marked sent
  const NEW_MAX_LINES = 25;
  let newTimer;

  async function sendNewClients() {
    const s = await settings();
    if (!s.telegram?.botToken || !s.telegram.chatId) return;
    const { clients = [], deviceId } = await local.get(['clients', 'deviceId']);
    const mine = clients.filter(c => c.ajout && !c.ajout.sent && c.ajout.pc === deviceId);
    if (!mine.length) return;
    const fresh = mine.filter(c => Date.now() - (c.ajout.at || 0) < NEW_MAX_AGE_MS);
    if (fresh.length) {
      const line = c => `• ${fullName(c).toUpperCase()}${c.dossier ? ` · 📁 ${c.dossier}` : ''}${c.passeport ? ` · ${c.passeport}` : ''}`;
      const by = [...new Set(fresh.map(c => c.ajout.by).filter(Boolean))].join(', ');
      const text = `➕ ${fresh.length > 1 ? `${fresh.length} كليان جداد` : 'كليان جديد'}${by ? ` — زادو: ${by}` : ''}\n`
        + fresh.slice(0, NEW_MAX_LINES).map(line).join('\n') + (fresh.length > NEW_MAX_LINES ? `\n… و ${fresh.length - NEW_MAX_LINES} آخرين` : '');
      const r = await sendTelegram(s.telegram, text);
      if (!r.ok) return; // stays pending: tried again on the next change or check
    }
    const { clients: now = [] } = await local.get('clients');
    for (const c of now) if (mine.some(m => m.id === c.id)) c.ajout = { ...c.ajout, sent: true };
    await local.set({ clients: now });
  }

  // A few seconds after the last change, so a CSV import or a family goes out as one message.
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || !ch.clients) return;
    const before = new Set((ch.clients.oldValue || []).map(c => c.id));
    if (!(ch.clients.newValue || []).some(c => !before.has(c.id) && c.ajout && !c.ajout.sent)) return;
    clearTimeout(newTimer);
    newTimer = setTimeout(() => sendNewClients().catch(() => {}), 4000);
  });
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'aa-passports') sendNewClients().catch(() => {}); });

  async function autoStartPending(tabId) {
    const v = (await chrome.storage.session.get(AUTOSTART_KEY))[AUTOSTART_KEY];
    if (v?.tabId === tabId && (v.until ?? 0) > Date.now()) return { ok: true };
    // Watching was on a moment ago (reload, error retry, Chrome restart) for this same client: pick it up again,
    // unless another tab is already watching.
    const { [RESUME_KEY]: r, [ACTIVE_KEY]: active } = await local.get([RESUME_KEY, ACTIVE_KEY]);
    if (!r || Date.now() - r.at > RESUME_WINDOW_MS || r.client !== (active ?? null)) return { ok: false };
    return serialized(async () => ({ ok: (await liveLeader()) === undefined, resumed: true }));
  }

  // ---- Resume: the page script beats while watching; a deliberate end (Stop, a find, end of peak) clears it ----
  const RESUME_KEY = 'blsResume';
  const RESUME_WINDOW_MS = 15 * 60_000;
  let resumeWrittenAt = 0;
  async function setResume(on) {
    if (!on) { resumeWrittenAt = 0; return local.remove(RESUME_KEY); }
    if (Date.now() - resumeWrittenAt < 30_000) return;
    resumeWrittenAt = Date.now();
    const { [ACTIVE_KEY]: active } = await local.get(ACTIVE_KEY);
    await local.set({ [RESUME_KEY]: { at: Date.now(), client: active ?? null } });
  }

  // ---- Activity log kept for the diagnostic export (warnings, errors, bookings, letters) ----
  const LOG_KEY = 'blsLog';
  let logOp = Promise.resolve();
  function addLog(text, tone = 'info') {
    logOp = logOp.then(async () => {
      const list = (await local.get(LOG_KEY))[LOG_KEY] || [];
      const last = list[list.length - 1];
      if (last && last.text === text && Date.now() - last.at < 10_000) return;
      await local.set({ [LOG_KEY]: [...list, { at: Date.now(), text: String(text).slice(0, 300), tone }].slice(-200) });
    }).catch(() => {});
  }

  // ---- BLS HTTP errors (429 / 5xx) per tab, with Retry-After, for the page's retry dialog ----
  const HTTP_PREFIX = 'blsHttp:';
  function retryAfterSec(headers = []) {
    const v = headers.find(h => h.name.toLowerCase() === 'retry-after')?.value?.trim();
    if (!v) return undefined;
    const sec = /^\d+$/.test(v) ? +v : Math.round((Date.parse(v) - Date.now()) / 1000);
    return Number.isFinite(sec) && sec > 0 ? Math.min(sec, 3600) : undefined;
  }
  chrome.webRequest.onCompleted.addListener(d => {
    if (d.tabId < 0) return;
    const key = HTTP_PREFIX + d.tabId, s = d.statusCode;
    if (s !== 429 && !(s >= 500 && s <= 504)) {
      if (d.type === 'main_frame' && s < 400) chrome.storage.session.remove(key);
      return;
    }
    const t = { status: s, retryAfterSec: retryAfterSec(d.responseHeaders), at: Date.now(), mainFrame: d.type === 'main_frame' };
    chrome.storage.session.set({ [key]: t });
    let where = d.url;
    try { where = new URL(d.url).host + new URL(d.url).pathname; } catch { /* keep the raw url */ }
    addLog(`HTTP ${s}${t.retryAfterSec ? ` (Retry-After ${t.retryAfterSec}s)` : ''} · ${where.slice(0, 120)}`, 'err');
  }, { urls: [BLS_TABS], types: ['main_frame', 'xmlhttprequest'] }, ['responseHeaders']);
  chrome.tabs.onRemoved.addListener(tabId => chrome.storage.session.remove(HTTP_PREFIX + tabId));
  const httpTroubleOf = async tabId => (await chrome.storage.session.get(HTTP_PREFIX + tabId))[HTTP_PREFIX + tabId] ?? null;

  // ---- A PDF downloaded from BLS (the appointment letter): marked on the active client and its family ----
  const BLS_SOURCE_RE = /^(blob:)?https:\/\/[^/]*\.blsinternational\.com\//;
  chrome.downloads.onChanged.addListener(async d => {
    if (d.state?.current !== 'complete') return;
    const [it] = await chrome.downloads.search({ id: d.id });
    if (!it || ![it.url, it.finalUrl, it.referrer].some(u => u && BLS_SOURCE_RE.test(u))) return;
    if (!/pdf/i.test(it.mime || '') && !/\.pdf$/i.test(it.filename || '')) return;
    let { [ACTIVE_KEY]: id, clients = [], deviceId } = await local.get([ACTIVE_KEY, 'clients', 'deviceId']);
    if (!deviceId) await local.set({ deviceId: (deviceId = crypto.randomUUID()) }); // same id rules.js would make
    const c = clients.find(x => x.id === id);
    const name = (it.filename || '').split(/[\\/]/).pop() || 'document.pdf';
    if (!c) return addLog(`📄 PDF BLS تحمّل (${name}) بلا كليان نشيط`, 'warn');
    const lettre = { at: Date.now(), name, pc: deviceId, dl: it.id };
    const family = familyOf(clients, c);
    for (const m of family) m.lettre = lettre;
    await local.set({ clients });
    const who = family.length > 1 ? `عائلة ${c.nom || fullName(c)}` : fullName(c);
    const text = `📄 Lettre de RDV ديال ${who} تحمّلات (${name})`;
    addLog(text, 'ok');
    chrome.notifications.create(`${NOTIF_PREFIX}:${Date.now()}`, { type: 'basic', iconUrl: 'bls/icon.png', title: 'Autofill BLS', message: text });
    const s = await settings();
    if (s.telegram?.enabled) sendTelegram(s.telegram, text);
  });

  // ---- Photos for the BLS photo step: the «🖼 Photo» file (✎ → Fichiers) of the active client and its family ----
  const blobToDataUrl = async blob => {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return `data:${blob.type || 'image/jpeg'};base64,${btoa(bin)}`;
  };
  async function photosForPage() {
    const { [ACTIVE_KEY]: id, clients = [] } = await local.get([ACTIVE_KEY, 'clients']);
    const c = clients.find(x => x.id === id);
    if (!c) return { ok: false, error: 'Aucun client actif : cliquez «BLS» sur un client dans le panneau' };
    const a = await globalThis.AAFilesAuth?.();
    if (!a?.token) return { ok: false, error: 'Connectez-vous (☁) dans le panneau pour voir les photos' };
    const api = (path, init = {}) => fetch(`${a.url}/storage/v1/${path}`,
      { ...init, headers: { apikey: a.key, Authorization: 'Bearer ' + a.token, ...init.headers } });
    const family = familyOf(clients, c).sort((x, y) => (x.id === c.id ? -1 : y.id === c.id ? 1 : 0));
    const people = await Promise.all(family.map(async m => {
      const who = { id: m.id, name: fullName(m) };
      try {
        const r = await api('object/list/fichiers', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prefix: `${m.id}/photo`, limit: 5 }),
        });
        const f = r.ok ? (await r.json()).find(x => x.id) : null;
        if (!f) return { ...who, missing: true };
        const img = await api(`object/authenticated/fichiers/${m.id}/photo/${encodeURIComponent(f.name)}`);
        if (!img.ok) return { ...who, error: 'erreur ' + img.status };
        return { ...who, file: { name: f.name, dataUrl: await blobToDataUrl(await img.blob()) } };
      } catch (e) { return { ...who, error: e.message }; }
    }));
    return { ok: true, people };
  }

  // ---- Diagnostic export (⚙ Paramètres BLS): what to send when something goes wrong; no tokens ----
  async function diagExport() {
    const keys = ['blsSettings', 'teamSettings', ACTIVE_KEY, RESUME_KEY, LOG_KEY, HISTORY_KEY, 'clients', 'deviceId'];
    const st = await local.get(keys);
    const hide = tg => tg && { ...tg, botToken: tg.botToken ? '(rempli)' : '', chatId: tg.chatId ? '(rempli)' : '' };
    const strip = o => o && { ...o, ...(o.telegram && { telegram: hide(o.telegram) }) };
    const active = (st.clients || []).find(c => c.id === st[ACTIVE_KEY]);
    const ses = await chrome.storage.session.get(null);
    const ask = (id, msg) => chrome.tabs.sendMessage(id, msg).catch(e => ({ error: e.message }));
    const pages = await Promise.all((await chrome.tabs.query({ url: BLS_TABS })).map(async t => {
      const [d, state] = await Promise.all([ask(t.id, { type: 'diag' }), ask(t.id, { type: 'getState' })]);
      let diag = d?.diag ?? d;
      try { diag = JSON.parse(diag); } catch { /* keep as is */ }
      return { tabId: t.id, path: t.url ? new URL(t.url).pathname : '', active: t.active, leader: ses[LEADER_KEY] === t.id, http: ses[HTTP_PREFIX + t.id] ?? null, state, diag };
    }));
    return {
      app: 'Autofill BLS', version: chrome.runtime.getManifest().version, at: new Date().toISOString(),
      userAgent: navigator.userAgent, pc: st.deviceId,
      activeClient: active ? { id: active.id, gmail: !!active.gmail, login: canLogin(active), famille: !!active.famille, pret: !!active.pret, reserve: active.reserve ?? null, lettre: active.lettre ?? null } : null,
      settings: strip(st.blsSettings), team: strip(st.teamSettings),
      resume: st[RESUME_KEY] ?? null, autoStart: ses[AUTOSTART_KEY] ?? null,
      log: st[LOG_KEY] || [], history: (st[HISTORY_KEY] || []).slice(-60), pages,
    };
  }

  let historyWrite = Promise.resolve();
  const recordSeen = (month, dates) => {
    historyWrite = historyWrite.then(async () => {
      const list = (await local.get(HISTORY_KEY))[HISTORY_KEY] || [];
      await local.set({ [HISTORY_KEY]: [...list, { at: Date.now(), month, dates }].slice(-300) });
    }).catch(() => {});
  };

  // BLS pages open during an install/update keep the old page script, cut off: reload them.
  chrome.runtime.onInstalled.addListener(() => {
    chrome.tabs.query({ url: BLS_TABS }).then(tabs => tabs.forEach(t => t.id !== undefined && chrome.tabs.reload(t.id)));
  });

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    const tabId = sender.tab?.id;
    const answer = p => { p.then(reply, e => reply({ ok: false, error: e.message })); return true; };
    switch (msg?.type) {
      case 'bls-open': return answer(openBls(msg.id, msg.windowId).then(() => ({ ok: true })));
      case 'openBls': openBls(null, sender.tab?.windowId); return false;
      case 'claim': return tabId === undefined ? false : answer(claim(tabId, msg.takeover));
      case 'release': if (tabId !== undefined) release(tabId); return false;
      case 'autoStartPending': return tabId === undefined ? false : answer(autoStartPending(tabId));
      case 'autoStartDone': chrome.storage.session.remove(AUTOSTART_KEY); return false;
      case 'notify': notify(msg.text, tabId); return false;
      case 'beep': beep(); return false;
      case 'seen': recordSeen(msg.month, msg.dates); return false;
      case 'booked': onBooked(msg); return false;
      case 'checkPassports': return answer(checkPassports(true));
      case 'resume': setResume(!!msg.on).catch(() => {}); return false;
      case 'log': addLog(msg.text, msg.tone); return false;
      case 'httpTrouble': return tabId === undefined ? false : answer(httpTroubleOf(tabId));
      case 'diagExport': return answer(diagExport());
      case 'blsPhotos': return answer(photosForPage());
      case 'bls-signup': return answer(startSignup(msg.id, msg.windowId));
      case 'signupState': return answer(signupState(tabId));
      case 'signupStage': signupStage(msg.stage).catch(() => {}); return false;
      case 'signupPassword': return answer(signupPassword(msg));
      case 'state':
        if (tabId !== undefined) {
          chrome.action.setBadgeBackgroundColor({ tabId, color: '#0a8550' });
          chrome.action.setBadgeText({ tabId, text: msg.running ? 'ON' : '' });
        }
        return false;
      case 'telegramTest': return answer(settings().then(s => sendTelegram(s.telegram, '✅ تجربة: التنبيهات واصلة لهاد الشات')));
      case 'telegramChatId': return answer(settings().then(s => findChatId(msg.token ?? s.telegram?.botToken)));
      case 'openOptions': chrome.tabs.create({ url: chrome.runtime.getURL('bls/settings.html') }); return false;
      default: return false;
    }
  });
})();
