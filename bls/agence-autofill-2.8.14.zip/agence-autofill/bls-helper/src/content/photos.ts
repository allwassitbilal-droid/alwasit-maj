// Agence Autofill: on a BLS page with a photo upload (an image file input), a small gallery shows the
// «🖼 Photo» saved in the client's files (✎ → Fichiers), for the active client and its family. A click puts
// that photo into the site's own file input, as if chosen by hand: BLS then crops and checks it as usual.
// Nothing is sent by itself: the user checks the preview and clicks the site's Next / Continue.
import { askBackground, sendToBackground, type PhotoPerson, type PhotosReply } from "../shared/messages";
import { contextAlive } from "./util";

const SCAN_MS = 1500;

/** The page's photo input: a file input that takes images (or anything), the visible one first. */
export function photoInput(): HTMLInputElement | null {
  const inputs = [...document.querySelectorAll<HTMLInputElement>('input[type="file"]')].filter((i) => {
    const acc = (i.accept || "").toLowerCase();
    return !i.disabled && (!acc || /image|\.jpe?g|\.png|\.webp/.test(acc));
  });
  return inputs.find((i) => i.offsetParent !== null) ?? inputs[0] ?? null;
}

function toFile(f: NonNullable<PhotoPerson["file"]>): File {
  const [head, b64 = ""] = f.dataUrl.split(",");
  const type = /data:([^;]+)/.exec(head ?? "")?.[1] ?? "image/jpeg";
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new File([bytes], f.name, { type, lastModified: Date.now() });
}

/** Puts the photo into the input like a manual pick: files set, then input + change events for the site. */
export function putPhoto(input: HTMLInputElement, f: NonNullable<PhotoPerson["file"]>): void {
  const dt = new DataTransfer();
  dt.items.add(toFile(f));
  input.files = dt.files;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}

const CSS = `
:host { all: initial; }
.box { position: fixed; right: 18px; bottom: 18px; z-index: 2147483645; width: 250px; direction: rtl; text-align: right;
  font: 12.5px/1.4 system-ui, "Segoe UI", Tahoma, sans-serif; color: #e6edf3; background: #0f1d2b;
  border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,.4); border-top: 3px solid #4fc3f7; overflow: hidden; }
.head { display: flex; align-items: center; gap: 6px; padding: 8px 10px; font-weight: 700; }
.head span { flex: 1; }
.x { all: unset; cursor: pointer; padding: 0 6px; color: #8fa3b5; font-size: 15px; }
.list { display: grid; gap: 6px; padding: 0 10px 10px; max-height: 50vh; overflow: auto; }
.p { display: flex; align-items: center; gap: 8px; padding: 6px; border-radius: 9px; background: #16283a; }
.p img { width: 46px; height: 58px; object-fit: cover; border-radius: 5px; background: #fff; flex: none; }
.p .t { flex: 1; min-width: 0; }
.p b { display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.p small { color: #8fa3b5; }
.p button { all: unset; cursor: pointer; padding: 5px 9px; border-radius: 999px; background: #1f8f5a; color: #fff; font-weight: 700; white-space: nowrap; }
.p button:hover { filter: brightness(1.12); }
.p.done button { background: #2e5784; }
.msg { padding: 0 10px 10px; color: #8fa3b5; }
.msg.err { color: #f0a24a; }
.hint { padding: 0 10px 10px; color: #8fa3b5; font-size: 11.5px; }
`;

/** Watches the page for a photo input and shows the gallery while there is one. */
export function startPhotoHelper(note: (text: string) => void): void {
  let host: HTMLElement | null = null;
  /** Closed with ✕: stays closed until the photo step is gone. */
  let closedFor: HTMLInputElement | null = null;

  const close = () => {
    host?.remove();
    host = null;
  };

  async function show(input: HTMLInputElement): Promise<void> {
    host = document.createElement("div");
    const root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `<style>${CSS}</style><div class="box"><div class="head"><span>🖼 صورة الكليان</span><button class="x" title="Fermer">✕</button></div>
      <div class="msg">كنجيب التصاور...</div><div class="list"></div><div class="hint" hidden>شوف الصورة فالموقع، ومن بعد ضغط Next بيدك.</div></div>`;
    document.documentElement.append(host);
    (root.querySelector(".x") as HTMLElement).onclick = () => {
      closedFor = input;
      close();
    };
    const msg = root.querySelector(".msg") as HTMLElement;
    const list = root.querySelector(".list") as HTMLElement;
    const r = await askBackground<PhotosReply>({ type: "blsPhotos" });
    if (!r?.ok || !r.people) {
      msg.className = "msg err";
      msg.textContent = r?.error ?? "ما قدرتش نجيب التصاور";
      return;
    }
    msg.remove();
    (root.querySelector(".hint") as HTMLElement).hidden = false;
    for (const p of r.people) {
      const row = document.createElement("div");
      row.className = "p";
      const t = document.createElement("div");
      t.className = "t";
      const b = document.createElement("b");
      b.textContent = p.name;
      const s = document.createElement("small");
      t.append(b, s);
      if (p.file) {
        const img = document.createElement("img");
        img.src = p.file.dataUrl;
        s.textContent = p.file.name;
        const btn = document.createElement("button");
        btn.textContent = "حط الصورة";
        btn.onclick = () => {
          const target = photoInput();
          if (!target) return void (s.textContent = "ما بقاتش خانة الصورة فالصفحة");
          putPhoto(target, p.file!);
          row.classList.add("done");
          btn.textContent = "✓ تحطات";
          note(`🖼 حطيت الصورة ديال ${p.name}: شوفها فالموقع وضغط Next`);
          sendToBackground({ type: "log", text: `🖼 photo ${p.name}`, tone: "info" });
        };
        row.append(img, t, btn);
      } else {
        s.textContent = p.missing ? "ما كايناش: زيدها ف ✎ ← 🖼 Photo" : `خطأ: ${p.error ?? "?"}`;
        row.append(t);
      }
      list.append(row);
    }
  }

  setInterval(() => {
    if (!contextAlive()) return;
    const input = photoInput();
    if (!input) {
      if (host) close();
      closedFor = null;
      return;
    }
    // The site may re-render its input after a pick: the gallery stays (✓ kept) as long as there is one.
    if (!host && !closedFor) void show(input);
  }, SCAN_MS);
}
