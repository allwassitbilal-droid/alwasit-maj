// Files of a client (form PDF, photo, passport). They live online only (Supabase Storage,
// private bucket "fichiers-tls"), never in the extension's local storage. Path: <client id>/<slot>/<name>.
(() => {
  const BUCKET = 'fichiers-tls';
  const SLOTS = [['formulaire', '📄 Formulaire'], ['photo', '🖼 Photo'], ['passeport', '🛂 Passeport']];

  // The background worker holds the login; it gives us a fresh token for each call.
  async function api(path, opts = {}) {
    const a = await chrome.runtime.sendMessage({ type: 'files-auth' });
    if (!a?.token) throw new Error('Connectez-vous (☁) pour voir les fichiers');
    const r = await fetch(`${a.url}/storage/v1/${path}`, {
      ...opts, headers: { apikey: a.key, Authorization: 'Bearer ' + a.token, ...opts.headers },
    });
    if (!r.ok) throw new Error('Fichiers : ' + ((await r.json().catch(() => ({}))).message || 'erreur ' + r.status));
    return { r, a };
  }
  const json = (body, method = 'POST') => ({ method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

  async function list(id, slot) {
    const { r } = await api(`object/list/${BUCKET}`, json({ prefix: `${id}/${slot}`, limit: 20 }));
    return (await r.json()).filter(f => f.id).map(f => ({ name: f.name, path: `${id}/${slot}/${f.name}` }));
  }

  async function remove(paths) {
    if (paths.length) await api(`object/${BUCKET}`, json({ prefixes: paths }, 'DELETE'));
  }

  // Phone photos are heavy: resize to 2000 px JPEG so thousands fit in the free 1 GB.
  async function shrink(file) {
    if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < 400 * 1024) return file;
    const img = await createImageBitmap(file);
    const k = Math.min(1, 2000 / Math.max(img.width, img.height));
    const c = new OffscreenCanvas(Math.round(img.width * k), Math.round(img.height * k));
    const g = c.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, c.width, c.height);
    g.drawImage(img, 0, 0, c.width, c.height);
    const out = await c.convertToBlob({ type: 'image/jpeg', quality: 0.85 });
    return out.size < file.size ? out : file;
  }

  const safeName = (name, type) => {
    let n = (name || 'fichier').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w.-]+/g, '_').slice(-80);
    if (type === 'image/jpeg' && !/\.jpe?g$/i.test(n)) n = n.replace(/\.[^.]*$/, '') + '.jpg';
    return n;
  };

  // One file per slot: the new one replaces the old one.
  async function upload(id, slot, file) {
    const blob = await shrink(file);
    if (blob.size > 10 * 1024 * 1024) throw new Error('Fichier trop lourd (10 Mo max)');
    const name = safeName(file.name, blob.type);
    const old = await list(id, slot);
    await api(`object/${BUCKET}/${id}/${slot}/${name}`, {
      method: 'POST', headers: { 'Content-Type': blob.type || 'application/octet-stream', 'x-upsert': 'true' }, body: blob,
    });
    await remove(old.map(f => f.path).filter(p => p !== `${id}/${slot}/${name}`));
  }

  // Opens the file in a new tab through a link valid 10 minutes.
  async function open(path) {
    const { r, a } = await api(`object/sign/${BUCKET}/${path}`, json({ expiresIn: 600 }));
    const { signedURL } = await r.json();
    chrome.tabs.create({ url: a.url + '/storage/v1' + signedURL });
  }

  // The file itself (for the card's photo thumbnail), through the same 10-minute link.
  async function fetchBlob(path) {
    const { r, a } = await api(`object/sign/${BUCKET}/${path}`, json({ expiresIn: 600 }));
    const { signedURL } = await r.json();
    const f = await fetch(a.url + '/storage/v1' + signedURL);
    if (!f.ok) throw new Error('Fichier introuvable');
    return f.blob();
  }

  async function removeAll(id) {
    const lists = await Promise.all(SLOTS.map(([s]) => list(id, s)));
    await remove(lists.flat().map(f => f.path));
  }

  globalThis.AAFiles = { SLOTS, list, upload, remove, open, removeAll, fetchBlob };
})();
