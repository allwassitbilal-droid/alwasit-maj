// Typed message contracts between the extension's contexts.
import type { Phase } from "./schedule";

/** popup -> content script; "yield" comes from the background when another tab takes over watching. */
export type ContentRequest =
  | { type: "getState" }
  | { type: "start" }
  | { type: "stop" }
  | { type: "yield" }
  | { type: "diag" }
  | { type: "fillForm" }
  /** «Open BLS» focused an already open tab: start watching once the date page is there. */
  | { type: "autoStart" };

/** Result of filling the applicant form: Arabic field labels. */
export interface FillReport {
  filled: string[];
  /** Recognised fields the user must fill or check by hand. */
  check: string[];
  /** Fields left orange because the saved profile has no value for them. */
  missing?: string[];
  /** Fields the user had already typed into, left as they were. */
  kept?: string[];
}

export type Tone = "info" | "ok" | "warn" | "err";

export interface LogEntry {
  at: number;
  text: string;
  tone: Tone;
}

export interface WatchState {
  running: boolean;
  text: string;
  tone: Tone;
  onCalendar: boolean;
  sched: Phase;
  intervalSec: number;
  checks: number;
  /** Epoch ms of the next scheduled check while napping, else null. */
  nextCheckAt: number | null;
  /** Seconds the last wait overran its schedule because Chrome throttled the tab; 0 when on time. */
  lagSec: number;
  /** Newest first. */
  log: LogEntry[];
}

export interface DiagResponse {
  diag: string;
}

/** content script / options page -> background */
export type BackgroundRequest =
  | { type: "notify"; text: string }
  | { type: "beep" }
  | { type: "state"; running: boolean }
  /** Become the one watching tab; with takeover the current leader is told to yield. Replies LeaderReply. */
  | { type: "claim"; takeover: boolean }
  | { type: "release" }
  /** Enabled dates appeared (or changed) in a month; appended to the history. */
  | { type: "seen"; month: string; dates: string[] }
  | { type: "telegramTest" }
  | { type: "telegramChatId" }
  /** From the on-page toolbar, which can't open the options page itself. */
  | { type: "openOptions" }
  /** Popup's «Open BLS»: focus the BLS tab (or open one in its own window) and start watching there. */
  | { type: "openBls"; windowId?: number }
  /** A freshly loaded BLS page asks whether «Open BLS» is waiting on it; replies LeaderReply. */
  | { type: "autoStartPending" }
  | { type: "autoStartDone" }
  /** Agence Autofill: a booking went through for the active client (day YYYY-MM-DD, time as shown). */
  | { type: "booked"; day: string; time: string; face: boolean }
  /** Agence Autofill: watching is on (heartbeat, so a reload or a Chrome restart picks it up again) or ended on purpose. */
  | { type: "resume"; on: boolean }
  /** Agence Autofill: a warn/err line of the activity log, kept for the diagnostic export. */
  | { type: "log"; text: string; tone: Tone }
  /** Agence Autofill: this tab's last BLS HTTP error (429 / 5xx) seen by the background; replies HttpTrouble | null. */
  | { type: "httpTrouble" }
  /** Agence Autofill: the «🖼 Photo» of the active client and its family, for the photo step; replies PhotosReply. */
  | { type: "blsPhotos" }
  /** Agence Autofill «Créer le compte BLS»: is a signup running for the active client? Replies SignupState. */
  | { type: "signupState" }
  | { type: "signupStage"; stage: "form" | "otp" | "password" | "created" }
  /** password: save it on the client before submitting; failed: put the old one back; neither: confirmed. */
  | { type: "signupPassword"; password?: string; failed?: boolean };

export interface SignupState {
  on: boolean;
  clientId?: string;
  gmail?: string;
  hasPassword?: boolean;
  /** The client's «Mot de passe BLS» (the one received by email, before the first-login change). */
  password?: string;
  stage?: "form" | "otp" | "password" | "created";
}

export interface PhotoPerson {
  id: string;
  name: string;
  file?: { name: string; dataUrl: string };
  missing?: boolean;
  error?: string;
}

export interface PhotosReply {
  ok: boolean;
  error?: string;
  people?: PhotoPerson[];
}

/** A BLS response refused or failed by the server, with its Retry-After in seconds when it gave one. */
export interface HttpTrouble {
  status: number;
  retryAfterSec?: number | undefined;
  at: number;
  mainFrame: boolean;
}

/** Reply to telegramTest / telegramChatId. */
export interface TelegramReply {
  ok: boolean;
  error?: string;
  chatId?: string;
  name?: string;
}

/** Reply to claim. */
export interface LeaderReply {
  ok: boolean;
  /** autoStartPending: true when it is watching interrupted by a reload / restart, not «Open BLS». */
  resumed?: boolean;
}

/** background -> offscreen document */
export type OffscreenRequest = { type: "offscreen-beep" };

/** Fire-and-forget; swallows "receiving end does not exist" and invalidated-context errors. */
export function sendToBackground(msg: BackgroundRequest): void {
  try {
    chrome.runtime.sendMessage(msg).catch(() => {});
  } catch {
    // extension reloaded: this content script is orphaned
  }
}

/** Request/reply to the background; undefined when it can't be reached. */
export async function askBackground<T>(msg: BackgroundRequest): Promise<T | undefined> {
  try {
    return (await chrome.runtime.sendMessage(msg)) as T;
  } catch {
    return undefined;
  }
}
