// «📄 Importer la lettre RDV» (✎): reads a BLS appointment letter (PDF, scanned PDF or photo) and gives back
// the appointment date and time, the reference (Group URN), the centre and the applicant names.
// Text PDFs are read with pdf.js; scans and photos go through the OCR already bundled (lib/tesseract).
(() => {
  const url = p => chrome.runtime.getURL(p);
  let pdfjs, ocr;

  async function loadPdf() {
    if (!pdfjs) {
      pdfjs = await import(url('lib/pdf.min.mjs'));
      pdfjs.GlobalWorkerOptions.workerSrc = url('lib/pdf.worker.min.mjs');
    }
    return pdfjs;
  }

  function loadScript(src) {
    return new Promise((ok, ko) => {
      const s = document.createElement('script');
      s.src = src; s.onload = ok; s.onerror = () => ko(new Error('OCR indisponible'));
      document.head.append(s);
    });
  }

  function ocrWorker() {
    ocr ||= (async () => {
      if (!globalThis.Tesseract) await loadScript(url('lib/tesseract.min.js'));
      return Tesseract.createWorker('eng', 1, {
        workerPath: url('lib/worker.min.js'), corePath: url('lib/tesseract-core-simd-lstm.wasm.js'),
        langPath: url('lib'), workerBlobURL: false, cacheMethod: 'none',
      });
    })();
    ocr.catch(() => { ocr = null; });
    return ocr;
  }

  /** Page 1 of the PDF: its text, and a canvas of it for the OCR when it has no text (scan). */
  async function pdfPage(file) {
    const lib = await loadPdf();
    const doc = await lib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false, verbosity: 0 }).promise;
    const page = await doc.getPage(1);
    const tc = await page.getTextContent();
    const text = tc.items.map(i => i.str + (i.hasEOL ? '\n' : ' ')).join('');
    return { text, page };
  }

  async function render(page) {
    const vp = page.getViewport({ scale: 2.5 });
    const c = document.createElement('canvas');
    c.width = vp.width; c.height = vp.height;
    const g = c.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: g, viewport: vp }).promise;
    return c;
  }

  async function textOf(file) {
    const isPdf = /pdf/i.test(file.type) || /\.pdf$/i.test(file.name);
    let src = file;
    if (isPdf) {
      const { text, page } = await pdfPage(file);
      if (parse(text).day) return text;
      src = await render(page); // scanned (CamScanner…): read the picture
    }
    const w = await ocrWorker();
    return (await w.recognize(src)).data.text;
  }

  const CITIES = ['Tetuan', 'Tetouan', 'Rabat', 'Casablanca', 'Tanger', 'Tangier', 'Nador', 'Agadir', 'Fes', 'Fez', 'Marrakech', 'Oujda', 'Al Hoceima'];

  /** {day:'YYYY-MM-DD', time:'HH:MM', ref, centre, text} — day is '' when no appointment date was found. */
  function parse(raw) {
    const text = String(raw || '').replace(/[–—]/g, '-').replace(/\s+/g, ' ');
    const t = text.replace(/(\d)\s*[.,]\s*(\d{2})\b/g, '$1:$2'); // OCR: 08.50 → 08:50
    // The appointment is a time range (08:50-09:10); the payment date has a single time.
    let m = t.match(/(20\d\d)\s*-\s*(\d\d)\s*-\s*(\d\d)\s+(\d\d?):(\d\d)\s*-\s*\d\d?:\d\d/);
    if (!m) {
      // Fallback: the latest date in the letter (the appointment comes after the payment)
      const all = [...t.matchAll(/(20\d\d)\s*-\s*(\d\d)\s*-\s*(\d\d)\s+(\d\d?):(\d\d)/g)];
      m = all.sort((a, b) => (a.slice(1).join('') < b.slice(1).join('') ? 1 : -1))[0];
    }
    const day = m ? `${m[1]}-${m[2]}-${m[3]}` : '';
    const time = m ? `${m[4].padStart(2, '0')}:${m[5]}` : '';
    const ref = (t.match(/\b([A-Z]{3})\s*-\s*(\d{6})\s*-\s*(\d{2})\b/) || []).slice(1).join('-');
    const addr = (t.match(/following address\s*:?\s*([^,]{2,30}),/i) || [])[1]?.trim() || '';
    const centre = addr || CITIES.find(c => new RegExp(`\\b${c}\\b`, 'i').test(t)) || '';
    return { day, time, ref, centre: centre.replace(/^Tetuan$/i, 'Tétouan'), text };
  }

  /** Does the letter name this client (nom or prénom)? null when we can't tell (no name on the client). */
  function namesClient(text, c) {
    const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    const words = [c.nom, c.prenom].flatMap(s => norm(s).split(/[\s-]+/)).filter(w => w.length > 2);
    if (!words.length) return null;
    const t = norm(text);
    return words.some(w => t.includes(w));
  }

  async function read(file) { return parse(await textOf(file)); }

  globalThis.AALettre = { read, parse, namesClient };
})();
