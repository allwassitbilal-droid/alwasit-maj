export const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

/** Polls fn until it returns a truthy value or the timeout elapses. */
export async function waitFor<T>(fn: () => T | null | undefined | false, timeoutMs = 8000, stepMs = 30): Promise<T | null> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const r = fn();
    if (r) return r;
    await sleep(stepMs);
  }
  return null;
}

/** Key-value store that never throws (storage can be blocked). */
export interface Store {
  get(key: string): string | null;
  set(key: string, value: string): void;
}

const storeOf = (storage: () => Storage): Store => ({
  get(key) {
    try {
      return storage().getItem(key);
    } catch {
      return null;
    }
  },
  set(key, value) {
    try {
      storage().setItem(key, value);
    } catch {
      // storage blocked: guards simply won't persist across reloads
    }
  },
});

/** This tab only; survives SPA reloads. */
export const session = storeOf(() => sessionStorage);
/** Shared by every BLS tab of the browser profile. */
export const shared = storeOf(() => localStorage);

/**
 * Sliding-window rate limit persisted in sessionStorage so it survives SPA reloads.
 * Returns true (and records the attempt) when another attempt is allowed.
 */
export function rateGuard(key: string, max: number, windowMs: number): boolean {
  return withinLimits(key, [[max, windowMs]], session);
}

/** Like rateGuard, with several [max, windowMs] limits that must all allow the attempt. */
export function withinLimits(key: string, limits: readonly (readonly [number, number])[], store: Store, now = Date.now()): boolean {
  const longest = Math.max(...limits.map(([, w]) => w));
  let log: number[] = [];
  try {
    log = JSON.parse(store.get(key) ?? "[]") as number[];
  } catch {
    // corrupted entry: start fresh
  }
  log = log.filter((t) => now - t < longest);
  if (limits.some(([max, w]) => log.filter((t) => now - t < w).length >= max)) return false;
  log.push(now);
  store.set(key, JSON.stringify(log));
  return true;
}

/** Sets a value in a way React's controlled inputs/selects pick up (native setter + input/change events). */
export function setNativeValue(el: HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement, value: string): void {
  const proto = Object.getPrototypeOf(el) as object;
  Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, value);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

export const contextAlive = (): boolean => !!chrome.runtime?.id;

export const textOf = (e: Element | null | undefined): string => e?.textContent?.trim() ?? "";

/** The account signup wizard: forms only, the slot watcher stays out (its date pickers are calendars too). */
export const onSignupPage = (): boolean => /\/(signup|register)/i.test(location.pathname);
