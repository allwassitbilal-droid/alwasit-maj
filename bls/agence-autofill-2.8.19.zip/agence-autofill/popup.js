// Gmail + its code come first everywhere. `code` has no fill rule: it only goes where you click.
const FIELDS = [
  ['gmail', 'Gmail'], ['code', 'Code Gmail'], ['blsmdp', 'Mot de passe BLS'], ['prenom', 'Prénom'], ['nom', 'Nom'], ['naissance', 'Naissance'], ['passeport', 'N° passeport'],
  ['delivre', 'Délivré'], ['expire', 'Expire'], ['lieu', 'Lieu délivrance'], ['mobile', 'Mobile'],
];
const $ = s => document.querySelector(s);
const form = $('#edit-view');
let clients = [], editingId = null, openId = null, selected = 0;
let enabled = FIELDS.map(f => f[0]); // fields the user wants filled (⚙)
// Folders: each account has an optional `dossier`; `dossiers` also keeps folders that are still empty.
const ALL = '', NONE = '\u0000none';
let dossiers = [], folder = ALL;
let famOpen = new Set(); // families shown open (▾): by default only the principal shows; kept on this PC only
let view = 'all'; // departures board: all | rdv | pret | pass
let folderHue = new Map(); // folder → its candy color, for the ticket stub
let blsActive = null; // client signed in / searched for on BLS (bls.js)

const save = () => chrome.storage.local.set({ clients });
const saveFolders = () => chrome.storage.local.set({ dossiers, folder });
const folderNames = () => [...new Set([...dossiers, ...clients.map(c => c.dossier).filter(Boolean)])]
  .sort((a, b) => a.localeCompare(b));
const inFolder = (c, f) => f === ALL || (f === NONE ? !c.dossier : c.dossier === f);
const frDate = iso => (iso ? iso.split('-').reverse().join('/') : '');
const show = (k, v) => (AA_DATES.includes(k) ? frDate(v) : v || '');
const fullName = c => `${c.prenom || ''} ${c.nom || ''}`.trim() || '(sans nom)';
// N° of the client (✎ → «N° dossier»): shown in the round badge, and the list is sorted by it. No number = at the end.
const numOf = c => (Number.isFinite(+c.num) && String(c.num).trim() !== '' ? +c.num : Infinity);
const groupNum = g => Math.min(...g.map(numOf));

function el(tag, props = {}, ...kids) {
  const e = Object.assign(document.createElement(tag), props);
  e.append(...kids.filter(k => k != null));
  return e;
}

function toast(msg, bad) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = bad ? 'show bad' : 'show';
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (t.className = ''), 2500);
}

// ---- Family: accounts with the same `famille` id show together; `lien` orders them ----
const LIENS = { principal: 'Principal', conjoint: 'Époux/se', enfant: 'Enfant', autre: 'Autre' };
const lienRank = c => { const i = Object.keys(LIENS).indexOf(c.lien); return i < 0 ? 9 : i; };
const membersOf = f => (f ? clients.filter(c => c.famille === f) : [])
  .sort((a, b) => lienRank(a) - lienRank(b) || fullName(a).localeCompare(fullName(b)));

// Flat list in display order: a family stays together (head first), and a match on one member brings the whole family.
// Departures board (top): quick views over the open folder.
const isComing = c => c.reserve?.day && dayDiff(c.reserve.day) >= 0;
const passBad = c => c.expire && (new Date(c.expire) - new Date()) / 864e5 < 183;
const BOARD = {
  all: { label: 'Tous', test: () => true },
  rdv: { label: 'RDV à venir', test: isComing, title: 'Clients avec un rendez-vous BLS aujourd\'hui ou plus tard' },
  pret: { label: 'Prêts', test: c => !!c.pret, title: 'Clients marqués prêts (⭐ wajdin)' },
  pass: { label: 'Passeport ⚠', test: passBad, title: 'Passeport expiré ou qui expire dans moins de 6 mois' },
};
function renderBoard() {
  const base = clients.filter(c => inFolder(c, folder));
  $('#board').replaceChildren(...Object.entries(BOARD).map(([k, b]) => el('button', {
    className: 'gate ' + k + (view === k ? ' on' : ''), title: b.title || 'Tous les clients du dossier',
    onclick: () => { view = view === k && k !== 'all' ? 'all' : k; selected = 0; render(); },
  }, el('b', { textContent: base.filter(b.test).length }), el('span', { textContent: b.label }))));
}

function filtered() {
  const q = AA_norm($('#q').value);
  const hits = clients
    .filter(c => inFolder(c, folder))
    .filter(c => BOARD[view].test(c))
    .filter(c => !q || String(c.num ?? '') === q || AA_norm([c.prenom, c.nom, c.prenom, c.passeport, c.mobile, c.gmail].join('')).includes(q));
  const groups = new Map();
  for (const c of hits) {
    const key = c.famille || c.id;
    if (!groups.has(key)) groups.set(key, c.famille ? membersOf(c.famille).filter(m => inFolder(m, folder)) : [c]);
  }
  // Ready (⭐) accounts first; a family with one ready member goes up whole.
  return [...groups.values()]
    // Ready groups first, then the others; inside each, by N° (1, 2, 3…), then by name for those without one.
    .sort((a, b) => isReady(b) - isReady(a) || (groupNum(a) - groupNum(b) || 0) || fullName(a[0]).localeCompare(fullName(b[0]))).flat();
}
const isReady = group => group.some(c => c.pret);
const readyAt = group => Math.min(...group.filter(c => c.pret).map(c => c.pretAt || 0));
// «aujourd'hui» / «demain» instead of the date when the appointment is that close
const dayDiff = iso => Math.round((new Date(iso + 'T12:00:00') - new Date(new Date().toDateString() + ' 12:00')) / 864e5);
const rdvText = r => {
  const d = dayDiff(r.day);
  const when = d === 0 ? "aujourd'hui" : d === 1 ? 'demain' : frDate(r.day).slice(0, 5);
  return `${when} ${r.time || ''}`.trim();
};

// This client becomes BLS's active person: login (BLS password, else the Gmail code), navigation to the
// dates, watching, and «Remplir» on the forms. Another account than the signed-in one signs out first.
async function openBls(c) {
  if (!c.gmail || !(c.blsmdp || c.code)) return toast('Ajoutez d\'abord le Gmail et le mot de passe BLS (✎)', true);
  const { id: windowId } = await chrome.windows.getCurrent();
  const r = await chrome.runtime.sendMessage({ type: 'bls-open', id: c.id, windowId });
  if (!r?.ok) return toast('BLS : ' + (r?.error || 'impossible d\'ouvrir'), true);
  blsActive = c.id;
  render();
  toast(`BLS : ${fullName(c)} — connexion puis page des dates…`);
}

// «🆕» on the list and «Créer le compte BLS» in ✎: a BLS account made from the client's real Gmail and passport.
// Shown for clients that seem to have none yet: no BLS password, never booked, not created here.
const needsAccount = c => !c.blsmdp && !c.reserve && c.blsCompte?.stage !== 'created';
const SIGNUP_NEEDS = [['gmail', 'Gmail'], ['prenom', 'Prénom'], ['nom', 'Nom'], ['passeport', 'N° passeport'], ['naissance', 'Naissance']];
async function createBls(c) {
  const need = SIGNUP_NEEDS.filter(([k]) => !(c[k] || '').trim()).map(([, l]) => l);
  if (need.length) return toast('Pour créer le compte, remplissez (✎) : ' + need.join(', '), true), false;
  const { id: windowId } = await chrome.windows.getCurrent();
  const r = await chrome.runtime.sendMessage({ type: 'bls-signup', id: c.id, windowId });
  if (!r?.ok) return toast('BLS : ' + (r?.error || 'impossible d\'ouvrir'), true), false;
  blsActive = c.id;
  toast(`BLS : création du compte de ${fullName(c)}…`);
  return true;
}

// A family is booked as one (the Principal's BLS account, number of persons chosen on BLS):
// its members are ready, or not, together.
async function toggleReady(c) {
  const pret = !c.pret;
  const pretAt = pret ? Date.now() : undefined; // «File ⭐» books the ready clients in this order
  const group = c.famille ? membersOf(c.famille) : [c];
  for (const m of group) Object.assign(m, { pret, pretAt });
  await save();
  render();
  const who = group.length > 1 ? `Famille ${c.nom || fullName(c)} (${group.length})` : fullName(c);
  toast(pret ? `⭐ ${who} prêt${group.length > 1 ? 's' : ''}` : `${who} n'est plus dans les prêts`);
}

function render() {
  renderFolders();
  renderBoard();
  AATaches.render();
  const list = filtered();
  selected = Math.min(selected, Math.max(list.length - 1, 0));
  $('#count').textContent = `${list.length} / ${clients.length} clients · nom = tout remplir · case + valeur = une case`;
  const blocks = [];
  const nReady = list.filter(c => c.pret).length;
  const section = (cls, text) => el('div', { className: 'section ' + cls, textContent: text });
  if (nReady && view !== 'pret') blocks.push(section('ready', `⭐ Prêts (wajdin) · ${nReady}`));
  let othersShown = false; // ready groups come first (filtered), then this title once
  const searching = !!$('#q').value.trim();
  for (let i = 0; i < list.length;) {
    const f = list[i].famille;
    let j = i + 1;
    while (f && j < list.length && list[j].famille === f) j++;
    const group = list.slice(i, j);
    if (nReady && view !== 'pret' && !othersShown && !isReady(group)) { blocks.push(section('others', 'Tous les clients')); othersShown = true; }
    if (group.length < 2) blocks.push(item(group[0], i, i === selected));
    else {
      // A family = the principal's ticket only; ▾ under it shows the others (a search always shows them).
      const headIdx = Math.max(0, group.findIndex(c => c.lien === 'principal'));
      const open = famOpen.has(f) || searching;
      const toggle = () => { famOpen.has(f) ? famOpen.delete(f) : famOpen.add(f); chrome.storage.local.set({ famOpen: [...famOpen] }); render(); };
      const others = group.map((c, k) => [c, i + k]).filter((_, k) => k !== headIdx);
      blocks.push(el('div', { className: 'family' + (open ? ' open' : '') },
        item(group[headIdx], i + headIdx, i + headIdx === selected || (!open && selected >= i && selected < j), { n: group.length, open, toggle, names: others.map(([c]) => c.prenom || fullName(c)) }),
        open ? el('div', { className: 'fam-members' }, ...others.map(([c, idx]) => item(c, idx, idx === selected))) : null));
    }
    i = j;
  }
  const emptyText = !clients.length ? 'Aucun client pour l\'instant. Cliquez + ou importez un CSV.'
    : view !== 'all' ? `Aucun client dans « ${BOARD[view].label} » ici.` : 'Aucun client dans ce dossier.';
  $('#list').replaceChildren(...(list.length ? blocks : [el('div', { className: 'empty', textContent: emptyText })]));
  $('#list .sel')?.scrollIntoView({ block: 'nearest' }); // keyboard ↑↓ keeps the selected row visible
}

let shineFolder; // folder just clicked: its button shines once
function renderFolders() {
  const names = folderNames();
  if (folder !== ALL && folder !== NONE && !names.includes(folder)) folder = ALL;
  const count = f => clients.filter(c => inFolder(c, f)).length;
  // Candy buttons: each folder keeps its own color (from its name), the open one shines.
  const CANDY = [330, 145, 28, 205, 268, 185, 0, 48, 95, 300];
  const hueOf = n => CANDY[names.indexOf(n) % CANDY.length]; // in A→Z order, so two folders never share a color
  folderHue = new Map(names.map(n => [n, hueOf(n)]));
  const fchip = (f, label, cls = '') => {
    const b = el('button', {
      className: 'fchip ' + cls + (folder === f ? ' on' : '') + (shineFolder === f ? ' shine' : ''),
      onclick: () => { folder = f; shineFolder = f; selected = 0; openId = null; saveFolders(); render(); },
    }, el('span', { className: 'lbl', textContent: label }), el('span', { className: 'cnt', textContent: count(f) }));
    if (f !== NONE) b.style.setProperty('--h', f === ALL ? 45 : hueOf(f));
    return b;
  };
  const kids = [fchip(ALL, 'Tous', 'all'), ...names.map(n => fchip(n, n))];
  if (names.length && count(NONE)) kids.push(fchip(NONE, 'Sans dossier', 'none'));
  kids.push(el('button', { className: 'fchip add', textContent: '+ Dossier', onclick: newFolder }));
  if (folder !== ALL && folder !== NONE) {
    kids.push(
      el('button', { className: 'fchip tool', textContent: '✎', title: 'Renommer le dossier', onclick: renameFolder }),
      el('button', { className: 'fchip tool danger', textContent: '🗑', title: 'Supprimer le dossier', onclick: deleteFolder }));
  }
  $('#folders').replaceChildren(...kids);
  shineFolder = undefined; // the shine plays once, on the click only
}

// Small inline text box (instead of prompt()) -> resolves with the text, or null if cancelled.
function askInline(placeholder, value = '') {
  return new Promise(resolve => {
    let finished = false;
    const box = $('#folder-ask');
    const inp = el('input', { placeholder, value });
    const done = v => { if (finished) return; finished = true; box.hidden = true; resolve(v); };
    inp.onkeydown = e => {
      if (e.key === 'Enter') { e.preventDefault(); done(inp.value.trim() || null); }
      if (e.key === 'Escape') done(null);
    };
    inp.onblur = () => done(null);
    box.replaceChildren(inp, el('button', {
      className: 'primary', textContent: 'OK',
      onmousedown: e => { e.preventDefault(); done(inp.value.trim() || null); },
    }));
    box.hidden = false;
    inp.focus();
    inp.select();
  });
}

async function newFolder() {
  const name = await askInline('Nom du dossier (ex: Omra 2026) puis Entrée');
  if (!name) return;
  if (!dossiers.includes(name)) dossiers.push(name);
  folder = name;
  saveFolders();
  render();
}

async function renameFolder() {
  const old = folder;
  const name = await askInline('Nouveau nom du dossier', old);
  if (!name || name === old) return;
  clients.forEach(c => { if (c.dossier === old) c.dossier = name; });
  dossiers = [...new Set(dossiers.map(d => (d === old ? name : d)).concat(name))];
  folder = name;
  await save();
  saveFolders();
  render();
}

// Two clicks to delete. The accounts are kept and go to "Sans dossier".
async function deleteFolder(e) {
  const btn = e.currentTarget;
  if (!btn.dataset.armed) {
    btn.dataset.armed = '1';
    btn.textContent = 'Supprimer le dossier ?';
    setTimeout(() => renderFolders(), 3000);
    return;
  }
  clients.forEach(c => { if (c.dossier === folder) delete c.dossier; });
  dossiers = dossiers.filter(d => d !== folder);
  folder = ALL;
  await save();
  saveFolders();
  render();
  toast('Dossier supprimé — ses comptes sont dans "Sans dossier"');
}

// Click a value = put it in the field clicked on the page (or copy it if the page blocks extensions)
// Codes and passwords show as dots; a click still puts (or copies) the real value.
const SECRETS = ['code', 'blsmdp'];
const chip = (label, value, key = null, raw = value) => el('button', {
  className: ['gmail', ...SECRETS].includes(key) ? 'chip gm' : 'chip', title: 'Cliquez une case du formulaire, puis ici',
  onclick: () => insertValue(label, key, raw, value),
}, el('span', { textContent: label }), SECRETS.includes(key) ? '••••••' : value);

// Passport ending soon: BLS wants it valid well after the trip. ⛔ expired, ⚠️ under 6 months left.
// Outlook / Hotmail / Live : à remplacer par un Gmail (recréer le compte BLS).
const OUTLOOK_RE = /@(?:outlook|hotmail|live|msn|windowslive|passport)\.[a-z.]+$/i;
function outlookWarning(c) {
  if (!c.gmail || !OUTLOOK_RE.test(c.gmail.trim())) return null;
  return el('span', { className: 'chip outlook', textContent: '✉ Outlook — recréer le compte',
    title: `${c.gmail.trim()} est une adresse Outlook/Hotmail. Créez un compte Gmail pour ce client.` });
}

function passportWarning(c) {
  if (!c.expire) return null;
  const left = (new Date(c.expire) - new Date()) / 864e5;
  if (left >= 183) return null;
  const when = frDate(c.expire);
  return left < 0
    ? el('span', { className: 'chip exp bad', textContent: '⛔ Passeport expiré', title: `Expiré le ${when}` })
    : el('span', { className: 'chip exp', textContent: `⚠ Passeport ${when.slice(3)}`, title: `Le passeport expire le ${when} (moins de 6 mois)` });
}

// BLS stage, one color each: 🗓 booked (blue) → 📸 selfie to do (purple) → 📄 letter downloaded (green).
const stageOf = c => !c.reserve ? '' : c.lettre ? 'done' : c.reserve.face ? 'selfie' : 'rdv';
const STAGES = {
  rdv: ['🗓 RDV ', 'Rendez-vous BLS réservé'],
  selfie: ['📸 Selfie · RDV ', 'Réservé — le selfie (scan du visage) reste à faire'],
  done: ['📄 RDV ', 'Réservé et lettre de rendez-vous téléchargée'],
};
function rdvTag(c) {
  const st = stageOf(c);
  if (!st) return null;
  const [label, title] = STAGES[st];
  const soon = dayDiff(c.reserve.day) <= 1 && dayDiff(c.reserve.day) >= 0 ? ' soon' : '';
  return el('span', { className: 'tag-rdv s-' + st + soon, textContent: label + rdvText(c.reserve), title: [c.lettre ? `${title} : ${c.lettre.name}` : title, c.reserve.centre, c.reserve.ref].filter(Boolean).join(' · ') });
}

// The stamp on the ticket: the appointment, inked like a passport stamp.
function stamp(c) {
  const st = stageOf(c);
  if (!st) return null;
  const d = dayDiff(c.reserve.day), date = frDate(c.reserve.day).slice(0, 5), time = c.reserve.time || '';
  const [top, bottom, cls] = d < 0 ? ['RDV passé', date, 'past']
    : st === 'done' ? ['Lettre ✓', `RDV ${date}`, 'done']
    : st === 'selfie' ? ['Selfie à faire', `RDV ${date} ${time}`, 'selfie']
    : [d === 0 ? "RDV aujourd'hui" : d === 1 ? 'RDV demain' : `RDV ${date}`, time, d <= 1 ? 'soon' : ''];
  const [, title] = STAGES[st];
  return el('div', { className: 'stamp ' + cls, title: c.lettre ? `${title} : ${c.lettre.name}` : title },
    el('b', { textContent: top }), bottom ? el('small', { textContent: bottom }) : null);
}

function item(c, i, isSel, fam) {
  const n = numOf(c), has = Number.isFinite(n);
  const hue = folderHue.get(c.dossier);
  // Stub: the file number, like a seat on a boarding pass, in the folder's color
  const stub = el('div', { className: 'stub' + (hue == null ? ' nofolder' : ''), title: has ? `N° ${n}${c.dossier ? ' · ' + c.dossier : ''}` : 'Pas de N° : ✎ → N° dossier' },
    el('small', { textContent: 'N°' }), el('b', { className: has && String(n).length > 2 ? 'long' : '', textContent: has ? String(n) : '?' }));
  if (hue != null) stub.style.setProperty('--h', hue);
  const signing = c.blsCompte?.stage && c.blsCompte.stage !== 'created';
  const chips = [
    fam ? el('button', { className: 'chip-fam', textContent: `👨‍👩‍👧 Famille · ${fam.n}`, title: fam.open ? 'Cacher les membres' : 'Voir : ' + fam.names.join(', '),
      onclick: e => { e.stopPropagation(); fam.toggle(); } }) : null,
    LIENS[c.lien] && c.famille && !fam ? el('span', { className: 'chip', textContent: LIENS[c.lien] }) : null,
    c.pret ? el('span', { className: 'chip pret', textContent: '★ Prêt' }) : null,
    AAExtras.payChip(c),
    outlookWarning(c),
    passportWarning(c),
    folder === ALL && c.dossier ? el('span', { className: 'chip', textContent: '📁 ' + c.dossier }) : null,
    needsAccount(c) ? el('button', {
      className: 'chip new', textContent: signing ? '↻ Créer le compte BLS' : '🆕 Créer le compte BLS',
      title: signing ? 'Reprendre la création du compte BLS' : 'Créer le compte BLS (Gmail et passeport du client)',
      onclick: e => { e.stopPropagation(); createBls(c).then(ok => ok && render()); },
    }) : null,
  ].filter(Boolean);
  const body = el('div', { className: 'body', title: 'Cliquer pour remplir', onclick: () => { openId = c.id; render(); fill(c); } },
    el('div', { className: 'nm', textContent: fullName(c) }),
    el('div', { className: 'meta', textContent: [c.passeport, c.gmail || c.mobile].filter(Boolean).join('  ·  ') || 'Passeport et Gmail à compléter' }),
    chips.length ? el('div', { className: 'chips' }, ...chips) : null);
  const acts = el('div', { className: 'acts' },
    el('button', { className: 'bls' + (blsActive === c.id ? ' on' : ''), textContent: 'BLS',
      title: blsActive === c.id ? 'Client actif sur BLS (cliquez pour y retourner)' : 'Ouvrir BLS avec ce client : connexion, dates, formulaire', onclick: () => openBls(c) }),
    el('button', { textContent: '✎', title: 'Modifier', onclick: () => openEdit(c) }),
    AAFiche.button(c),
    el('button', { className: 'lettre-btn', textContent: '📄', title: 'Importer la lettre de RDV (PDF ou photo) : date, heure, centre et réf enregistrés', onclick: e => importLettreFor(c, e.currentTarget) }),
    el('button', { className: 'star', textContent: c.pret ? '★' : '☆', title: c.pret ? 'Retirer des prêts' : 'Marquer prêt (wajed)', onclick: () => toggleReady(c) }),
    el('button', { textContent: '⧉', title: 'Afficher les valeurs (sans remplir)', onclick: () => { openId = openId === c.id ? null : c.id; render(); } }));
  const st = stageOf(c);
  const ticket = el('div', { className: 'ticket' + (st ? ' has-stamp' : '') }, stub, el('i', { className: 'perf' }), body, stamp(c), acts);
  const details = openId === c.id ? el('div', { className: 'details' },
    ...FIELDS.filter(([k]) => c[k]).map(([k, label]) => chip(label, show(k, c[k]), k, c[k])),
    ...(c.extra || '').split('\n').map(l => l.split(/=(.*)/s)).filter(p => p[1] !== undefined)
      .map(([l, v]) => chip(l.trim(), v.trim()))) : null;
  // ▾ under a family's principal: shows / hides the other members
  const more = fam ? el('button', { className: 'fam-arrow' + (fam.open ? ' open' : ''), title: fam.open ? 'Cacher la famille' : `Voir la famille (${fam.names.join(', ')})`,
    onclick: fam.toggle }, el('span', { textContent: fam.open ? '▴' : '▾' }), fam.open ? ' Cacher' : ` ${fam.n - 1} autre${fam.n > 2 ? 's' : ''}`) : null;
  return el('div', { className: 'item' + (c.pret ? ' pret' : '') + (st ? ' st-' + st : '') + (isSel ? ' sel' : '') + (fam ? ' head' : '') }, ticket, details, more);
}

function renderSettings() {
  $('#checks').replaceChildren(...FIELDS.filter(([k]) => k !== 'code' && k !== 'blsmdp').map(([k, label]) => el('label', {},
    el('input', {
      type: 'checkbox', checked: enabled.includes(k),
      onchange: e => {
        enabled = e.target.checked ? [...enabled, k] : enabled.filter(x => x !== k);
        chrome.storage.local.set({ enabled });
      },
    }), label)));
}
$('#gear').onclick = () => { $('#settings').hidden = !$('#settings').hidden; };
$('#blsSettings').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('bls/settings.html') });

// Runs filler.js in the page. `frames`: undefined = main frame, true = all frames, [ids] = those frames.
async function runInTab(fn, arg, frames) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const target = { tabId: tab.id };
  if (frames === true) target.allFrames = true;
  else if (frames) target.frameIds = frames;
  await chrome.scripting.executeScript({ target, files: ['rules.js', 'filler.js'] });
  const res = await chrome.scripting.executeScript({
    target,
    func: (fn, arg) => globalThis.__agenceAutofill[fn](arg),
    args: [fn, arg ?? null],
  });
  return frames === true ? res : res[0].result;
}

async function fill(c) {
  try {
    const payload = { extra: c.extra };
    for (const k of enabled) payload[k] = c[k];
    const res = await runInTab('fill', payload, true);
    const n = res.reduce((s, r) => s + (r.result?.filled.length || 0), 0);
    if (!n) return toast('Aucun champ reconnu : cliquez une case puis une valeur', true);
    toast(`✓ ${n} champs remplis`);
  } catch (e) {
    toast('Page protégée : cliquez une valeur pour la copier, puis Ctrl+V', true);
  }
}

async function insertValue(label, key, raw, shown) {
  try {
    // Frame where the user clicked a field most recently
    const times = await runInTab('lastTime', null, true);
    const best = times.reduce((a, b) => ((b.result || 0) > (a?.result || 0) ? b : a), null);
    if (best?.result && await runInTab('insert', { key, value: raw }, [best.frameId])) {
      return toast(`✓ ${label} mis`);
    }
  } catch { /* page where extensions cannot write: copy instead */ }
  await navigator.clipboard.writeText(shown);
  toast(`${label} copié — cliquez la case et faites Ctrl+V`);
}

async function capture() {
  try {
    const data = await runInTab('capture');
    if (!Object.keys(data).length) return toast('Aucune donnée trouvée sur la page', true);
    const same = data.passeport && clients.find(c => c.passeport === data.passeport);
    openEdit(same ? { ...same, ...data } : data);
  } catch (e) {
    toast('Impossible sur cette page (' + e.message + ')', true);
  }
}

function openEdit(c = {}) {
  editingId = c.id || null;
  for (const [k] of FIELDS) form.elements[k].value = c[k] || '';
  form.elements.extra.value = c.extra || '';
  form.elements.num.value = c.num ?? ''; // the N° is typed by the user, never set automatically
  AAExtras.fillPay(form, c);
  AAExtras.renderWa($('#wa-box'), c);
  form.elements.lien.value = c.lien || '';
  editFamille = c.famille || '';
  editReserve = c.reserve || null;
  editLettre = c.lettre || null;
  importedRdv = null;
  form.elements.rdvDay.value = c.reserve?.day || '';
  form.elements.rdvTime.value = c.reserve?.time || '';
  for (const i of document.querySelectorAll('.secret input')) i.classList.add('hide');
  for (const b of document.querySelectorAll('.secret .eye')) b.classList.remove('on');
  renderRdv();
  renderSignup(c);
  renderFamily();
  // New account goes into the folder currently open
  form.elements.dossier.value = editingId || c.dossier ? c.dossier || '' : (folder !== ALL && folder !== NONE ? folder : '');
  $('#dossier-list').replaceChildren(...folderNames().map(n => el('option', { value: n })));
  $('#edit-title').textContent = editingId ? 'Modifier compte' : 'Nouveau compte';
  $('#del').hidden = !editingId;
  $('#del').textContent = 'Supprimer';
  delete $('#del').dataset.armed;
  $('#list-view').hidden = true;
  form.hidden = false;
  form.elements.gmail.focus();
  renderFiles(editingId);
}

// ---- Files of the client (only here in ✎, never in the list) ----
async function renderFiles(id) {
  const box = $('#file-rows');
  const note = text => box.replaceChildren(el('div', { className: 'hint', textContent: text }));
  if (!id) return note('Enregistrez d\'abord le client, puis ✎ pour ajouter ses fichiers.');
  note('Chargement…');
  try {
    const lists = await Promise.all(AAFiles.SLOTS.map(([slot]) => AAFiles.list(id, slot)));
    if (editingId !== id) return; // form closed meanwhile
    box.replaceChildren(...AAFiles.SLOTS.map(([slot, label], i) => fileRow(id, slot, label, lists[i][0])));
  } catch (e) {
    if (editingId === id) note(e.message);
  }
}

function fileRow(id, slot, label, f) {
  const btn = (text, title, onclick, cls = '') => el('button', { type: 'button', textContent: text, title, onclick, className: cls });
  return el('div', { className: 'frow' },
    el('span', { className: 'flabel', textContent: label }),
    el('span', { className: 'fname', textContent: f ? '✓ ' + f.name : '—', title: f?.name || '' }),
    f && btn('👁', 'Ouvrir', () => AAFiles.open(f.path).catch(e => toast(e.message, true))),
    f && btn('🗑', 'Supprimer (2 clics)', e => deleteFile(e, id, f.path), 'danger'),
    btn(f ? 'Remplacer' : 'Ajouter', '', () => pickFile(id, slot)));
}

function pickFile(id, slot) {
  const inp = $('#upload');
  inp.accept = slot === 'photo' ? 'image/*' : 'image/*,.pdf';
  inp.onchange = async () => {
    const file = inp.files[0];
    inp.value = '';
    if (!file) return;
    toast('Envoi…');
    try {
      await AAFiles.upload(id, slot, file);
      toast('✓ Fichier ajouté');
    } catch (e) { toast(e.message, true); }
    if (editingId === id) renderFiles(id);
  };
  inp.click();
}

async function deleteFile(e, id, path) {
  const btn = e.currentTarget;
  if (!btn.dataset.armed) { btn.dataset.armed = '1'; btn.textContent = 'Sûr ?'; return; }
  try {
    await AAFiles.remove([path]);
    toast('Fichier supprimé');
  } catch (err) { toast(err.message, true); }
  if (editingId === id) renderFiles(id);
}

function closeEdit() {
  form.hidden = true;
  $('#list-view').hidden = false;
  render();
  $('#q').focus();
}

// Saves the open form (a new account gets its id here). false = not saved.
async function saveForm() {
  const data = Object.fromEntries(FIELDS.map(([k]) => [k, form.elements[k].value.trim()]));
  data.extra = form.elements.extra.value.trim();
  data.dossier = form.elements.dossier.value.trim();
  const num = form.elements.num.value.trim();
  data.num = num === '' ? undefined : +num;
  Object.assign(data, AAExtras.readPay(form));
  const twin = data.num !== undefined && clients.find(c => c.id !== editingId && numOf(c) === data.num);
  saveForm.warn = twin ? `Enregistré — attention : le N° ${data.num} est aussi celui de ${fullName(twin)}` : '';
  data.lien = form.elements.lien.value;
  data.famille = editFamille;
  // «🗓 Rendez-vous BLS» typed by hand: kept as the booking (same as when the extension books by itself)
  const day = form.elements.rdvDay.value, time = form.elements.rdvTime.value;
  const before = editReserve;
  if (!day) { editReserve = null; editLettre = null; }
  else if (importedRdv && importedRdv.day === day && importedRdv.time === time) {
    // «📄 Importer la lettre RDV»: the date read from the letter, with its reference and centre
    const { ref, centre, lettre } = importedRdv;
    editReserve = { day, time, at: Date.now(), manual: true, ...(ref && { ref }), ...(centre && { centre }) };
    editLettre = lettre;
  }
  else if (!editReserve || editReserve.day !== day || (editReserve.time || '') !== time) {
    editReserve = { day, time, at: Date.now(), manual: true };
    editLettre = null;
  }
  const rdvChanged = JSON.stringify(before) !== JSON.stringify(editReserve);
  data.reserve = editReserve || undefined;
  data.lettre = (editReserve && editLettre) || undefined;
  if (editReserve && rdvChanged) data.pret = false; // booked: leaves the ⭐ queue
  if (!data.nom && !data.prenom) { toast('Nom ou prénom obligatoire', true); return false; }
  if (editingId) Object.assign(clients.find(c => c.id === editingId), data);
  else { editingId = crypto.randomUUID(); clients.push({ id: editingId, ...data, ajout: await AA_newMeta() }); }
  // A family books together: the same appointment for every member.
  if (rdvChanged && data.famille) {
    for (const m of membersOf(data.famille)) {
      if (m.id === editingId) continue;
      if (editReserve) Object.assign(m, { reserve: editReserve, pret: false }); else delete m.reserve;
      delete m.lettre;
    }
  }
  await save();
  if (editReserve && rdvChanged) AAWhatsApp.addPending(editingId); // «🗓 RDV جديد» → 📲 the staff
  const file = importedRdv?.file;
  importedRdv = null;
  if (file) AAFiles.upload(editingId, 'lettre', file).then(() => renderFiles(editingId), e => toast('Lettre non envoyée dans Fichiers : ' + e.message, true));
  return true;
}

// ---- ✎ → «Créer le compte BLS»: the client's real Gmail and passport; bls.js signs out and opens the signup ----
const SIGNUP_STAGES = {
  form: '🆕 Inscription en cours : formulaire rempli sur BLS',
  otp: '📧 Code envoyé au Gmail du client : tapez-le sur BLS',
  password: '🔐 Mettez le mot de passe reçu par email dans «Mot de passe BLS», la connexion suit',
  created: '✅ Compte BLS créé (mot de passe changé et enregistré ici)',
};
function renderSignup(c = {}) {
  const st = c.blsCompte?.stage;
  $('#signup-state').textContent = SIGNUP_STAGES[st] || '';
  $('#signup').textContent = st && st !== 'created' ? '↻ Reprendre la création' : '🆕 Créer le compte BLS';
}
$('#signup').onclick = async () => {
  const need = SIGNUP_NEEDS.filter(([k]) => !form.elements[k].value.trim()).map(([, l]) => l);
  if (need.length) return toast('Pour créer le compte, remplissez : ' + need.join(', '), true);
  if (!(await saveForm())) return;
  if (await createBls(clients.find(x => x.id === editingId))) closeEdit();
};

form.onsubmit = async e => {
  e.preventDefault();
  if (!await saveForm()) return;
  toast(saveForm.warn || 'Client enregistré', !!saveForm.warn);
  closeEdit();
};

// ---- BLS appointment in ✎ (set by bls.js when a booking goes through) ----
let editReserve = null, editLettre = null, importedRdv = null;
function renderRdv() {
  const box = $('#rdv');
  box.hidden = !editReserve;
  if (!editReserve) return;
  const st = stageOf({ reserve: editReserve, lettre: editLettre });
  box.className = 'rdv s-' + st;
  const where = [editReserve.centre, editReserve.ref].filter(Boolean).join(' · ');
  const when = `${frDate(editReserve.day)} ${editReserve.time || ''}${where ? ` (${where})` : ''}`;
  const text = st === 'done' ? `📄 RDV ${when} — lettre : ${editLettre.name}`
    : st === 'selfie' ? `📸 RDV ${when} — selfie à faire` : `🗓 Rendez-vous BLS : ${when}`;
  box.replaceChildren(...[
    el('span', { textContent: text }),
    st === 'selfie' ? el('button', {
      type: 'button', className: 'small', textContent: '✓ Selfie fait',
      onclick: () => { editReserve = { ...editReserve, face: false }; renderRdv(); toast('Cliquez Enregistrer pour confirmer'); },
    }) : null,
    editLettre && editLettre.pc === deviceId ? el('button', {
      type: 'button', className: 'small', textContent: '📂 Afficher', title: 'Montrer le PDF dans le dossier Téléchargements',
      onclick: () => chrome.downloads.search({ id: editLettre.dl }).then(([d]) => d?.exists ? chrome.downloads.show(d.id) : toast('Fichier introuvable sur ce PC (déplacé ou supprimé)', true)),
    }) : null,
    el('button', {
      type: 'button', className: 'danger small', textContent: 'Effacer',
      onclick: () => { editReserve = null; editLettre = null; form.elements.rdvDay.value = ''; form.elements.rdvTime.value = ''; renderRdv(); toast('RDV effacé — cliquez Enregistrer pour confirmer'); },
    })].filter(Boolean));
}
let deviceId = null;
chrome.storage.local.get('deviceId').then(r => { deviceId = r.deviceId || null; });

// ---- Family box in ✎ ----
let editFamille = '', linkable = new Map();
function renderFamily() {
  const others = membersOf(editFamille).filter(m => m.id !== editingId);
  $('#fam-members').replaceChildren(...others.map(m => el('button', {
    type: 'button', className: 'fam-m', title: 'Ouvrir (ce compte est enregistré d\'abord)',
    onclick: async () => { if (await saveForm()) openEdit(m); },
  }, el('span', { textContent: LIENS[m.lien] || '' }), fullName(m))));
  $('#fam-leave').hidden = !editFamille;
  linkable = new Map(clients.filter(c => c.id !== editingId && (!editFamille || c.famille !== editFamille))
    .map(c => [`${fullName(c)} · ${c.passeport || c.mobile || String(c.id || '').slice(0, 6)}`, c])); // a client without id must not break ✎
  $('#fam-list').replaceChildren(...[...linkable.keys()].map(v => el('option', { value: v })));
}

// Gives the account being edited a family id (it becomes the head if it has no role yet).
function ensureFamily(cur) {
  if (!cur.famille) { cur.famille = crypto.randomUUID(); cur.lien ||= 'principal'; }
  editFamille = cur.famille;
  form.elements.lien.value = cur.lien;
}

$('#fam-add').onclick = async () => {
  if (!await saveForm()) return;
  const cur = clients.find(c => c.id === editingId);
  ensureFamily(cur);
  await save();
  const hasSpouse = membersOf(cur.famille).some(m => m.lien === 'conjoint');
  // Same name, folder and Gmail as the family (change them if needed).
  openEdit({ famille: cur.famille, lien: hasSpouse ? 'enfant' : 'conjoint', nom: cur.nom, dossier: cur.dossier, gmail: cur.gmail, code: cur.code });
  toast('Nouveau membre de la famille : complétez puis Enregistrer');
};

$('#fam-link').onchange = async e => {
  const other = linkable.get(e.target.value);
  e.target.value = '';
  if (!other || !await saveForm()) return;
  const cur = clients.find(c => c.id === editingId);
  if (!cur.famille && other.famille) cur.famille = other.famille;
  ensureFamily(cur);
  // The other account joins, with its whole family if it already had one.
  const old = other.famille;
  for (const c of clients) if (c === other || (old && c.famille === old)) c.famille = cur.famille;
  await save();
  renderFamily();
  toast(`✓ ${fullName(other)} ajouté à la famille`);
};

$('#fam-leave').onclick = () => {
  editFamille = '';
  form.elements.lien.value = '';
  renderFamily();
  toast('Retiré de la famille — cliquez Enregistrer pour confirmer');
};

$('#del').onclick = async () => {
  const btn = $('#del');
  if (!btn.dataset.armed) { btn.dataset.armed = '1'; btn.textContent = 'Cliquez encore pour supprimer'; return; }
  AAFiles.removeAll(editingId).catch(() => {}); // its files go too (if connected)
  clients = clients.filter(c => c.id !== editingId);
  await save();
  closeEdit();
};
$('#cancel').onclick = closeEdit;
// 👁 shows a hidden code; every form opening hides them again.
for (const b of document.querySelectorAll('.secret .eye')) {
  b.onclick = () => { const i = b.previousElementSibling; i.classList.toggle('hide'); b.classList.toggle('on', !i.classList.contains('hide')); };
}
// 👁 of the team login: a real password field, so it switches type (text ↔ password).
$('#loginEye').onclick = () => {
  const i = $('#loginEye').previousElementSibling;
  i.classList.remove('hide');
  i.type = i.type === 'password' ? 'text' : 'password';
  $('#loginEye').classList.toggle('on', i.type === 'text');
};
$('#back').onclick = closeEdit;
$('#ver').textContent = 'v' + (chrome.runtime.getManifest?.().version || '');
$('#add').onclick = () => openEdit();
$('#capture').onclick = capture;
$('#scan').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('scan.html') });

$('#q').oninput = () => { selected = 0; render(); };
$('#q').onkeydown = e => {
  const list = filtered();
  if (e.key === 'ArrowDown') { selected = Math.min(selected + 1, list.length - 1); render(); e.preventDefault(); }
  if (e.key === 'ArrowUp') { selected = Math.max(selected - 1, 0); render(); e.preventDefault(); }
  if (e.key === 'Enter' && list[selected]) fill(list[selected]);
};

// ---- CSV import / export (Excel friendly: ";" separator, dates jj/mm/aaaa) ----
function parseCSV(text) {
  text = text.replace(/^﻿/, '');
  const first = text.split(/\r?\n/)[0];
  const sep = [';', ',', '\t'].sort((a, b) => first.split(b).length - first.split(a).length)[0];
  const rows = [];
  let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"' && text[i + 1] === '"') { cur += '"'; i++; }
      else if (ch === '"') q = false;
      else cur += ch;
    } else if (ch === '"') q = true;
    else if (ch === sep) { row.push(cur); cur = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i++;
      row.push(cur); rows.push(row); row = []; cur = '';
    } else cur += ch;
  }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(v => v.trim()));
}

$('#import').onclick = () => $('#file').click();
$('#file').onchange = async e => {
  const file = e.target.files[0];
  if (!file) return;
  const [head, ...rows] = parseCSV(await file.text());
  const special = { champsenplus: 'extra', dossier: 'dossier', code: 'code', codegmail: 'code', motdepasse: 'code', motdepassebls: 'blsmdp', famille: 'famille', lien: 'lien', n: 'num', no: 'num', num: 'num', numero: 'num', ndossier: 'num', numerodossier: 'num' };
  const keys = (head || []).map(h => special[AA_norm(h)] || AA_match(h));
  const current = folder !== ALL && folder !== NONE ? folder : '';
  if (!keys.includes('nom') && !keys.includes('prenom')) return toast('Colonnes Nom/Prénom introuvables', true);
  let added = 0, updated = 0;
  for (const r of rows) {
    const data = {};
    keys.forEach((k, i) => { if (k && r[i]?.trim()) data[k] = AA_DATES.includes(k) ? AA_toIso(r[i]) : r[i].trim(); });
    if (data.num !== undefined) { if (/^\d+$/.test(data.num)) data.num = +data.num; else delete data.num; }
    if (!data.nom && !data.prenom) continue;
    if (!data.dossier && current) data.dossier = current; // imported into the open folder
    const same = data.passeport && clients.find(c => c.passeport === data.passeport);
    if (same) { Object.assign(same, data); updated++; }
    else { clients.push({ id: crypto.randomUUID(), ...data, ajout: await AA_newMeta() }); added++; }
  }
  await save();
  e.target.value = '';
  render();
  toast(`${added} ajoutés, ${updated} mis à jour`);
};

$('#export').onclick = () => {
  const cell = v => (/[;"\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);
  const lines = [['N°', ...FIELDS.map(f => f[1]), 'Champs en plus', 'Dossier', 'Famille', 'Lien'].join(';'),
    ...[...clients].sort((a, b) => numOf(a) - numOf(b) || 0).map(c => [c.num ?? '', ...FIELDS.map(([k]) => cell(show(k, c[k]))), cell(c.extra || ''), cell(c.dossier || ''),
      c.famille || '', c.lien || ''].join(';'))];
  const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv' });
  el('a', { href: URL.createObjectURL(blob), download: `clients-${new Date().toISOString().slice(0, 10)}.csv` }).click();
};

// ---- Team sharing (☁): the background worker does the sync, this only logs in and shows the state ----
const preset = globalThis.AA_CONFIG || {};
$('#server-fields').hidden = !!(preset.supabaseUrl && preset.supabaseKey);
$('#cloudBtn').onclick = () => { $('#cloud').hidden = !$('#cloud').hidden; };

function renderCloud(st = {}) {
  const on = st.state !== 'off' && !!st.email;
  $('#cloudBtn').className = st.state === 'error' ? 'err' : on ? 'on' : '';
  $('#cloudBtn').title = on ? 'Partagé avec l\'équipe' : 'Non connecté : comptes seulement sur ce PC';
  $('#login').hidden = on;
  $('#logged').hidden = !on;
  const msg = on
    ? `☁ Connecté : <b></b> · ${st.live ? 'mise à jour en direct ✓' : 'synchro chaque minute'}`
    : 'Connectez-vous pour partager les comptes avec l\'équipe.';
  $('#cloud-status').innerHTML = msg;
  if (on) $('#cloud-status b').textContent = st.email || '';
  if (st.state === 'error') $('#cloud-status').append(el('div', { style: 'color:var(--danger)', textContent: 'Erreur : ' + st.error }));
}

$('#login').onsubmit = async e => {
  e.preventDefault();
  const f = e.target.elements;
  const btn = e.target.querySelector('button[type=submit]');
  btn.disabled = true;
  btn.textContent = 'Connexion…';
  const r = await chrome.runtime.sendMessage({
    type: 'login', url: f.url.value, key: f.key.value, email: f.email.value.trim(), password: f.password.value,
  });
  btn.disabled = false;
  btn.textContent = 'Se connecter';
  if (r?.ok) { f.password.value = ''; f.password.type = 'password'; $('#loginEye').classList.remove('on'); toast('Connecté ✓ les comptes sont partagés'); }
  else toast('Connexion impossible : ' + (r?.error || '?'), true);
};
$('#logout').onclick = async () => { await chrome.runtime.sendMessage({ type: 'logout' }); toast('Déconnecté'); };
$('#syncNow').onclick = async () => {
  await chrome.runtime.sendMessage({ type: 'sync-now' });
  toast('Synchronisé ✓');
};

// Changes from the scan page or from colleagues (via the background sync) show up right away.
chrome.storage.onChanged.addListener(ch => {
  // Always take the new list (a booking marks a client while a form may be open); the open form keeps its values.
  if (ch.clients) { clients = ch.clients.newValue || []; if (form.hidden) render(); }
  if (ch.syncStatus) renderCloud(ch.syncStatus.newValue);
  if (ch.blsActive) { blsActive = ch.blsActive.newValue ?? null; if (form.hidden) render(); }
});
chrome.storage.local.get(['syncStatus', 'syncConfig']).then(r => {
  renderCloud(r.syncStatus);
  if (r.syncConfig) { $('#login').elements.url.value = r.syncConfig.url; $('#login').elements.key.value = r.syncConfig.key; }
});
chrome.runtime.sendMessage({ type: 'sync-now' }).catch(() => {});

chrome.storage.local.get(['clients', 'enabled', 'dossiers', 'folder', 'famOpen', 'blsActive']).then(r => {
  clients = r.clients || [];
  // A client without id (old PC, old import) broke ✎: give it one, once.
  if (clients.some(c => !c.id)) { clients.forEach(c => { if (!c.id) c.id = crypto.randomUUID(); }); save(); }
  famOpen = new Set(r.famOpen || []);
  blsActive = r.blsActive ?? null;
  if (r.enabled) enabled = r.enabled;
  // Gmail is new: switch it on once for PCs that saved their ⚙ choice before it existed.
  if (!enabled.includes('gmail') && !r.enabled?.includes('-gmail')) {
    enabled.push('gmail', '-gmail');
    chrome.storage.local.set({ enabled });
  }
  dossiers = r.dossiers || [];
  folder = r.folder ?? ALL;
  renderSettings();
  render();
});

// ---- «À faire aujourd'hui» (taches.js): the automatic tasks, from the clients ----
function showClient(c) {
  folder = ALL; view = 'all'; openId = null; selected = 0;
  $('#q').value = `${c.prenom || ''} ${c.nom || ''}`.trim() || c.passeport || '';
  render();
  $('#list .sel')?.scrollIntoView({ block: 'center' });
}
// ✎ «💰 Paiement»: price, payments, «Tout payé» (extras.js)
AAExtras.wirePay(form);

AATaches.init({
  clients: () => clients,
  show: showClient,
  auto: () => {
    const out = [], at = h => (h ? ' à ' + h : '');
    for (const c of clients) {
      const day = c.reserve?.day;
      if (!day || c.lettre) continue;
      const d = dayDiff(day), time = c.reserve.time, selfie = c.reserve.face ? ' · selfie à faire' : '';
      if (d === 0) out.push({ key: `rdv0:${c.id}:${day}`, icon: '🗓', rank: 1, time, client: c, text: `RDV BLS aujourd'hui${at(time)}${selfie}` });
      else if (d === 1) out.push({ key: `rdv1:${c.id}:${day}`, icon: '🗓', rank: 4, time, client: c, text: `RDV BLS demain${at(time)} : préparer le dossier${selfie}` });
      else if (d > 1 && c.reserve.face) out.push({ key: `selfie:${c.id}:${day}`, icon: '🤳', rank: 5, client: c, text: `Selfie à faire avant le RDV du ${frDate(day).slice(0, 5)}` });
    }
    return out;
  },
});

// What is new in this version: shown to the team members who still have an older one (update.js).
AAUpdate.init([
  "⏸ Connexion automatique aux comptes BLS arrêtée : connectez-vous à la main (le reste marche comme avant)",
  "✉ Les clients avec une adresse Outlook / Hotmail / Live sont signalés « recréer le compte » (créez-leur un Gmail)",
  "⚙ → 🖥 Les PC de l'équipe : quelle version sur quel PC, et depuis quand il n'a pas été allumé",
  "⚙ → « Nom de ce PC » pour le reconnaître dans la liste",
  "Mise à jour automatique : chaque nouvelle version arrive toute seule sur les PC équipés"
]);

// «📝 Traductions» (traductions.js) suggests the names of this extension's clients.
globalThis.AATradClients = () => clients;

// ---- ✎ → «📄 Importer la lettre RDV»: date, time, reference and centre read from the BLS letter ----
$('#lettre-import').onclick = () => {
  const inp = $('#upload');
  inp.accept = '.pdf,image/*';
  inp.onchange = async () => {
    const file = inp.files[0];
    inp.value = '';
    if (!file) return;
    const btn = $('#lettre-import');
    btn.disabled = true;
    toast('Lecture de la lettre…');
    try {
      const r = await AALettre.read(file);
      if (!r.day) return toast('Date du RDV introuvable dans ce fichier : tapez-la à la main', true);
      form.elements.rdvDay.value = r.day;
      form.elements.rdvTime.value = r.time;
      // No «lettre» mark here: it would stop the reminders (PC and phone); the PDF goes to Fichiers instead.
      importedRdv = { day: r.day, time: r.time, ref: r.ref, centre: r.centre, file, lettre: null };
      editReserve = { day: r.day, time: r.time, ...(r.ref && { ref: r.ref }), ...(r.centre && { centre: r.centre }) };
      editLettre = importedRdv.lettre;
      renderRdv();
      const cur = { nom: form.elements.nom?.value, prenom: form.elements.prenom?.value };
      const who = AALettre.namesClient(r.text, cur);
      const info = `RDV ${frDate(r.day)} ${r.time}${r.centre ? ' · ' + r.centre : ''}`;
      if (who === false) toast(`⚠️ Le nom de la lettre ne ressemble pas à ce client. ${info} — vérifiez avant Enregistrer`, true);
      else toast(`✓ ${info} — cliquez Enregistrer`);
    } catch (e) {
      toast('Lettre illisible : ' + e.message, true);
    } finally { btn.disabled = false; }
  };
  inp.click();
};

// ---- 📄 on the card: the same letter import, saved right away (no need to open ✎) ----
function importLettreFor(c, btn) {
  const inp = $('#upload');
  inp.accept = '.pdf,image/*';
  inp.onchange = async () => {
    const file = inp.files[0];
    inp.value = '';
    if (!file) return;
    btn.disabled = true;
    toast('Lecture de la lettre…');
    try {
      const r = await AALettre.read(file);
      if (!r.day) return toast('Date du RDV introuvable dans ce fichier : ouvrez ✎ et tapez-la à la main', true);
      const info = `RDV ${frDate(r.day)} ${r.time}${r.centre ? ' · ' + r.centre : ''}`;
      if (AALettre.namesClient(r.text, c) === false && !confirm(`⚠️ Le nom sur la lettre ne ressemble pas à ${fullName(c)}.\n${info}\n\nEnregistrer quand même pour ce client ?`)) return toast('Annulé');
      const cur = clients.find(x => x.id === c.id);
      if (!cur) return;
      const reserve = { day: r.day, time: r.time, at: Date.now(), manual: true, ...(r.ref && { ref: r.ref }), ...(r.centre && { centre: r.centre }) };
      for (const m of cur.famille ? membersOf(cur.famille) : [cur]) { Object.assign(m, { reserve, pret: false }); delete m.lettre; }
      await save();
      render();
      AAWhatsApp.addPending(cur.id);
      toast(`✓ ${info} — ${fullName(cur)}`);
      AAFiles.upload(cur.id, 'lettre', file).catch(e => toast('RDV enregistré, mais lettre non envoyée dans Fichiers : ' + e.message, true));
    } catch (e) {
      toast('Lettre illisible : ' + e.message, true);
    } finally { btn.disabled = false; }
  };
  inp.click();
}
