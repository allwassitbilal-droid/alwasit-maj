// ☀️ Morning summary on Telegram (service worker; shared by Autofill TLS and Autofill BLS).
// Once a day, from 8:30 until 14:00, the first PC of the team that is on sends to the team's Telegram chat:
// appointments today and tomorrow, the day's tasks (and late ones), what to follow up, what is left to pay.
// The day is marked in the team settings (teamSettings.matin, synced ☁) so the other PCs don't send it again.
(() => {
  const local = chrome.storage.local;
  const APP = /TLS/i.test(chrome.runtime.getManifest().name) ? 'tls' : 'bls';
  const ymd = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const fr = iso => (iso ? iso.slice(8, 10) + '/' + iso.slice(5, 7) : '');
  const who = c => `${c.num != null && c.num !== '' ? 'N°' + c.num + ' ' : ''}${`${c.prenom || ''} ${c.nom || ''}`.trim() || '(sans nom)'}`;
  const DAY = 864e5;
  const START = 8 * 60 + 30, END = 14 * 60;

  function tlsExpiry(created) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(created || '')) return '';
    const [y, m, d] = created.split('-').map(Number);
    const last = new Date(Date.UTC(y, m - 1 + 3 + 1, 0)).getUTCDate();
    return new Date(Date.UTC(y, m - 1 + 3, Math.min(d, last))).toISOString().slice(0, 10);
  }
  const reste = c => {
    const prix = parseFloat(c.prix);
    return Number.isFinite(prix) ? Math.max(0, prix - (parseFloat(c.paye) || 0)) : 0;
  };

  function build(clients, tasks, now = new Date()) {
    const today = ymd(now), tomorrow = ymd(new Date(now.getTime() + DAY));
    const list = (title, rows) => (rows.length ? `${title} (${rows.length})\n${rows.map(r => '• ' + r).join('\n')}` : '');
    const parts = [];
    const live = clients.filter(c => !c.archive);
    const rdvOf = c => (APP === 'tls' ? (c.etape === 'rdv' && c.rdvDate ? { day: c.rdvDate, time: c.rdvHeure } : null)
      : (c.reserve?.day && !c.lettre ? c.reserve : null));
    const rdv = day => live.map(c => [c, rdvOf(c)]).filter(([, r]) => r?.day === day)
      .sort((a, b) => (a[1].time || '').localeCompare(b[1].time || ''))
      .map(([c, r]) => `${who(c)}${r.time ? ' à ' + r.time : ''}${r.face ? ' (selfie)' : ''}`);
    parts.push(list('⏰ RDV اليوم', rdv(today)), list(`🗓 RDV غدا ${fr(tomorrow)}`, rdv(tomorrow)));

    const byId = new Map(clients.map(c => [c.id, c]));
    const todo = (tasks || []).filter(t => !t.deleted && !t.done && !t.id.startsWith('auto:') && (t.day || today) <= today)
      .sort((a, b) => (a.day || '').localeCompare(b.day || ''))
      .map(t => `${(t.day || today) < today ? '⚠️ ' : ''}${t.text}${t.clientId && byId.get(t.clientId) ? ' — ' + who(byId.get(t.clientId)) : ''}`);
    parts.push(list('✅ المهام ديال اليوم', todo));

    if (APP === 'tls') {
      const acc = live.map(c => [c, tlsExpiry(c.tlsCree)]).filter(([, e]) => e && (new Date(e + 'T12:00:00') - now) / DAY <= 7)
        .map(([c, e]) => `${who(c)} — ${e < today ? 'expiré' : 'expire le ' + fr(e)}`);
      parts.push(list('⏳ كونطات TLS خاصهم يتجددو', acc));
      parts.push(list('📎 خاص نعيطو ليهم (Il manque)', live.filter(c => c.etape === 'manque').map(c => `${who(c)}${c.manque ? ' : ' + c.manque : ''}`)));
    }
    const due = live.filter(c => reste(c) > 0);
    if (due.length) {
      const total = due.reduce((s, c) => s + reste(c), 0);
      parts.push(`💰 باقي الخلاص: ${due.length} دوسي · ${total.toLocaleString('fr-FR')} DH`);
    }
    const body = parts.filter(Boolean).join('\n\n');
    const head = `☀️ صباح الخير — ${APP === 'tls' ? 'Autofill TLS 🇫🇷' : 'Autofill BLS 🇪🇸'} · ${fr(today)}`;
    return `${head}\n\n${body || 'ما كاين حتى حاجة مستعجلة اليوم 👌'}`;
  }

  async function telegramSettings() {
    const { teamSettings = {}, blsSettings = {} } = await local.get(['teamSettings', 'blsSettings']);
    return teamSettings.telegram || blsSettings.telegram || {};
  }
  async function send(tg, text) {
    try {
      const r = await fetch(`https://api.telegram.org/bot${encodeURIComponent(tg.botToken)}/sendMessage`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, signal: AbortSignal.timeout(15_000),
        body: JSON.stringify({ chat_id: tg.chatId, text }),
      });
      return (await r.json()).ok;
    } catch { return false; }
  }

  let running = null;
  const check = () => (running ||= run().finally(() => { running = null; }));
  async function run() {
    const now = new Date(), mins = now.getHours() * 60 + now.getMinutes(), today = ymd(now);
    if (mins < START || mins >= END) return;
    const first = await local.get(['teamSettings']);
    if (first.teamSettings?.matin === today) return;
    const tg = await telegramSettings();
    if (!tg.botToken || !tg.chatId) return;
    // Several PCs: wait a random moment, so the first one's mark arrives by sync before the others look again.
    await new Promise(r => setTimeout(r, 5_000 + Math.random() * 40_000));
    const { teamSettings = {}, clients = [] } = await local.get(['teamSettings', 'clients']);
    if (teamSettings.matin === today) return;
    await local.set({ teamSettings: { ...teamSettings, matin: today } }); // mark first: fewer doubles
    if (!(await send(tg, build(clients, teamSettings.tasks)))) {
      const { teamSettings: ts = {} } = await local.get('teamSettings');
      if (ts.matin === today) await local.set({ teamSettings: { ...ts, matin: undefined } }); // try again later
    }
  }

  chrome.alarms.create('matin-telegram', { delayInMinutes: 2, periodInMinutes: 15 });
  chrome.alarms.onAlarm.addListener(a => { if (a.name === 'matin-telegram') check(); });
  globalThis.AAMatin = { build, check };
})();
