// Agence Autofill: when BLS answers with an error (429 «too many requests», 500/502/503/504), a dialog
// counts down and reloads the page by itself, waiting at least the server's Retry-After. Each attempt in
// a row waits longer (60s, 2 min, 4 min, then 5 min), and after MAX_ATTEMPTS it gives up and alerts.
// «Réessayer» reloads now, «Stop» cancels. Watching that was on comes back after the reload (see «resume»).
import { askBackground, sendToBackground, type HttpTrouble } from "../shared/messages";
import { session, textOf } from "./util";

const ATTEMPTS_KEY = "aaRetryAttempts";
const BACKOFF_SEC = [60, 120, 240, 300];
export const MAX_ATTEMPTS = 6;
/** An HTTP error older than this no longer explains what the page shows. */
const FRESH_MS = 45_000;

/** BLS / Cloudflare / nginx error pages, read from the page itself (short pages only: a real page is long). */
const PAGE_ERRORS: Array<[RegExp, number]> = [
  [/too many requests|error 1015|you are being rate limited/i, 429],
  [/502\s*bad gateway|bad gateway/i, 502],
  [/503\s*service (temporarily )?unavailable|service (temporarily )?unavailable/i, 503],
  [/504\s*gateway time-?out|gateway time-?out/i, 504],
  [/500\s*internal server error|internal server error/i, 500],
];

function pageError(): number | null {
  const text = `${document.title} ${textOf(document.body)}`;
  if (text.length > 3000) return null;
  return PAGE_ERRORS.find(([re]) => re.test(text))?.[1] ?? null;
}

/**
 * What went wrong, if BLS refused or failed: the page's own error text, else a recent 429/5xx the background
 * saw for this tab (the page document, or with apiToo the site's API calls behind the calendar).
 */
export async function httpTrouble(apiToo: boolean): Promise<HttpTrouble | null> {
  const seen = await askBackground<HttpTrouble | null>({ type: "httpTrouble" });
  const fresh = seen && Date.now() - seen.at < FRESH_MS && (seen.mainFrame || apiToo) ? seen : null;
  const fromPage = pageError();
  if (fromPage) return { status: fresh?.status ?? fromPage, retryAfterSec: fresh?.retryAfterSec, at: Date.now(), mainFrame: true };
  return fresh;
}

/** The page works again: the next error starts the waits over from 60s. */
export const resetRetries = (): void => session.set(ATTEMPTS_KEY, "0");

const attempts = (): number => Number(session.get(ATTEMPTS_KEY)) || 0;

const label = (status: number): string =>
  status === 429 ? "BLS قال: طلبات بزاف (429)" : `BLS ما جاوبش مزيان (${status})`;

const CSS = `
:host { all: initial; }
.back { position: fixed; inset: 0; z-index: 2147483647; display: grid; place-items: center;
  background: rgba(8, 15, 24, .55); font: 14px/1.45 system-ui, "Segoe UI", Tahoma, sans-serif; }
.box { direction: rtl; text-align: right; width: min(420px, calc(100vw - 32px)); padding: 18px 20px; border-radius: 14px;
  background: #0f1d2b; color: #e6edf3; box-shadow: 0 18px 50px rgba(0,0,0,.5); border-top: 4px solid #f0a24a; }
h2 { margin: 0 0 6px; font-size: 16px; }
p { margin: 0 0 4px; color: #b9c7d4; }
.count { font: 800 34px/1.1 system-ui, sans-serif; color: #f0a24a; margin: 10px 0; direction: ltr; text-align: center; }
.row { display: flex; gap: 8px; margin-top: 12px; }
button { all: unset; cursor: pointer; flex: 1; text-align: center; padding: 9px 12px; border-radius: 999px; font-weight: 700; color: #fff; }
.now { background: #1f8f5a; } .stop { background: #b4483e; }
button:hover { filter: brightness(1.12); }
`;

let open = false;

/**
 * Shows the countdown and reloads at zero. Returns false (and alerts) once MAX_ATTEMPTS ran out in a row.
 * onStop: the user cancelled (watching then stays stopped).
 */
export function showRetry(t: HttpTrouble, onStop: () => void): boolean {
  if (open) return true;
  const n = attempts();
  if (n >= MAX_ATTEMPTS) {
    const text = `⛔ ${label(t.status)}، عاودت ${MAX_ATTEMPTS} مرات وما خدمش. جرب من بعد بيدك (F5)`;
    sendToBackground({ type: "notify", text });
    sendToBackground({ type: "log", text, tone: "err" });
    resetRetries();
    return false;
  }
  open = true;
  const waitSec = Math.max(t.retryAfterSec ?? 0, BACKOFF_SEC[Math.min(n, BACKOFF_SEC.length - 1)] ?? 300);
  const until = Date.now() + waitSec * 1000;
  sendToBackground({
    type: "log",
    text: `⚠️ ${label(t.status)}${t.retryAfterSec ? ` · Retry-After ${t.retryAfterSec}s` : ""} · محاولة ${n + 1}/${MAX_ATTEMPTS} من بعد ${waitSec}s`,
    tone: "warn",
  });

  const host = document.createElement("div");
  const root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `<style>${CSS}</style><div class="back"><div class="box">
    <h2>⚠️ ${label(t.status)}</h2>
    <p>غادي نعاود نحمّل الصفحة بوحدي${t.retryAfterSec ? ` (BLS طلب نتسناو ${t.retryAfterSec} ثانية)` : ""}.</p>
    <p>محاولة ${n + 1} من ${MAX_ATTEMPTS}. المراقبة كترجع بوحدها من بعد.</p>
    <div class="count"></div>
    <div class="row"><button class="now">↻ Réessayer</button><button class="stop">■ Stop</button></div>
  </div></div>`;
  document.documentElement.append(host);
  const count = root.querySelector(".count") as HTMLElement;

  const go = () => {
    clearInterval(timer);
    session.set(ATTEMPTS_KEY, String(n + 1));
    location.reload();
  };
  const tick = () => {
    const left = Math.max(0, Math.ceil((until - Date.now()) / 1000));
    count.textContent = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}`;
    if (!left) go();
  };
  const timer = setInterval(tick, 500);
  tick();
  (root.querySelector(".now") as HTMLElement).onclick = go;
  (root.querySelector(".stop") as HTMLElement).onclick = () => {
    clearInterval(timer);
    host.remove();
    open = false;
    resetRetries();
    onStop();
  };
  return true;
}
