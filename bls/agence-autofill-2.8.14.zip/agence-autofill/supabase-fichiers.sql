-- Agence Autofill : fichiers des clients (formulaire PDF, photo, passeport).
-- À coller dans Supabase → SQL Editor → New query → Run (une seule fois).
-- Ne touche pas au tableau des clients : ajoute seulement un espace privé pour les fichiers.

insert into storage.buckets (id, name, public, file_size_limit)
values ('fichiers', 'fichiers', false, 10485760) -- privé, 10 Mo max par fichier
on conflict (id) do nothing;

drop policy if exists "equipe lit fichiers" on storage.objects;
drop policy if exists "equipe ajoute fichiers" on storage.objects;
drop policy if exists "equipe modifie fichiers" on storage.objects;
drop policy if exists "equipe supprime fichiers" on storage.objects;

-- Seuls les comptes de l'équipe (connectés) voient et gèrent les fichiers.
create policy "equipe lit fichiers" on storage.objects for select to authenticated using (bucket_id = 'fichiers');
create policy "equipe ajoute fichiers" on storage.objects for insert to authenticated with check (bucket_id = 'fichiers');
create policy "equipe modifie fichiers" on storage.objects for update to authenticated using (bucket_id = 'fichiers') with check (bucket_id = 'fichiers');
create policy "equipe supprime fichiers" on storage.objects for delete to authenticated using (bucket_id = 'fichiers');
